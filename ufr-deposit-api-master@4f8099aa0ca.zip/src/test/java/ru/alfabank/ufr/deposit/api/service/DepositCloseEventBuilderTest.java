package ru.alfabank.ufr.deposit.api.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import org.apache.commons.lang.StringUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import ru.alfabank.ufr.deposit.api.configuration.DepositAutoProlongationParams;
import ru.alfabank.ufr.deposit.api.configuration.DepositClaimParams;
import ru.alfabank.ufr.deposit.api.configuration.DepositRefillParams;
import ru.alfabank.ufr.deposit.api.entity.repository.ad.Employee;
import ru.alfabank.ufr.deposit.api.entity.rest.DepositCloseInData;
import ru.alfabank.ufr.deposit.api.repository.accounts.AccountsApi;
import ru.alfabank.ufr.deposit.api.repository.ad.AdApiRepository;
import ru.alfabank.ufr.deposit.api.repository.client.ClientDepositsRestRepository;
import ru.alfabank.ufr.deposit.api.repository.client.ClientDepositsSOAPRepository;
import ru.alfabank.ufr.deposit.api.repository.close.ClosingDepositRepository;
import ru.alfabank.ufr.deposit.api.repository.currency.DepositCurrencyApi;
import ru.alfabank.ufr.deposit.api.repository.depositPrincipal.DepositPrincipalRepository;
import ru.alfabank.ufr.deposit.api.repository.event.Event;
import ru.alfabank.ufr.deposit.api.repository.event.EventRepository;
import ru.alfabank.ufr.deposit.api.repository.opened.OpenedDepositRepository;
import ru.alfabank.ufr.deposit.api.repository.operation.OperationTypeGetter;
import ru.alfabank.ufr.deposit.api.repository.refill.RefillDepositRepository;
import ru.alfabank.ufr.deposit.api.repository.session.SessionRepository;
import ru.alfabank.ufr.deposit.api.repository.types.DepositTypesRepository;
import ru.alfabank.ufr.deposit.api.repository.variants.DepositVariantsRepository;
import ru.alfabank.ufr.deposit.api.service.session.SessionService;
import ru.alfabank.ufr.deposit.api.utils.DtoConverter;
import ru.alfabank.ufr.deposit.api.utils.EventFactory;
import ru.alfabank.ufr.deposit.api.utils.Timestamp;

import java.time.Instant;
import java.time.format.DateTimeFormatter;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static ru.alfabank.ufr.deposit.api.configuration.Constants.ACC_TYPE;
import static ru.alfabank.ufr.deposit.api.configuration.Constants.EVENT_TYPE_100;
import static ru.alfabank.ufr.deposit.api.configuration.Constants.EVENT_TYPE_118;
import static ru.alfabank.ufr.deposit.api.configuration.Constants.EVENT_TYPE_119;
import static ru.alfabank.ufr.deposit.api.configuration.Constants.EVENT_TYPE_24;
import static ru.alfabank.ufr.deposit.api.configuration.Constants.WORKFLOW_DEFAULT;

@ExtendWith(SpringExtension.class)
@MockBean(classes = {
        ClientDepositsRestRepository.class,
        ClientDepositsSOAPRepository.class,
        DepositTypesRepository.class,
        DepositVariantsRepository.class,
        OpenedDepositRepository.class,
        ClosingDepositRepository.class,
        EventRepository.class,
        AdApiRepository.class,
        AccountsApi.class,
        RefillDepositRepository.class,
        SessionRepository.class,
        DepositPrincipalRepository.class,
        DtoConverter.class,
        SessionService.class,
        DepositIdGenerator.class,
        DepositService.CreateDepositRequestMapper.class,
        DepositCurrencyApi.class
})
@EnableConfigurationProperties(value = {
        DepositRefillParams.class,
        DepositClaimParams.class,
        DepositAutoProlongationParams.class})
@ContextConfiguration(classes = {DepositService.class, EventFactory.class})
public class DepositCloseEventBuilderTest {

    private static final String OPERATOR_LOGIN = "U_000A0";
    private static final String EVENT_NUMBER_1 = "AD014U_000A01464931480300";
    private static final String EVENT_NUMBER_2 = "AD020U_000A01464931480300";
    private static final String BARCODE_1 = "BARCODE1";
    private static final String BARCODE_2 = "BARCODE2";
    private static final String EAND = "40817810404100000014";
    private static final String EQ_ID = "A001";
    private static final String BRNM = "MOPV";
    private static final String DLP = "AQ3";
    private static final String DLR = "AQVX7Q101090D";
    private static final String USER_BRANCH = "MOCC";
    private static final String EMPLOYEE_FIO = "Фамилия Имя";
    private static final String EMPLOYEE_POSITION = "Оператор";

    private Employee employee;

    {
        employee = new Employee();
        employee.setDisplayName(EMPLOYEE_FIO);
        employee.setTitle(EMPLOYEE_POSITION);
    }

    @MockBean
    private AdApiRepository adApiRepository;
    @MockBean
    private OperationTypeGetter operationTypeGetter;

    @Autowired
    private DepositService depositService;
    @Autowired
    private EventFactory eventFactory;


    @Value("${deposit.close.freeFormatExtSysCode}")
    private String freeFormatExtSysCode;

    private DepositCloseInData createRequest(String needDULScan) {
        DepositCloseInData request = new DepositCloseInData();
        request.setOperatorLogin(OPERATOR_LOGIN);
        request.setEventNumber1(EVENT_NUMBER_1);
        request.setEventNumber2(EVENT_NUMBER_2);
        request.setWasESigning("Y");
        request.setWasSecondDoc("Y");
        request.setBarcode1(BARCODE_1);
        request.setBarcode2(BARCODE_2);
        request.setEand(EAND);
        request.setEqId(EQ_ID);
        request.setBrnm(BRNM);
        request.setDlp(DLP);
        request.setDlr(DLR);
        request.setUserBranch(USER_BRANCH);
        request.setWorkflow(WORKFLOW_DEFAULT);
        request.setNeedDULScan(needDULScan);
        return request;
    }

    @Test
    public void timestampsFormatCheck() throws JsonProcessingException {
        final String etalon = "2020-01-01T01:01:01Z";
        Timestamp t = new Timestamp(Instant.from(DateTimeFormatter.ISO_INSTANT.parse(etalon)));
        String serialized = new ObjectMapper().writeValueAsString(Event.builder().time(t).startTime(t).callingTime(t).build());
        DocumentContext dctx = JsonPath.parse(serialized);
        assertEquals(etalon, dctx.read("$.time"));
        assertEquals(etalon, dctx.read("$.startTime"));
        assertEquals(etalon, dctx.read("$.callingTime"));
    }

    @Test
    public void getEvent24() {
        String eventType = EVENT_TYPE_24;
        String freeFormat = String.format("<m>" +
                        "<ga>%s</ga>" +
                        "<dpType>%s</dpType>" +
                        "<accType>%s</accType>" +
                        "<fio>%s</fio>" +
                        "<operatorPosition>%s</operatorPosition>" +
                        "<mc>%s</mc>" +
                        "</m>",
                EAND,
                DLP,
                ACC_TYPE,
                EMPLOYEE_FIO,
                EMPLOYEE_POSITION,
                eventType);
        Mockito.when(adApiRepository.getEmployee(OPERATOR_LOGIN)).thenReturn(employee);

        Event event = eventFactory.getDepositCloseEvent(createRequest(null), eventType);

        assertEquals(freeFormat, event.getFreeFormat());
        assertTrue(event.getEventNumber().startsWith(OPERATOR_LOGIN));
        assertEquals(BRNM + DLP + DLR, event.getDealID());
    }

    @Test
    public void getEvent118() {
        String eventType = EVENT_TYPE_118;
        String freeFormat = String.format("<m>" +
                        "<ga>%s</ga>" +
                        "<dpType>%s</dpType>" +
                        "<accType>%s</accType>" +
                        "<fio>%s</fio>" +
                        "<operatorPosition>%s</operatorPosition>" +
                        "<mc>%s</mc>" +
                        "<docs>AD014</docs><bcd>%s|AD014|d</bcd>" +
                        "<opId>%s</opId><extSysCode>%s</extSysCode><eDoc>true</eDoc>" +
                        "</m>",
                EAND,
                DLP,
                ACC_TYPE,
                EMPLOYEE_FIO,
                EMPLOYEE_POSITION,
                eventType,
                StringUtils.EMPTY,
                EVENT_NUMBER_1,
                freeFormatExtSysCode
        );
        Mockito.when(adApiRepository.getEmployee(OPERATOR_LOGIN)).thenReturn(employee);

        Event event = eventFactory.getDepositCloseEvent(createRequest("N"), eventType);

        assertEquals(freeFormat, event.getFreeFormat());
        assertEquals(EVENT_NUMBER_1, event.getEventNumber());
    }

    @Test
    public void getEvent119() {
        String eventType = EVENT_TYPE_119;
        String freeFormat = String.format("<m>" +
                        "<ga>%s</ga>" +
                        "<dpType>%s</dpType>" +
                        "<accType>%s</accType>" +
                        "<fio>%s</fio>" +
                        "<operatorPosition>%s</operatorPosition>" +
                        "<mc>%s</mc>" +
                        "<docs>AD014;AD001</docs><bcd>%s|AD014|d</bcd>" +
                        "<opId>%s</opId><extSysCode>%s</extSysCode><eDoc>true</eDoc>" +
                        "</m>",
                EAND,
                DLP,
                ACC_TYPE,
                EMPLOYEE_FIO,
                EMPLOYEE_POSITION,
                eventType,
                StringUtils.EMPTY,
                EVENT_NUMBER_1,
                freeFormatExtSysCode
        );
        Mockito.when(adApiRepository.getEmployee(OPERATOR_LOGIN)).thenReturn(employee);

        Event event = eventFactory.getDepositCloseEvent(createRequest("Y"), eventType);

        assertEquals(freeFormat, event.getFreeFormat());
        assertEquals(EVENT_NUMBER_1, event.getEventNumber());
    }

    @Test
    public void getEvent100() {
        String eventType = EVENT_TYPE_100;
        String freeFormat = String.format("<m>" +
                        "<ga>%s</ga>" +
                        "<dpType>%s</dpType>" +
                        "<accType>%s</accType>" +
                        "<fio>%s</fio>" +
                        "<operatorPosition>%s</operatorPosition>" +
                        "<mc>%s</mc>" +
                        "<docs>AD020</docs><bcd>%s|AD020|m</bcd>" +
                        "<opId>%s</opId><extSysCode>%s</extSysCode><eDoc>false</eDoc>" +
                        "</m>",
                EAND,
                DLP,
                ACC_TYPE,
                EMPLOYEE_FIO,
                EMPLOYEE_POSITION,
                eventType,
                BARCODE_2,
                EVENT_NUMBER_2,
                freeFormatExtSysCode
        );
        Mockito.when(adApiRepository.getEmployee(OPERATOR_LOGIN)).thenReturn(employee);

        Event event = eventFactory.getDepositCloseEvent(createRequest(null), eventType);

        assertEquals(freeFormat, event.getFreeFormat());
        assertEquals(EVENT_NUMBER_2, event.getEventNumber());
    }
}