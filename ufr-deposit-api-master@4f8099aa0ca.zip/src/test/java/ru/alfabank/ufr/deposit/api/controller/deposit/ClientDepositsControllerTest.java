package ru.alfabank.ufr.deposit.api.controller.deposit;

import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.junit.WireMockRule;
import com.github.tomakehurst.wiremock.junit5.WireMockTest;
import lombok.SneakyThrows;
import org.apache.commons.lang.StringUtils;
import org.aspectj.lang.annotation.Before;
import org.hamcrest.BaseMatcher;
import org.hamcrest.Description;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import ru.alfabank.ufr.deposit.api.configuration.SessionHeadersNames;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.containing;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.matchingXPath;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathMatching;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(SpringExtension.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureMockMvc
@ActiveProfiles({"test"})
@WireMockTest(httpPort = 4567)
public class ClientDepositsControllerTest {
    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private SessionHeadersNames sessionHeadersNames;

    public static final String REFILL_REQUEST_OK = "{\n" +
            "\t\"userBranch\": \"MOPV\",\n" +
            "\t\"brnm\": \"MOAL\",\n" +
            "\t\"dlp\": \"AV2\",\n" +
            "\t\"dlr\": \"AAAP6H11198I2\",\n" +
            "\t\"sum\": 1000,\n" +
            "\t\"expressAccount\": \"NDA4MTc4MTAwMDQyMzAwNTk2MTA=\",\n" +
            "\t\"wasRURTransfer\": \"Y\",\n" +
            "\t\"wasForeignCurrTransfer\": \"N\",\n" +
            "\t\"debetAccNum\": \"40817810604230008472\",\n" +
            "\t\"debetAccCurrency\": \"RUR\",\n" +
            "\t\"convertedDebetSum\": null,\n" +
            "\t\"rate\": null,\n" +
            "\t\"servicePacketCode\": \"N01\",\n" +
            "\t\"servicePacketName\": \"Пакет услуг \\\"Максимум+\\\"\",\n" +
            "\t\"currencyRate\": \"RUR\"\n" +
            "}";

    @BeforeEach
    public void init() {
        WireMock.stubFor(post(urlPathMatching("/CS/EQ/WSDepositWithdraw/WSDepositWithdraw11"))
                .withHeader("SOAPAction", containing("/CS/EQ/WSDepositWithdraw/11#Add"))
                .withRequestBody(matchingXPath("//dlp[contains(text(),'faulty')]"))
                .willReturn(aResponse()
                    .withStatus(500)
                    .withHeader("Content-Type", "text/xml")
                    .withBodyFile("responses/WSDepositWithdraw11Add-error.xml")));
        WireMock.stubFor(post(urlPathMatching("/CS/EQ/WSStatementDepositInfo14/SOAP"))
                .withHeader("SOAPAction", containing("/CS/EQ/WSStatementDepositInfo14#Get"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "text/xml")
                        .withBodyFile("responses/WSStatementDepositInfo14-Get-ok.xml")));
        WireMock.stubFor(post(urlPathMatching("/CS/EQ/WSDepositPrincipal/WSDepositPrincipal10"))
                .withHeader("SOAPAction", containing("/CS/EQ/WSDepositPrincipal10#Add"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "text/xml")
                        .withBodyFile("responses/WSDepositPrincipal10#Add-ok.xml")));
        WireMock.stubFor(post(urlPathMatching("/ufr-mcrm-ucc-session-api/session/check"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody("{\n" +
                                "  \"status\": \"SESSION_EXISTS\"\n" +
                                "}")));
        WireMock.stubFor(post(urlPathMatching("/ufr-mcrm-ucc-session-api/event/add"))
                .willReturn(aResponse()
                        .withStatus(200)));
        WireMock.stubFor(post(urlPathMatching("/ufr-mcrm-code-business-event-api/events"))
                .willReturn(aResponse()
                        .withStatus(200)));
        WireMock.stubFor(get(urlPathMatching("/ufr-start-board-ad-api/api/employees/OPOPOP"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody("{\n" +
                                "\"sAMAccountName\": \"OPOPOP\",\n" +
                                "\"displayName\": \"Тестов Тест Тестович\",\n" +
                                "\"eqMnemonic\": \"MOCO\",\n" +
                                "\"eqNumber\": \"0000\",\n" +
                                "\"eqProfile\": \"CLIN\",\n" +
                                "\"dn\": \"CN=utest0455,OU=Techusers,OU=PROJECTS,DC=msk,DC=ad2012,DC=loc\",\n" +
                                "\"groups\": [\n" +
                                "\"CLIN_0000_D\",\n" +
                                "\"CLIN_0002_R\"\n" +
                                "],\n" +
                                "\"permissions\": [],\n" +
                                "\"roles\": []\n" +
                                "}")));
    }

    @Test
    public void closeDeposit_check_errorCode() throws Exception {

        MvcResult result = mockMvc.perform(
                        MockMvcRequestBuilders.post("/deposit/client/close")
                                .header(sessionHeadersNames.getEqId(), "NNNNNN")
                                .header(sessionHeadersNames.getOperatorLogin(), "OPOPOP")
                                .header(sessionHeadersNames.getSessionToken(), "dummyToken")
                                .content("{\n" +
                                        "  \"barcode1\": \"string\",\n" +
                                        "  \"barcode2\": \"string\",\n" +
                                        "  \"brnm\": \"string\",\n" +
                                        "  \"dlp\": \"faulty\",\n" +
                                        "  \"dlr\": \"string\",\n" +
                                        "  \"eand\": \"string\",\n" +
                                        "  \"eventNumber1\": \"string\",\n" +
                                        "  \"eventNumber2\": \"string\",\n" +
                                        "  \"needDULScan\": \"string\",\n" +
                                        "  \"tax\": \"string\",\n" +
                                        "  \"userBranch\": \"string\",\n" +
                                        "  \"wasESigning\": \"string\",\n" +
                                        "  \"wasSecondDoc\": \"string\",\n" +
                                        "  \"workflow\": \"string\"\n" +
                                        "}")
                                .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(MockMvcResultMatchers.status().is5xxServerError())
                .andReturn();

        assertTrue(result.getResponse().getContentAsString().contains("BSM8747"));
    }

    @Test
    public void refill_deposit__should_return_ok() throws Exception {
        WireMock.stubFor(get(urlEqualTo("/ufr-deposit-accounts-api/accounts/AAAP6H?operationTypes=allCustomerAccounts&act=EL"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBodyFile("responses/AAAP6Haccounts.json")));
        WireMock.stubFor(post(urlPathMatching("/ufr-mcrm-ucc-session-api/event/add"))
                .willReturn(aResponse()
                        .withStatus(200)));

        mockMvc.perform(
                MockMvcRequestBuilders.post("/deposit/client/refill")
                        .header(sessionHeadersNames.getEqId(), "AAAP6H")
                        .header(sessionHeadersNames.getOperatorLogin(), "OPOPOP")
                        .header(sessionHeadersNames.getSessionToken(), "dummyToken")
                        .content(REFILL_REQUEST_OK)
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(MockMvcResultMatchers.status().is2xxSuccessful())
                .andExpect(MockMvcResultMatchers.content().string(new BaseMatcher<String>() {
                    @SneakyThrows
                    @Override
                    public boolean matches(Object item) {
                        return StringUtils.isNumeric((String)item);
                    }

                    @Override
                    public void describeTo(Description description) {
                    }
                }));
    }
}