package ru.alfabank.ufr.deposit.api.service;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import ru.alfabank.ufr.deposit.api.configuration.Constants;
import ru.alfabank.ufr.deposit.api.configuration.DepositRefillParams;
import ru.alfabank.ufr.deposit.api.entity.repository.accounts.Account;
import ru.alfabank.ufr.deposit.api.entity.repository.ad.Employee;
import ru.alfabank.ufr.deposit.api.entity.rest.DepositRefillInData;
import ru.alfabank.ufr.deposit.api.entity.rest.OpenedDepositDetails;
import ru.alfabank.ufr.deposit.api.repository.accounts.AccountsApi;
import ru.alfabank.ufr.deposit.api.repository.ad.AdApiRepository;
import ru.alfabank.ufr.deposit.api.repository.event.Event;
import ru.alfabank.ufr.deposit.api.repository.event.EventRepository;
import ru.alfabank.ufr.deposit.api.repository.opened.OpenedDepositRepository;
import ru.alfabank.ufr.deposit.api.repository.refill.RefillDepositRepository;
import ru.alfabank.ufr.deposit.api.repository.session.SessionRepository;
import ru.alfabank.ufr.deposit.api.utils.EventFactory;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class DepositServiceTest {

    public static final String DEFAULT_CUS = "cus";
    public static final String DEFAULT_OP_LOGIN = "opLogin";
    public static final String DEFAULT_SESSION_TOKEN = "sessionToken";
    public static final String DEFAULT_ACCOUNT_IN_BASE_64 = "ZXhwcmVzcyBhY2NvdW50";
    public static final String DEFAULT_EXPRESS_ACCOUNT = "express account";
    public static final String DEFAULT_DATE_FORMAT = "dd/MM/yyyy";

    @InjectMocks
    private DepositService uut; // unit under test

    @Mock
    private AdApiRepository adApiRepository;
    @Mock
    private AccountsApi accountsApi;
    @Mock
    private RefillDepositRepository refillDepositRepository;
    @Mock
    private SessionRepository sessionRepository;
    @Mock
    private EventRepository eventRepository;
    @Mock
    private DepositRefillParams depositRefillParams;
    @Mock
    private OpenedDepositRepository openedDepositRepository;
    @Mock
    private DepositRefillParams.SessionEvent mockedSessionEvent;
    @Mock
    private EventFactory eventFactory;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    /**
     * Тест проверяет, что внешние сервисы не будут вызываться, только если переданы флаги и они явно выключены.
     */
    @ParameterizedTest
    @CsvSource(
            value = {
                    "true, true, 1",
                    "null, null, 1",
                    "false, false, 0"
            },
            nullValues = "null")
    void refillDepositSuccessSendEventTest(Boolean writeEventToSessionFlag, Boolean createBusinessEventFlag, int expectedEventCallCount) {
        final var expectedRefillResult = BigDecimal.valueOf(10001);

        final DepositRefillInData inData = createValidInputData();
        inData.setWriteEventToSession(writeEventToSessionFlag);
        inData.setCreateBusinessEvent(createBusinessEventFlag);

        final OpenedDepositDetails openedDepositDetails = createValidOpenedDepositDetails();

        when(accountsApi.getAccountListByPinEq(eq(DEFAULT_CUS), any(), any()))
                .thenReturn(Set.of(new Account().setAccountNumber(DEFAULT_EXPRESS_ACCOUNT)));
        when(refillDepositRepository.refill(any())).thenReturn(expectedRefillResult);
        when(depositRefillParams.getXm()).thenReturn("xm");
        when(depositRefillParams.getLnm()).thenReturn("lnm");
        when(openedDepositRepository.getDetails(eq("brnm"), eq("dlp"), eq("dl"), eq("xm"), eq("lnm")))
                .thenReturn(openedDepositDetails);
        when(adApiRepository.getEmployee(eq(DEFAULT_OP_LOGIN))).thenReturn(new Employee());
        when(depositRefillParams.getSessionEvent()).thenReturn(mockedSessionEvent);
        when(mockedSessionEvent.getNumberDecimalSeparator()).thenReturn(Constants.NumberDecimalSeparator.DOT);
        when(mockedSessionEvent.getNumberGroupSeparator()).thenReturn(Constants.NumberGroupSeparator.SPACE);
        when(mockedSessionEvent.getCommonDateFormat()).thenReturn(DEFAULT_DATE_FORMAT);
        when(eventFactory.getEventRefillDeposit(eq(DEFAULT_CUS), eq(DEFAULT_OP_LOGIN), eq(inData)))
                .thenReturn(Event.builder().build());

        final var refillResult = uut.refillDeposit(DEFAULT_CUS, DEFAULT_OP_LOGIN, DEFAULT_SESSION_TOKEN, inData, Locale.ROOT);

        Assertions.assertEquals(expectedRefillResult, refillResult);
        verify(sessionRepository, times(expectedEventCallCount)).addEvent(any());
        verify(eventRepository, times(expectedEventCallCount)).createEvent(any());
    }

    private static DepositRefillInData createValidInputData() {
        final var inData = new DepositRefillInData();
        inData.setExpressAccount(DEFAULT_ACCOUNT_IN_BASE_64);
        inData.setSum(BigDecimal.TEN);
        inData.setBrnm("brnm");
        inData.setDlp("dlp");
        inData.setDlr("dl");
        return inData;
    }

    private static OpenedDepositDetails createValidOpenedDepositDetails() {
        final var openedDepositDetails = new OpenedDepositDetails();
        openedDepositDetails.setV5Bal(BigDecimal.ONE);
        openedDepositDetails.setOtdla2(BigDecimal.ZERO);
        openedDepositDetails.setStsum(BigDecimal.TEN);
        openedDepositDetails.setV5Nrd(new Date());
        openedDepositDetails.setAccrual(new OpenedDepositDetails.Accrual().setGraphic(List.of()));
        openedDepositDetails.setDdst(new Date());
        openedDepositDetails.setDdend(new Date());
        openedDepositDetails.setTotalint(BigDecimal.ONE);
        openedDepositDetails.setMaxsum(BigDecimal.TEN);
        openedDepositDetails.setPopol("Y");
        openedDepositDetails.setDinclast(BigDecimal.ZERO);
        return openedDepositDetails;
    }
}