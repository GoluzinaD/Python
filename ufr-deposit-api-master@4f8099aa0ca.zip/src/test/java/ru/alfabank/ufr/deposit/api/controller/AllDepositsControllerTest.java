package ru.alfabank.ufr.deposit.api.controller;

import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.junit5.WireMockTest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import ru.alfabank.api.utils.wiremock.stub.XPathResponseTransformer;

import static com.github.tomakehurst.wiremock.client.WireMock.containing;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.urlMatching;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static ru.alfabank.api.utils.wiremock.stub.FileResponseBuilder.stubFor;

@ExtendWith(SpringExtension.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureMockMvc
@ActiveProfiles({"test"})
@WireMockTest(httpPort = 4567)
public class AllDepositsControllerTest {
    @Autowired
    private MockMvc mockMvc;

    @Test
    public void getDepositVariants() throws Exception {
        givenWSDepositRatesGetResponseType("responses/WSDepositRates_OK.xml");
        mockMvc.perform(get("/deposit/variants")
                .param("ctp", "AA")
                .param("ccy", "RUR")
                .param("dll", "AQ")
                .param("xm", "GB")
                .param("lnm", "RU")
                .param("pu", "T04")
                .param("osn", "Y")
                .param("std", "2019-11-18")
                .param("dlp", "AQ3")
        ).andExpect(MockMvcResultMatchers.status().is2xxSuccessful());
    }

    @Test
    public void getClosedDeposits() throws Exception {
        WireMock.stubFor(
                WireMock.get(urlMatching("/eq/customer/depositfinres/v10/rest.*"))
                        .willReturn(WireMock.aResponse()
                                .withHeader("Content-Type", "application/xml;charset=UTF-8")
                                .withBodyFile("responses/RestDepositFinRes_OK.xml")));
        mockMvc.perform(get("/deposit/client/rest/AAAAAA")
        ).andExpect(MockMvcResultMatchers.status().is2xxSuccessful());
    }

    @Test
    public void getDepositVariants_RequiredParamsOnly() throws Exception {
        givenWSDepositRatesGetResponseType("responses/WSDepositRates_OK.xml");
        mockMvc.perform(get("/deposit/variants")
                .param("ctp", "AA")
                .param("ccy", "RUR")
                .param("xm", "GB")
                .param("lnm", "RU")
                .param("pu", "T04")
                .param("osn", "Y")
        ).andExpect(MockMvcResultMatchers.status().is2xxSuccessful());
    }

    @Test
    public void getDepositVariants_ValidationError() throws Exception {
        givenWSDepositRatesGetResponseType("responses/WSDepositRates_OK.xml");
        mockMvc.perform(get("/deposit/variants")
                .param("ctp", "AA")
                .param("xm", "GB")
                .param("lnm", "RU")
                .param("pu", "T04")
                .param("osn", "Y")
        ).andExpect(MockMvcResultMatchers.status().is5xxServerError());
    }

    private void givenWSDepositRatesGetResponseType(String responsePath) {
        String endpoint = "/CS/EQ/WSDepositRates/WSDepositRates12";
        XPathResponseTransformer response = stubFor(endpoint)
                .withFile(responsePath);
        WireMock.givenThat(
                post(urlEqualTo(endpoint))
                        .withHeader("SOAPAction", containing("/CS/EQ/WSDepositRates12#Get"))
                        .willReturn(response.getFileResponseBuilder().getResponse())
        );
    }
}