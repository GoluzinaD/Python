package ru.alfabank.ufr.deposit.api.entity.repository.operation;

import lombok.Data;

@Data
public class OperationType {
    private String operationName;
}
