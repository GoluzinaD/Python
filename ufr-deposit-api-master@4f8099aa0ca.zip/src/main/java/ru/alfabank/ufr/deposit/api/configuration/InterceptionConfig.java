package ru.alfabank.ufr.deposit.api.configuration;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import ru.alfabank.ufr.deposit.api.controller.interceptor.SessionValidator;
import ru.alfabank.ufr.deposit.api.repository.session.SessionRepository;

@Configuration
@RequiredArgsConstructor
public class InterceptionConfig implements WebMvcConfigurer {
    private final SessionHeadersNames sessionHeadersNames;
    private final SessionValidator.SessionApiDTOConverter mapper;

    @Autowired
    @Lazy
    private SessionRepository sessionRepository;
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(new SessionValidator(sessionHeadersNames, mapper, sessionRepository))
                .excludePathPatterns(
                        "/admin/**",
                        "/favicon.ico",
                        "/error",
                        "/v3/api-docs",
                        "/swagger-resources/**",
                        "/swagger-ui/**",
                        "/webjars/**"
                );
    }
}
