package ru.alfabank.ufr.deposit.api.service.session;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.alfabank.ufr.deposit.api.configuration.DepositAutoProlongationParams;
import ru.alfabank.ufr.deposit.api.configuration.moduleinfo.DepositCreateParams;
import ru.alfabank.ufr.deposit.api.entity.repository.session.CustomEventDataDto;
import ru.alfabank.ufr.deposit.api.entity.repository.session.EventDto;
import ru.alfabank.ufr.deposit.api.entity.repository.session.TokenDto;
import ru.alfabank.ufr.deposit.api.entity.rest.DepositCreateRESTRequestData;
import ru.alfabank.ufr.deposit.api.entity.rest.autoProlongation.AutoProlongationRequest;
import ru.alfabank.ufr.deposit.api.entity.rest.session.SessionRequestWrapper;
import ru.alfabank.ufr.deposit.api.repository.session.SessionRepository;
import ru.alfabank.ufr.deposit.api.service.exceptions.SessionAddEventException;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;
import java.util.Map;

@Slf4j
@Component
@RequiredArgsConstructor
public class SessionApiService implements SessionService {
    private final SessionRepository sessionRepository;
    private final DepositCreateParams depositCreateParams;
    private final DepositAutoProlongationParams depositAutoProlongationParams;

    @Override
    public TokenDto addCreateDepositEvent(DepositCreateRESTRequestData request, Date operationDateTime) {

        SessionRequestWrapper<DepositCreateRESTRequestData> requestWrapper = new SessionRequestWrapper<>(request);
        Map<String, String> customFields = SessionCustomFieldsGenerator.CREATE.getCustomFields(requestWrapper);

        ZonedDateTime dateTime = convertToZonedDateTime(operationDateTime);

        EventDto eventDto = createEventDto(request.getSessionToken(), customFields, dateTime,
                depositCreateParams.getSessionEvent().getCustomType(), depositCreateParams.getSessionEvent().getEventType());

        TokenDto tokenDto = null;
        try {
            tokenDto = sessionRepository.addEvent(eventDto);
        } catch (Exception e) {
            throw new SessionAddEventException(e);
        }
        return tokenDto;
    }

    @Override
    public TokenDto addProlongDepositEvent(AutoProlongationRequest request) {
        SessionRequestWrapper<AutoProlongationRequest> requestWrapper = new SessionRequestWrapper<>(request);
        Map<String, String> customFields = SessionCustomFieldsGenerator.PROLONG.getCustomFields(requestWrapper);

        EventDto eventDto = createEventDto(request.getSessionToken(), customFields, ZonedDateTime.now(),
                depositAutoProlongationParams.getCustomType(), depositAutoProlongationParams.getEventType());

        TokenDto tokenDto = null;
        try {
            tokenDto = sessionRepository.addEvent(eventDto);
        } catch (Exception e) {
            log.info("Error calling the SessionApi service, message is- {}", e.getMessage());
        }
        return tokenDto;
    }


    private ZonedDateTime convertToZonedDateTime(Date operationDateTime) {
        ZoneId defaultZoneId = ZoneId.systemDefault();
        // Convert Date to Instant
        Instant instant = operationDateTime.toInstant();
        // Instant + default time zone
        return instant.atZone(defaultZoneId);
    }

    private EventDto createEventDto(String sessionToken,
                                    Map<String, String> customFields,
                                    ZonedDateTime dateTime,
                                    String customType,
                                    String eventType) {
        return EventDto.builder()
                .token(sessionToken)
                .event(new CustomEventDataDto()
                        .setCustomFields(customFields)
                        .setCustomType(customType)
                        .setDateTime(dateTime)
                        .setEventType(eventType))
                .build();
    }
}
