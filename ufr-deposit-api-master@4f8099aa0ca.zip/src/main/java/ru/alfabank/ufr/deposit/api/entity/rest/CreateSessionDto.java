package ru.alfabank.ufr.deposit.api.entity.rest;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CreateSessionDto {
    @NotBlank
    private String eqId;
    @NotBlank
    private String operatorLogin;
    @NotBlank
    private String mobilePhone;
    private String workflow;
    private String viewtype;
    private String callerId;
    private String callerEntityId;
}