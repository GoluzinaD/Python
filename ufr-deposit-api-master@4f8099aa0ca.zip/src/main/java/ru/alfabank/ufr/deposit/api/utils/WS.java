package ru.alfabank.ufr.deposit.api.utils;

import lombok.experimental.UtilityClass;
import lombok.val;
import org.apache.commons.lang.StringUtils;
import ru.alfabank.ws.cs.wscommontypes10.WSCommonParms;

import java.util.Optional;

@UtilityClass
public class WS {
    public WSCommonParms duplicateAndReplaceWithNotBlank(WSCommonParms commonParms,
                                                         String branchNumber, String userId) {
        val w = duplicate(commonParms);
        Optional.ofNullable(branchNumber).filter(StringUtils::isNotBlank).ifPresent(w::setBranchNumber);
        Optional.ofNullable(userId).filter(StringUtils::isNotBlank).ifPresent(w::setUserID);
        return w;
    }

    public WSCommonParms duplicate(WSCommonParms commonParms) {
        WSCommonParms w = new WSCommonParms();
        w.setBranchNumber(commonParms.getBranchNumber());
        w.setExternalSystemCode(commonParms.getExternalSystemCode());
        w.setExternalUserCode(commonParms.getExternalUserCode());
        w.setLdapPassword(commonParms.getLdapPassword());
        w.setUserID(commonParms.getUserID());
        return w;
    }
}
