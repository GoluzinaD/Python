package ru.alfabank.ufr.deposit.api.utils;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import ru.alfabank.ufr.deposit.api.configuration.Constants;
import ru.alfabank.ufr.deposit.api.configuration.DepositAutoProlongationParams;
import ru.alfabank.ufr.deposit.api.configuration.DepositClaimParams;
import ru.alfabank.ufr.deposit.api.configuration.DepositRefillParams;
import ru.alfabank.ufr.deposit.api.entity.repository.ad.Employee;
import ru.alfabank.ufr.deposit.api.entity.rest.DepositCloseInData;
import ru.alfabank.ufr.deposit.api.entity.rest.DepositRefillInData;
import ru.alfabank.ufr.deposit.api.entity.rest.autoProlongation.AutoProlongationRequest;
import ru.alfabank.ufr.deposit.api.entity.rest.depositClaim.DepositClaimRequest;
import ru.alfabank.ufr.deposit.api.repository.ad.AdApiRepository;
import ru.alfabank.ufr.deposit.api.repository.event.Event;

import java.util.Base64;

import static ru.alfabank.ufr.deposit.api.configuration.Constants.*;

@Slf4j
@Component
@RequiredArgsConstructor
public class EventFactory {
    private final AdApiRepository adApiRepository;
    private final DepositRefillParams depositRefillParams;
    private final DepositClaimParams depositClaimParams;
    private final DepositAutoProlongationParams depositAutoProlongationParams;

    @Value("${deposit.close.channelId}")
    private String channelId;
    @Value("${deposit.close.masterSys}")
    private String masterSys;
    @Value("${deposit.close.externalSys}")
    private String externalSys;
    @Value("${deposit.close.masterSysEvent24}")
    private String masterSys24;
    @Value("${deposit.close.externalSysEvent24}")
    private String externalSys24;
    @Value("${deposit.close.freeFormatExtSysCode}")
    private String freeFormatExtSysCode;


    public Event getDepositCloseEvent(DepositCloseInData r, String eventType) {
        Timestamp now = Timestamp.now();
        String eventNumber;
        String operatorLogin = r.getOperatorLogin();
        String docs = "";
        String bcd = "";
        boolean isDigitalDocument = Y.equals(r.getWasESigning());
        switch (eventType) {
            case EVENT_TYPE_24:
                eventNumber = operatorLogin + now.toInstant().toEpochMilli();
                break;
            case EVENT_TYPE_118:
            case EVENT_TYPE_119:
                eventNumber = r.getEventNumber1();
                docs = EVENT_TYPE_118.equals(eventType) ? DOCS_AD014 : DOCS_AD014 + ";" + DOCS_AD001;
                bcd = String.join(FREE_FORMAT_SEPARATOR,
                        isDigitalDocument ? "" : r.getBarcode1(),
                        DOCS_AD014,
                        isDigitalDocument ? MARKER_WAS_ESIGNING : MARKER_WAS_NOT_ESIGNING);
                break;
            case EVENT_TYPE_100:
                eventNumber = r.getEventNumber2();
                isDigitalDocument = false;
                docs = DOCS_AD020;
                bcd = String.join(FREE_FORMAT_SEPARATOR,
                        r.getBarcode2(),
                        DOCS_AD020,
                        MARKER_WAS_NOT_ESIGNING);
                break;
            default:
                eventNumber = null;
        }

        String additionalInfo = "";
        if (EVENT_TYPE_118.equals(eventType) || EVENT_TYPE_119.equals(eventType) || EVENT_TYPE_100.equals(eventType)) {
            additionalInfo = "<docs>" + docs + "</docs>" +
                    "<bcd>" + bcd + "</bcd>" +
                    "<opId>" + eventNumber + "</opId>" +
                    "<extSysCode>" + freeFormatExtSysCode + "</extSysCode>" +
                    "<eDoc>" + isDigitalDocument + "</eDoc>";
        }

        Employee employee = adApiRepository.getEmployee(operatorLogin);

        String freeFormat =
                "<m>" +
                        "<ga>" + r.getEand() + "</ga>" +
                        "<dpType>" + r.getDlp() + "</dpType>" +
                        "<accType>" + ACC_TYPE + "</accType>" +
                        "<fio>" + employee.getDisplayName() + "</fio>" +
                        "<operatorPosition>" + employee.getTitle() + "</operatorPosition>" +
                        "<mc>" + eventType + "</mc>" +
                        additionalInfo +
                        "</m>";

        return Event.builder()
                .callingTime(now)
                .channelId(channelId)
                .customerPinEq(r.getEqId())
                .dealID(r.getBrnm() + r.getDlp() + r.getDlr())
                .eventNumber(eventNumber)
                .managerId(operatorLogin)
                .masterSys(eventType.equals(EVENT_TYPE_24) ? masterSys24 : masterSys)
                .operatorId(operatorLogin)
                .salePointId(r.getUserBranch())
                .sourceId(eventType.equals(EVENT_TYPE_24) ? externalSys24 : externalSys)
                .startTime(now)
                .time(now)
                .type(eventType)
                .freeFormat(freeFormat)
                .build();
    }

    public Event getEventRefillDeposit(String cus, String opLogin, DepositRefillInData in) {
        final Timestamp now = Timestamp.now();
        return Event.builder()
                .callingTime(now)
                .channelId(depositRefillParams.getChannelId())
                .customerPinEq(cus)
                .dealID(in.getBrnm() + in.getDlp() + in.getDlr())
                .eventNumber(opLogin + System.currentTimeMillis())
                .freeFormat(refillDepositFreeFormat(new String(Base64.getDecoder().decode(in.getExpressAccount())),
                        opLogin))
                .managerId(opLogin)
                .masterSys(depositRefillParams.getMasterSys())
                .operatorId(opLogin)
                .salePointId(in.getUserBranch())
                .sourceId(depositRefillParams.getSourceId())
                .startTime(now)
                .time(now)
                .type(depositRefillParams.getEventType())
                .build();
    }

    public Event getAutoProlongationDepositEvent(AutoProlongationRequest request) {
        final Timestamp now = Timestamp.now();
        return Event.builder()
                .callingTime(now)
                .channelId(depositAutoProlongationParams.getChannelId())
                .customerPinEq(request.getEqId())
                .dealID(request.getBranch() + request.getDepositType() + request.getDepositNumber())
                .eventNumber(request.getOperatorLogin() + System.currentTimeMillis())
                .freeFormat(getAutoProlongationDepositFreeFormat(
                        request.getOperatorLogin(),
                        request.getExpressAccNum()))
                .managerId(request.getOperatorLogin())
                .masterSys(depositAutoProlongationParams.getMasterSys())
                .operatorId(request.getOperatorLogin())
                .salePointId(request.getUserBranch())
                .sourceId(depositAutoProlongationParams.getSourceId())
                .startTime(now)
                .time(now)
                .type(depositAutoProlongationParams.getFreeFormatMap().get(Constants.EVENT_TYPE_KEY))
                .build();
    }

    private String getAutoProlongationDepositFreeFormat(String operatorLogin,
                                                        String expressAccount) {
        Employee employee = adApiRepository.getEmployee(operatorLogin);

        return "<m>" +
                "<ga>" + new String(Base64.getDecoder().decode(expressAccount)) + "</ga>" +
                "<accType>" + depositAutoProlongationParams.getFreeFormatMap().get("accType") + "</accType>" +
                "<fio>" + employee.getDisplayName() + "</fio>" +
                "<operatorPosition>" + employee.getTitle() + "</operatorPosition>" +
                "<mc>" + depositAutoProlongationParams.getFreeFormatMap().get(Constants.EVENT_TYPE_KEY) + "</mc>" +
                "</m>";
    }

    private String refillDepositFreeFormat(String expressAccount, String opLogin) {
        Employee employee = adApiRepository.getEmployee(opLogin);

        return "<m>" +
                "<ga>" + expressAccount + "</ga>" +
                "<accType>" + depositRefillParams.getFreeFormatAccType() + "</accType>" +
                "<fio>" + employee.getDisplayName() + "</fio>" +
                "<operatorPosition>" + employee.getTitle() + "</operatorPosition>" +
                "<mc>" + depositRefillParams.getFreeFormatMc() + "</mc>" +
                "</m>";
    }

    public Event getEventDepositClaim(DepositClaimRequest request, String eventType) {
        final Timestamp now = Timestamp.now();
        String eventNumber;
        String freeFormat;
        String type = getType(request.getNeedDULScan(), eventType);
        switch (eventType) {
            case FIRST_EVENT:
                log.info("depositClaimRequest is {}, PARTIAL_DEMAND_DEPOSIT event creating", request);
                eventNumber = request.getEventNumber() + now.toInstant().toEpochMilli();
                freeFormat = depositClaimFreeFormat(request.getEand(), PARTIAL_DEMAND_DEPOSIT);
                break;
            case SECOND_EVENT:
                log.info("depositClaimRequest is {}, PARTIAL_DEPOSIT_CLAIM_WITH_DUL event creating", request);
                eventNumber = StringUtils.isBlank(request.getEventNumber())
                        ? generateAppId(type, request.getOperatorLogin()) :
                        request.getEventNumber();
                freeFormat = depositClaimFreeFormat(
                        request.getOperatorLogin(),
                        request.getNeedDULScan(),
                        request.getEventNumber(),
                        request.getWasESigning(),
                        request.getEand(),
                        request.getBarcode());
                break;
            default:
                throw new IllegalArgumentException(eventType + " doesn't exist");
        }

        Event event = Event.builder()
                .callingTime(now)
                .channelId(depositClaimParams.getChannelId())
                .customerPinEq(request.getEqId())
                .dealID(request.getBranch() + request.getDepositType() + request.getDepositNumber()) //brnm + dlp + dlr
                .eventNumber(eventNumber)
                .freeFormat(freeFormat)
                .managerId(request.getOperatorLogin())
                .masterSys(depositClaimParams.getMasterSys())
                .operatorId(request.getOperatorLogin())
                .salePointId(request.getUserBranch())
                .sourceId(depositClaimParams.getSourceId())
                .startTime(now)
                .time(now)
                .type(type)
                .build();

        log.info("event {}, request is {}, eventType is {}", event, request, eventType);
        return event;
    }

    private String depositClaimFreeFormat(String operatorLogin,
                                          String needDULScan,
                                          String eventNumber,
                                          String wasESigning,
                                          String eand,
                                          String barcode) {
        Employee employee = adApiRepository.getEmployee(operatorLogin);

        return "<m>" +
                "<ga>" + eand + "</ga>" +
                "<accType>" + depositClaimParams.getFreeFormatAccType() + "</accType>" +
                "<fio>" + employee.getDisplayName() + "</fio>" +
                "<operatorPosition>" + employee.getTitle() + "</operatorPosition>" +
                "<mc>" + getType(needDULScan, SECOND_EVENT) + "</mc>" +
                "<docs>" + getFreeFormatDocs(needDULScan) + "</docs>" + // AD016->neddDoolScan N; AD001 -> Y
                "<bcd>" + getFreeFormatBcd(barcode, wasESigning) + "</bcd>" +
                "<opId>" + eventNumber + "</opId>" +
                "<eDoc>" + getFreeFormatEDoc(wasESigning) + "</eDoc>" +
                "<extSysCode>" + depositClaimParams.getFreeFormatExtSysCode() + "</extSysCode>" +
                "</m>";
    }

    private String depositClaimFreeFormat(String eand, String eventType) {
        return "<m>" +
                "<ga>" + eand + "</ga>" +
                "<mc>" + depositClaimParams.getEventTypes().get(eventType).toString() + "</mc>" +
                "</m>";
    }


    private String getFreeFormatDocs(String needDULScan) {
        return Constants.N.equalsIgnoreCase(needDULScan)
                ? depositClaimParams.getFreeFormatDocs().get(needDULScan)
                : String.join(SEMICOLON_DELIMITER, depositClaimParams.getFreeFormatDocs().values());//todo
    }

    private String getType(String needDULScan, String eventNumber) {
        String type = null;
        if (FIRST_EVENT.equals(eventNumber)) {
            type = depositClaimParams.getEventTypes().get(PARTIAL_DEMAND_DEPOSIT).toString();
        }
        if (SECOND_EVENT.equals(eventNumber)) {
            type = Constants.Y.equalsIgnoreCase(needDULScan)
                    ? depositClaimParams.getEventTypes().get(PARTIAL_DEPOSIT_CLAIM_WITH_DUL).toString()
                    : depositClaimParams.getEventTypes().get(PARTIAL_DEPOSIT_CLAIM_WITHOUT_DUL).toString();
        }
        return type;
    }

    private String getFreeFormatEDoc(String wasESigning) {
        return Constants.Y.equalsIgnoreCase(wasESigning) ? Boolean.TRUE.toString() : Boolean.FALSE.toString();
    }

    private String getFreeFormatBcd(String barcode, String wasESigning) {
        return String.join(FREE_FORMAT_SEPARATOR, barcode, depositClaimParams.getFreeFormatDocs().get(N),
                Constants.Y.equalsIgnoreCase(wasESigning) ? MARKER_WAS_ESIGNING : MARKER_WAS_NOT_ESIGNING);
    }

    public String generateAppId(String docType, String operatorLogin) {
        String result = docType + operatorLogin + String.valueOf(System.currentTimeMillis());
        return result.length() > MAX_APP_ID_SIZE ? result.substring(0, MAX_APP_ID_SIZE) : result;
    }


}
