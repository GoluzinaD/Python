package ru.alfabank.ufr.deposit.api.repository.opened;

import lombok.RequiredArgsConstructor;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.springframework.stereotype.Repository;
import ru.alfabank.ufr.deposit.api.entity.rest.OpenedDepositDetails;
import ru.alfabank.ws.cs.eq.wsstatementdepositinfo14.WSStatementDepositInfo14PortType;
import ru.alfabank.ws.cs.eq.wsstatementdepositinfo14.hystrix.WsStatementDepositInfoGetCmd;
import ru.alfabank.ws.cs.eq.wsstatementdepositinfoinoutparms14.WSStatementDepositInfoGetInParms;
import ru.alfabank.ws.cs.eq.wsstatementdepositinfoinoutparms14.WSStatementDepositInfoGetOutParms;
import ru.alfabank.ws.cs.wscommontypes10.WSCommonParms;

@Repository
@RequiredArgsConstructor
public class OpenedDepositSOAPRepository implements OpenedDepositRepository {
    private final WSCommonParms commonParms;
    private final WSStatementDepositInfo14PortType portType;
    private final SOAPResponseToDepositDetails outputMapper;
    private final SOAPInputMapper inputMapper;

    @Mapper(componentModel = "spring")
    public interface SOAPResponseToDepositDetails {
        @Mappings({
            @Mapping(source = "out.resultSet", target = "accrual"),
            @Mapping(source = "out.resultSet.resultSetRow", target = "accrual.graphic"),
        })
        OpenedDepositDetails convert(WSStatementDepositInfoGetOutParms out);
    }

    @Mapper(componentModel = "spring")
    public interface SOAPInputMapper {
        WSStatementDepositInfoGetInParms build(String brnm, String dlp, String dlr, String xm, String lnm);
    }

    @Override
    public OpenedDepositDetails getDetails(String bnm, String dlp, String dlr, String xm, String lnm) {
        WsStatementDepositInfoGetCmd statementDepositInfoGetCmd = new WsStatementDepositInfoGetCmd(portType)
                .setInCommonParms(commonParms)
                .setInParms(inputMapper.build(bnm, dlp, dlr, xm, lnm));
        try {
            return outputMapper.convert(statementDepositInfoGetCmd.execute().getOutParms());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}