package ru.alfabank.ufr.deposit.api.entity.exceptions;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.extern.slf4j.Slf4j;

@Data
@Slf4j
@EqualsAndHashCode(callSuper = false)
public class NoSuchObjectResponseApiException extends RuntimeException {
    public NoSuchObjectResponseApiException(String message) {
        super(message);
    }
}
