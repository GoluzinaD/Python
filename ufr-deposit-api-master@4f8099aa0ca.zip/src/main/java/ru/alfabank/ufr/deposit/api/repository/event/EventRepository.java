package ru.alfabank.ufr.deposit.api.repository.event;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import ru.alfabank.ufr.deposit.api.configuration.FeignClientConfiguration;

@FeignClient(name = "code-business-event", url = "${interaction.event.url}", configuration = FeignClientConfiguration.class)
public interface EventRepository {
    @PostMapping(value = "${interaction.event.add}")
    Event createEvent(Event event);
}