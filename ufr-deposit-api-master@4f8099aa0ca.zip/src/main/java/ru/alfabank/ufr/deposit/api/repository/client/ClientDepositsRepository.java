package ru.alfabank.ufr.deposit.api.repository.client;

import ru.alfabank.ufr.deposit.api.entity.rest.DepositCreateInData;
import ru.alfabank.ufr.deposit.api.entity.rest.DepositCreateOutData;
import ru.alfabank.ufr.deposit.api.entity.rest.FetchedProducts;

public interface ClientDepositsRepository {
    FetchedProducts getClientDeposits(String clientId, String channelCode, String languageMnemonic);
    DepositCreateOutData createDeposit(DepositCreateInData inData);
}
