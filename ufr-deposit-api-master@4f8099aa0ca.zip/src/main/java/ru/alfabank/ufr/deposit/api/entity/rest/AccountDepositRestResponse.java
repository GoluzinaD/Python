package ru.alfabank.ufr.deposit.api.entity.rest;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.experimental.Accessors;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Data
@Accessors(chain = true)
@JsonInclude(JsonInclude.Include.ALWAYS)
@XmlRootElement(name = "resultSet")
@XmlAccessorType(XmlAccessType.FIELD)
public class AccountDepositRestResponse {

    @Data
    @Accessors(chain = true)
    @JsonInclude(JsonInclude.Include.ALWAYS)
    @XmlAccessorType(XmlAccessType.FIELD)
    public static class AccountDepositFromRestApi {
        private String osbrnm;
        private String osdlp;
        private String osdlr;
        private String neeandeposit;
        private String v5abd;
        private String v5and;
        private String v5asd;
        private String v5ccy;
        private BigDecimal c8pwd;
        private String neeanpercent;
        private String v5abi;
        private String v5ani;
        private String v5asi;
        private BigDecimal osctrd;
        private String dll;
        private Date dataopen;
        private Date dataopennext;
        private Date dend;
        private String v5prc;
        private String v5rddy;
        private String term;
        private int factday;
        private String v5arc;
        private String isclosed;
        private BigDecimal dla2;
        private BigDecimal v5bal;
        private BigDecimal v5am1;
        private BigDecimal finres;
        private String cpi;
        private String prol;
        private String islre;
        private BigDecimal v5rat;
        private BigDecimal totalint;
        private BigDecimal brat;
        private BigDecimal drat;
        private String obdealname;
        private String hbdealname;
        private String productname;
        private String nm1full;
        private String nm2add;
        private String dcustomername;
    }

    @XmlElement(name = "resultSetRow")
    private List<AccountDepositFromRestApi> resultSetRow = new ArrayList<>();
}

