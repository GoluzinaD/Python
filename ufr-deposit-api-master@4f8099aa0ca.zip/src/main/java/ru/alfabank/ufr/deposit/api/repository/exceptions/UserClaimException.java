package ru.alfabank.ufr.deposit.api.repository.exceptions;

import lombok.Getter;

public class UserClaimException extends WebServiceException {
    @Getter
    private final String clientId;

    public UserClaimException(String clientId, Throwable cause) {
        super(cause);
        this.clientId = clientId;
    }
}