package ru.alfabank.ufr.deposit.api.utils;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.util.stream.Stream;

public class OneOfValidator implements ConstraintValidator<OneOf, String> {
    private String[] allowed = {};

    @Override
    public void initialize(OneOf constraintAnnotation) {
        allowed = constraintAnnotation.allowed();
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        return Stream.of(allowed).anyMatch(a -> a.equals(value));
    }
}
