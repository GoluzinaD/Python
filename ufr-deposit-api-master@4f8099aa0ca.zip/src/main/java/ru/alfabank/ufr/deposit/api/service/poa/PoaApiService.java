package ru.alfabank.ufr.deposit.api.service.poa;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.alfabank.ufr.deposit.api.configuration.Constants;
import ru.alfabank.ufr.deposit.api.entity.exceptions.NoSuchObjectResponseApiException;
import ru.alfabank.ufr.deposit.api.entity.repository.poa.AggregatePoaDto;
import ru.alfabank.ufr.deposit.api.entity.repository.poa.FullPoaDto;
import ru.alfabank.ufr.deposit.api.entity.repository.poa.FullPoasResponse;
import ru.alfabank.ufr.deposit.api.entity.rest.poa.AccessType;
import ru.alfabank.ufr.deposit.api.entity.rest.poa.FullPoasResponseDto;
import ru.alfabank.ufr.deposit.api.entity.rest.poa.PoaResponse;
import ru.alfabank.ufr.deposit.api.messages.MessageCode;
import ru.alfabank.ufr.deposit.api.messages.MessageUtil;
import ru.alfabank.ufr.deposit.api.repository.session.FeignSessionApi;
import ru.alfabank.ufr.deposit.api.utils.DateTimeMapping;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class PoaApiService implements PoaService {
    private final FeignSessionApi feignSessionApi;
    private final DateTimeMapping dateTimeMapping;
    private final PoaMapper poaMapper;
    private final MessageUtil messageUtil;


    public PoaResponse getFullPoaResponse(String sessionId, AccessType accessType, String accountNumber) {
        log.info("sessionId is {}, accessType is {}, accountNumber is {}", sessionId, accessType, accountNumber);
        List<FullPoasResponse> fullPoaResponse = feignSessionApi.getSession(sessionId, Constants.POA_KEY_PARAMETER);
        log.info("sessionId is {}, accessType is {}, accountNumber is {}, fullPoaResponse is {}",
                sessionId, accessType, accountNumber, fullPoaResponse);
        List<FullPoaDto> fullPoaDtos = fullPoaResponse
                .stream()
                .filter(fullPoasResponse -> Constants.POA_KEY_PARAMETER.equals(fullPoasResponse.getName()))
                .flatMap(fullPoasResponse -> fullPoasResponse.getValue().stream())
                .collect(Collectors.toList());

        log.info("sessionId is {}, accessType is {}, accountNumber is {}, fullPoaDtos is {}",
                sessionId, accessType, accountNumber, fullPoaDtos);

        FullPoasResponseDto fullPoasResponseDto = poaMapper.getFullPoasResponseDto(fullPoaDtos, accountNumber);
        log.info("sessionId is {}, accessType is {}, accountNumber is {}, fullPoasResponseDto is {}",
                sessionId, accessType, accountNumber, fullPoasResponseDto);
        PoaResponse powerOfAttorney = accessType.getPowerOfAttorney(fullPoasResponseDto);
        log.info("sessionId is {}, accessType is {}, accountNumber is {}, powerOfAttorney is {}",
                sessionId, accessType, accountNumber, powerOfAttorney);
        return powerOfAttorney;
    }


    private boolean isActingPoa(FullPoaDto fullPoaDto) { //not using now
        LocalDate now = LocalDate.now();
        AggregatePoaDto aggregatePoa = Optional.ofNullable(fullPoaDto.getAggregatePoa())
                .orElseThrow(() ->
                        new NoSuchObjectResponseApiException(messageUtil.getMessage(
                                MessageCode.SESSION_API_REPOSITORY_FULL_POA_DTO.getDescription())));

        String startDate = Optional.ofNullable(aggregatePoa.getPoaStartDate())
                .orElseThrow(() -> new NoSuchObjectResponseApiException(messageUtil.getMessage(
                        MessageCode.SESSION_API_REPOSITORY_AGGREGATE_POA_START_DATE.getDescription())));

        String expireDate = Optional.ofNullable(aggregatePoa.getPoaExpiryDate())
                .orElseThrow(() -> new NoSuchObjectResponseApiException(messageUtil.getMessage(
                        MessageCode.SESSION_API_REPOSITORY_AGGREGATE_POA_EXPIRY_DATE.getDescription())));

        return now.isAfter(dateTimeMapping.convertStringToLocalDate(startDate))
                && now.isBefore(dateTimeMapping.convertStringToLocalDate(expireDate));
    }

}



