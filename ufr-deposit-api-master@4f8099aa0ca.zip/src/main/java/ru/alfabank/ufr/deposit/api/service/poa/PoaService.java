package ru.alfabank.ufr.deposit.api.service.poa;

import ru.alfabank.ufr.deposit.api.entity.rest.poa.AccessType;
import ru.alfabank.ufr.deposit.api.entity.rest.poa.PoaResponse;

public interface PoaService {
    PoaResponse getFullPoaResponse(String sessionId, AccessType accessType, String accountNumber);
}
