package ru.alfabank.ufr.deposit.api.entity.repository.poa;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.Parameter;
import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.Size;

@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ElementaryPoaDto {
    @Size(max=20)
    @Parameter(description = "Номер счета.")
    private String accountNoExt;

    @Size(max=500)
    @Parameter(description = "Информационное сообщение (комментарий).")
    private String comments;

    @Size(max=15)
    @Parameter(description = "Идентификатор пластика .")
    private String plasticId;

    @Parameter(description = "Дополнительная информация о элементарной доверенности.")
    private OtherDetailsDto otherDetails;
}