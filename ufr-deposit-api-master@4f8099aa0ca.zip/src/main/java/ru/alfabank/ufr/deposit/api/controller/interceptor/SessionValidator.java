package ru.alfabank.ufr.deposit.api.controller.interceptor;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.AsyncHandlerInterceptor;
import ru.alfabank.ufr.deposit.api.configuration.SessionHeadersNames;
import ru.alfabank.ufr.deposit.api.entity.rest.BodyWithMessage;
import ru.alfabank.ufr.deposit.api.entity.rest.SessionDto;
import ru.alfabank.ufr.deposit.api.entity.rest.SessionStatusDto;
import ru.alfabank.ufr.deposit.api.repository.session.SessionRepository;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Optional;

@Slf4j
@Component
@RequiredArgsConstructor
public class SessionValidator implements AsyncHandlerInterceptor {
    private static final String CALLER_ID_SESSION_CHECK_EXCLUSION = "os";
    private final SessionHeadersNames sessionHeadersNames;
    private final SessionApiDTOConverter mapper;
    private final SessionRepository sessionRepository;

    public static class SessionValiationException extends RuntimeException {
        public SessionValiationException(String msg) { super(msg); }
        public SessionValiationException(Throwable cause) { super(cause); }
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {
        if (!(handler instanceof HandlerMethod)) {
            return true;
        }
        final String methodName = ((HandlerMethod)handler).getMethod().getName();
        switch(methodName) {
            case "createDeposit":
            case "closeDeposit":
            case "refillDeposit":
                return validateSession(request, response);
            default: return true;
        }
    }

    private boolean validateSession(HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        try {
            final String sessionToken = retrieveHeaderValue(request, sessionHeadersNames.getSessionToken());
            final String eqId = retrieveHeaderValue(request, sessionHeadersNames.getEqId());
            final String operatorLogin = retrieveHeaderValue(request, sessionHeadersNames.getOperatorLogin());
            final String callerId = request.getHeader(sessionHeadersNames.getCallerId());
            final SessionCheckResult sessionValidation = checkSessionIsValid(eqId, operatorLogin, sessionToken, callerId);
            if (sessionValidation.getSessionState() != SessionCheckResult.SessionState.SESSION_EXISTS) {
                throw new SessionValiationException("Invalid session state:" + sessionValidation.getSessionState().name());
            }
            return true;
        } catch (SessionValiationException e) {
            response.setStatus(HttpStatus.BAD_REQUEST.value());
            response.getWriter().write(new ObjectMapper().writeValueAsString(new BodyWithMessage().setMsg(
                    "Session validation not passed. " + e.getMessage())));
            return false;
        }
    }

    private String retrieveHeaderValue(HttpServletRequest request, String headerName) throws SessionValiationException {
        Optional<String> header = Optional.ofNullable(request.getHeader(headerName));
        header.orElseThrow(() -> new SessionValiationException("Required session header not found: " + headerName));
        return header.get();
    }

    @Data
    protected static class SessionCheckResult {
        public enum SessionState {
            SESSION_EXISTS,
            SESSION_NOT_EXISTS,
            ANOTHER_SESSION_EXISTS,
            SESSION_EXPIRED,
            SESSION_CLOSED
        }
        private SessionState sessionState;
        private String customMessage;
    }

    private SessionCheckResult checkSessionIsValid(String eqId, String operatorLogin, String sessionToken, String callerId) {
        if (CALLER_ID_SESSION_CHECK_EXCLUSION.equals(callerId)) {
            SessionCheckResult sessionCheckResult = new SessionCheckResult();
            sessionCheckResult.setSessionState(SessionCheckResult.SessionState.SESSION_EXISTS);
            return sessionCheckResult;
        }
        try {
            return mapper.convertCheckResult(sessionRepository.checkSession(
                    SessionDto.builder().eqId(eqId).operatorLogin(operatorLogin).token(sessionToken).build()));
        } catch(Exception e) {
            throw new SessionValidator.SessionValiationException(e);
        }
    }

    @Mapper(componentModel = "spring")
    public interface SessionApiDTOConverter {
        @Mappings({
                @Mapping(target = "sessionState", source = "status.status")
        })
        SessionCheckResult convertCheckResult(SessionStatusDto status);
    }
}