package ru.alfabank.ufr.deposit.api.repository.variants;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;
import ru.alfabank.api.deposit.rates.DepositRate;
import ru.alfabank.api.deposit.rates.DepositRatesGetCommandFactory;
import ru.alfabank.api.deposit.rates.DepositRatesGetRequest;
import ru.alfabank.api.deposit.rates.DepositRatesGetResponse;
import ru.alfabank.api.enums.BinOption;
import ru.alfabank.ufr.deposit.api.entity.rest.DepositInfo;
import ru.alfabank.ufr.deposit.api.entity.rest.DepositVariantsRequest;
import ru.alfabank.ws.cs.eq.wsdepositrates12.WSDepositRates12PortType;
import ru.alfabank.ws.cs.wscommontypes10.WSCommonParms;

import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository
public class DepositVariantsSOAPRepository implements DepositVariantsRepository {
    private final DepositRatesGetCommandFactory ratesGetCommandFactory;

    public DepositVariantsSOAPRepository(WSCommonParms commonParms, WSDepositRates12PortType portType,
                                         @Value("${hystrix.command.default.execution.isolation.thread.timeoutInMilliseconds}") int timeout) {
        this.ratesGetCommandFactory = new DepositRatesGetCommandFactory(commonParms, timeout, portType);
    }

    @Override
    public List<DepositInfo> getDepositVariantsOfType(DepositVariantsRequest variantsRequest) {
        DepositRatesGetRequest request = getRequest(variantsRequest);
        List<DepositRate> rates = Optional.ofNullable(ratesGetCommandFactory.getCommand(request).execute())
                .map(DepositRatesGetResponse::getDepositRates)
                .orElse(Collections.emptyList());

        return rates.stream()
                .map(rate -> new DepositInfo()
                        .setCcy(rate.getCurrencyMnemonic())
                        .setCcyn(rate.getCurrencyCode())
                        .setRnm(rate.getCurrencyName())
                        .setDll(rate.getDepositSortType())
                        .setDlp(rate.getDepositType())
                        .setNm1(rate.getDepositName())
                        .setNm2(rate.getDepositAdditionalInfo())
                        .setDname(rate.getDepositShortName())
                        .setPrc(rate.getPeriodCode())
                        .setPrd(rate.getPeriodName())
                        .setCpi(convertBooleanToString(rate.getIsCapitalizationAvailable()))
                        .setRol(convertBooleanToString(rate.getIsProlongationAvailable()))
                        .setChm(convertBooleanToString(rate.getIsEndDateChangeAvailable()))
                        .setChs(convertBooleanToString(rate.getIsOpenDateChangeAvailable()))
                        .setCrl(convertBooleanToString(rate.getIsProlongationChangeAvailable()))
                        .setCrt(convertBooleanToString(rate.getIsRateChangeAvailable()))
                        .setIfq(rate.getPercentFrequencyPayment())
                        .setBi(rate.getInterestAccrualAccount())
                        .setCdd(rate.getPeriodInDays())
                        .setMinama(rate.getMinOpenAmount())
                        .setMinsum(rate.getMinRefillAmount())
                        .setMaxsum(rate.getMaxRefillAmount())
                        .setBrat(rate.getBaseRate())
                        .setAct(rate.getPercentRecordAccount())
                        .setTax(rate.getCanTakeNDFL())
                        .setPdp(rate.getCanRefillInRefillDate())
                        .setVdp(rate.getCanPartialWithdrawInRefillDate())
                        .setVnp(rate.getCanPartialWithdraw())
                        .setPnp(convertBooleanToString(rate.getIsRefillAvailable()))
                        .setMaxday(rate.getMaximumDays())
                        .setDrat(rate.getBonusRate())
                        .setRat(rate.getTotalRate()))
                .collect(Collectors.toList());
    }

    private DepositRatesGetRequest getRequest(DepositVariantsRequest variantsRequest) {
        return DepositRatesGetRequest.builder()
                .clientType(variantsRequest.getCtp())
                .currency(variantsRequest.getCcy())
                .depositShortType(variantsRequest.getDll())
                .externalSystemCode(variantsRequest.getXm())
                .languageMnemonic(variantsRequest.getLnm())
                .clientPackageCode(variantsRequest.getPu())
                .hasMainAccount(StringUtils.isBlank(variantsRequest.getOsn())
                        ? Boolean.FALSE
                        : BinOption.YES.getCode().equalsIgnoreCase(variantsRequest.getOsn()))
                .depositOpenDate(variantsRequest.getStd() == null
                        ? null
                        : new SimpleDateFormat("yyyy-MM-dd").format(variantsRequest.getStd()))
                .depositType(variantsRequest.getDlp())
                .build();
    }

    private String convertBooleanToString(Boolean value) {
        return Boolean.TRUE.equals(value) ? BinOption.YES.getCode() : BinOption.NO.getCode();
    }
}