package ru.alfabank.ufr.deposit.api.entity.rest;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SessionDto {
    @NotBlank
    private String eqId;

    @NotBlank
    private String operatorLogin;

    @NotBlank
    private String token;
}