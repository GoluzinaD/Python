package ru.alfabank.ufr.deposit.api.entity.rest;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class DepositCloseValidationParams {
    // Процентная ставка досрочного расторжения
    private BigDecimal rat;
    // Сумма возвращаемых процентов
    private BigDecimal isum;
    // Сумма депозитной сделки
    private BigDecimal dsum;
    // Сумма возвращаемого налога
    private BigDecimal tsum;
    // 20-значный номер счета депозита
    private String eand;
    // 20-значный номер счета возврата налога
    private String eantx;
}
