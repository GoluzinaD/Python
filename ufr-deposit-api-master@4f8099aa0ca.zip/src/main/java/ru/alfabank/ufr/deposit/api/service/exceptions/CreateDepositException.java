package ru.alfabank.ufr.deposit.api.service.exceptions;

public class CreateDepositException extends RuntimeException {
    public CreateDepositException(Throwable e) {
        super(e);
    }
}
