package ru.alfabank.ufr.deposit.api.entity.rest;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class ProductClassification {
    // категория (
    private String category;
    // группа в категории (напр., накопительный счет для банк.счета, ПИФ для ДУ и т.д.)
    private String groupWithinCategory;
}
