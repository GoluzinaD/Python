package ru.alfabank.ufr.deposit.api.repository.exceptions;

public class UserNotFoundException extends UserRelatedException {
    public UserNotFoundException(String clientId, Throwable cause) {
        super(clientId, cause);
    }
}
