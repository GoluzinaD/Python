package ru.alfabank.ufr.deposit.api.configuration.moduleinfo;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ModuleInfoConfiguration {
    @Bean
    @ConfigurationProperties(prefix = "moduleinfo")
    public ModuleInfoProps moduleInfoProps() {
        return new ModuleInfoProps();
    }

    @Bean
    @ConfigurationProperties(prefix = "moduleinfoopendeposit")
    public ModuleInfoProps moduleInfoPropsOpenDeposit() {
        return new ModuleInfoProps();
    }
}
