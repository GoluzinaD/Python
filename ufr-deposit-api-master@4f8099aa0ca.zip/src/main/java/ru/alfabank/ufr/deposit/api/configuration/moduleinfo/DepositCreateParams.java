package ru.alfabank.ufr.deposit.api.configuration.moduleinfo;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Data
@Configuration
@ConfigurationProperties(prefix = "deposit.create")
public class DepositCreateParams {
    private SessionEvent sessionEvent;

    @Data
    public static class SessionEvent {
        private String eventType;
        private String customType;
    }
}
