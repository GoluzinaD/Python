package ru.alfabank.ufr.deposit.api.entity.rest.poa;

import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import ru.alfabank.ufr.deposit.api.configuration.Constants;
import ru.alfabank.ufr.deposit.api.entity.exceptions.NoSuchObjectResponseApiException;
import ru.alfabank.ufr.deposit.api.entity.repository.poa.*;
import ru.alfabank.ufr.deposit.api.messages.MessageCode;

import java.util.Collection;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Stream;

public enum AccessType {
    DEPOSIT_MODULE {
        @Override
        public PoaResponse getPowerOfAttorney(FullPoasResponseDto fullPoasResponseDto) {
            return getFullPoaDtoStream(fullPoasResponseDto)
                    .anyMatch(isGeneralPoaPredicate
                            .or(isAvailableDepositOperationPredicate)
                            .or(isAvailableOpenDepositToAnyAccountPredicate))
                    ? getAvailablePoaResponse(fullPoasResponseDto)
                    : getEmptyPoaResponse();
        }
    },
    DEPOSIT_OPEN {
        @Override
        public PoaResponse getPowerOfAttorney(FullPoasResponseDto fullPoasResponseDto) {
            if (StringUtils.isBlank(fullPoasResponseDto.getAccountNumber())) {
                return getFullPoaDtoStream(fullPoasResponseDto)
                        .anyMatch(isGeneralPoaPredicate.or(isAvailableOpenDepositToAnyAccountPredicate))
                        ? getAvailablePoaResponse(fullPoasResponseDto)
                        : getEmptyPoaResponse();
            } else {
                Stream<OperationDto> operationDtoStream = getOperationDtoStream(fullPoasResponseDto);
                return getFullPoaDtoStream(fullPoasResponseDto)
                        .anyMatch(isGeneralPoaPredicate)
                        || operationDtoStream
                        .anyMatch(isAvailableOpenDepositToAccountPredicate)
                        ? getAvailablePoaResponse(fullPoasResponseDto)
                        : getEmptyPoaResponse();
            }

        }
    },
    DEBT_ACC {
        @Override
        public PoaResponse getPowerOfAttorney(FullPoasResponseDto fullPoasResponseDto) {
            if (StringUtils.isBlank(fullPoasResponseDto.getAccountNumber())) {
                throw new IllegalArgumentException(MessageCode.POA_CONTROLLER_ACCOUNT_NUMBER.getDescription());
            }

            Stream<OperationDto> operationDtoStream = getOperationDtoStream(fullPoasResponseDto);
            return getFullPoaDtoStream(fullPoasResponseDto)
                    .anyMatch(isGeneralPoaPredicate)
                    || operationDtoStream
                    .anyMatch(isPossibleDebitAccount)
                    ? getAvailablePoaResponse(fullPoasResponseDto)
                    : getEmptyPoaResponse();


        }

    },
    ACCOUNT_OPEN {
        @Override
        public PoaResponse getPowerOfAttorney(FullPoasResponseDto fullPoasResponseDto) {
            return getFullPoaDtoStream(fullPoasResponseDto)
                    .anyMatch(isGeneralPoaPredicate)
                    ? getAvailablePoaResponse(fullPoasResponseDto)
                    : getEmptyPoaResponse();
        }
    };


    private static PoaResponse getAvailablePoaResponse(FullPoasResponseDto fullPoasResponseDto) {
        return PoaResponse.builder().poaResponse(fullPoasResponseDto).isAvailable(true).build();
    }

    private static PoaResponse getEmptyPoaResponse() {
        return PoaResponse.builder().poaResponse(FullPoasResponseDto.builder().build()).build();
    }

    private final static Predicate<FullPoaDto> isGeneralPoaPredicate;

    private final static Predicate<FullPoaDto> isAvailableDepositOperationPredicate;

    private final static Predicate<ElementaryPoaDto> isDepositPredicate;

    private final static Predicate<FullPoaDto> isAvailableOpenDepositToAnyAccountPredicate;

    private final static Predicate<OperationDto> isAvailableOpenDepositToAccountPredicate;

    private final static Predicate<OperationDto> isPossibleDebitAccount;


    static {
        isDepositPredicate = e -> Constants.DEPOSIT_CODE.equals(Optional.ofNullable(e.getOtherDetails())
                .orElseThrow(() -> new NoSuchObjectResponseApiException(
                        MessageCode.SESSION_API_REPOSITORY_ELEMENTARY_POA_DTO_OTHER_DETAILS
                                .getDescription()))
                .getCodeObjectType());

        isGeneralPoaPredicate = p ->
                BooleanUtils.toBoolean(Optional.ofNullable(p)
                        .map(FullPoaDto::getAggregatePoa)
                        .map(AggregatePoaDto::getIsGeneral)
                        .orElseThrow(() ->
                                new NoSuchObjectResponseApiException(
                                        MessageCode.SESSION_API_REPOSITORY_AGGREGATE_IS_GENERAL_FLAG
                                                .getDescription())));


        isAvailableDepositOperationPredicate = p ->
                Optional.ofNullable(p)
                        .map(FullPoaDto::getElementaryPoaList)
                        .orElseThrow(() -> new NoSuchObjectResponseApiException(
                                MessageCode.SESSION_API_REPOSITORY_ELEMENTARY_POA_LIST
                                        .getDescription()))
                        .stream()
                        .filter(Objects::nonNull)
                        .anyMatch(isDepositPredicate);

        isAvailableOpenDepositToAnyAccountPredicate = p ->
                getOperationDtoStream(p)
                        .anyMatch(operationDtos ->
                                Constants.AVAILABLE_OPEN_DEPOSIT_CODE.equals(operationDtos.getCodeOperationKind()));

        isAvailableOpenDepositToAccountPredicate =
                p ->
                        Constants.AVAILABLE_OPEN_DEPOSIT_CODE.equals(p.getCodeOperationKind());

        isPossibleDebitAccount =
                p ->
                        Constants.POSSIBLE_DEBIT_ACCOUNT_CODE.equals(p.getCodeOperationKind());


    }

    private static Stream<OperationDto> getOperationDtoStream(FullPoaDto p) {
        return Optional.ofNullable(p)
                .map(FullPoaDto::getElementaryPoaList)
                .orElseThrow(() -> new NoSuchObjectResponseApiException(
                        MessageCode.SESSION_API_REPOSITORY_FULL_POA_DTO
                                .getDescription()))
                .stream()
                .map(ElementaryPoaDto::getOtherDetails)
                .map(OtherDetailsDto::getOperationList)
                .flatMap(Collection::stream)
                .filter(Objects::nonNull);
    }

    private static Stream<OperationDto> getOperationDtoStream(FullPoasResponseDto fullPoasResponseDto) {
        return getFullPoaDtoStream(fullPoasResponseDto)
                .map(FullPoaDto::getElementaryPoaList)
                .flatMap(Collection::stream)
                .filter(elementaryPoaDto ->
                        elementaryPoaDto.getAccountNoExt().equals(fullPoasResponseDto.getAccountNumber()))
                .map(ElementaryPoaDto::getOtherDetails)
                .map(OtherDetailsDto::getOperationList)
                .flatMap(Collection::stream);
    }

    public abstract PoaResponse getPowerOfAttorney(FullPoasResponseDto fullPoasResponseDto);

    private static Stream<FullPoaDto> getFullPoaDtoStream(FullPoasResponseDto fullPoasResponseDto) {
        return Optional.ofNullable(fullPoasResponseDto)
                .map(FullPoasResponseDto::getFullPoaList)
                .orElseThrow(() ->
                        new NoSuchObjectResponseApiException(MessageCode.SESSION_API_REPOSITORY_FULL_POA
                                .getDescription()))
                .stream()
                .filter(Objects::nonNull);
    }
}
