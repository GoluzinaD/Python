package ru.alfabank.ufr.deposit.api.controller.interceptor;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.AsyncHandlerInterceptor;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Slf4j
@Component
@RequiredArgsConstructor
public class ModuleInfoCall implements AsyncHandlerInterceptor {
    private final Environment environment;
    @Value("#{'${moduleInfo.enabledOnProfiles}'.split(',')}")
    private List<String> enabledOnProfiles;
    private Set<String> activeProfiles;
    private Boolean isAllowedSpringProfile;

    @PostConstruct
    private void init() {
        isAllowedSpringProfile = new HashSet<>(enabledOnProfiles).containsAll(
                Stream.of(environment.getActiveProfiles()).collect(Collectors.toSet()));
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        final String methodName = ((HandlerMethod)handler).getMethod().getName();
        if ("getModuleInfo".equals(methodName)) {
            if (!isAllowedSpringProfile)
                throw new UnsupportedOperationException(String.format("Method call %s is restricted in active profile(s): %s. Allowed profiles: %s",
                        methodName, activeProfiles, enabledOnProfiles));
        }
        return true;
    }
}