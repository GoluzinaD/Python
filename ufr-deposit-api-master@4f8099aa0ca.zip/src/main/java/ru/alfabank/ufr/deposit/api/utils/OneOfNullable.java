package ru.alfabank.ufr.deposit.api.utils;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.*;

@Documented
@Constraint(validatedBy = OneOfNullableValidator.class)
@Target( { ElementType.METHOD, ElementType.FIELD })
@Retention(RetentionPolicy.RUNTIME)
public @interface OneOfNullable {
    String message() default "Value is not allowed";
    String[] allowed() default {};
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};
}
