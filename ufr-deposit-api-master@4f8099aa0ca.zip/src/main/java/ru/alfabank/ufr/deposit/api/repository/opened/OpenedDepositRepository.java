package ru.alfabank.ufr.deposit.api.repository.opened;

import ru.alfabank.ufr.deposit.api.entity.rest.OpenedDepositDetails;

public interface OpenedDepositRepository {
    OpenedDepositDetails getDetails(String bnm, String dlp, String dlr, String xm, String lnm);
}
