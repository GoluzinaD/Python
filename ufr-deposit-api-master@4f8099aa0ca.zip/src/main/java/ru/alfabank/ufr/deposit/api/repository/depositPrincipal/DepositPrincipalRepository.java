package ru.alfabank.ufr.deposit.api.repository.depositPrincipal;

import ru.alfabank.api.deposit.principal.DepositPrincipalAddResponse;
import ru.alfabank.ufr.deposit.api.entity.repository.depositPrincipal.DepositPrincipalClaimRequest;

public interface DepositPrincipalRepository {

    DepositPrincipalAddResponse claim(DepositPrincipalClaimRequest request);
}