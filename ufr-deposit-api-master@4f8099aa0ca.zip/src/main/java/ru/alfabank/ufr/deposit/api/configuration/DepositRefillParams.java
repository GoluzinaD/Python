package ru.alfabank.ufr.deposit.api.configuration;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "deposit.refill")
@Data
public class DepositRefillParams {
    private String channelId;
    private String freeFormatAccType;
    private String freeFormatMc;
    private String masterSys;
    private String sourceId;
    private String eventType;
    private String xm;
    private String lnm;
    private SessionEvent sessionEvent;

    @Data
    public static class SessionEvent {
        private String eventType;
        private String customType;
        private String commonDateFormat;
        private Constants.NumberGroupSeparator numberGroupSeparator;
        private Constants.NumberDecimalSeparator numberDecimalSeparator;
    }
}
