package ru.alfabank.ufr.deposit.api.entity.repository.autoProlongation.maintain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MaintainDepositRequestDto {
    private String userId;
    private String branchNumber;
    private String dlp;
    private String dlr;
    private String brnm;
    private Date mdt;
}
