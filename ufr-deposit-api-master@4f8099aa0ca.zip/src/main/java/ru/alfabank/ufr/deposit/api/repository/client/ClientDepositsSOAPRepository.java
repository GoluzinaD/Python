package ru.alfabank.ufr.deposit.api.repository.client;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;
import ru.alfabank.ufr.deposit.api.entity.rest.AccountDeposit;
import ru.alfabank.ufr.deposit.api.entity.rest.DepositCreateInData;
import ru.alfabank.ufr.deposit.api.entity.rest.DepositCreateOutData;
import ru.alfabank.ufr.deposit.api.entity.rest.FactoryDeposit;
import ru.alfabank.ufr.deposit.api.entity.rest.FetchedProducts;
import ru.alfabank.ufr.deposit.api.repository.exceptions.DepositsRecievingException;
import ru.alfabank.ufr.deposit.api.repository.exceptions.UserNotFoundException;
import ru.alfabank.ufr.deposit.api.utils.DateTimeMapping;
import ru.alfabank.ws.cs.eq.wsdeposit11.WSDepositPortType;
import ru.alfabank.ws.cs.eq.wsdeposit11.hystrix.WsDepositAddCmd;
import ru.alfabank.ws.cs.eq.wsdepositinoutparms11.WSDepositAddInParms;
import ru.alfabank.ws.cs.eq.wsdepositinoutparms11.WSDepositAddOutParms;
import ru.alfabank.ws.cs.eq.wsstatementdepositlist13.WSStatementDepositList13PortType;
import ru.alfabank.ws.cs.eq.wsstatementdepositlist13.WSStatementDepositListGetResponseType;
import ru.alfabank.ws.cs.eq.wsstatementdepositlist13.hystrix.WsStatementDepositListGetCmd;
import ru.alfabank.ws.cs.eq.wsstatementdepositlistinoutparms13.WSStatementDepositListGetInParms;
import ru.alfabank.ws.cs.wscommontypes10.WSCommonParms;

import javax.annotation.PostConstruct;
import javax.xml.ws.soap.SOAPFaultException;
import java.time.Instant;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static org.apache.commons.lang3.StringUtils.isBlank;

@Slf4j
@Repository
@RequiredArgsConstructor
public class ClientDepositsSOAPRepository implements ClientDepositsRepository {
    private final WSCommonParms commonParms;
    private final WSStatementDepositList13PortType depositList13PortType;
    private final WSDepositPortType depositOperatePortType;
    private final DepositCreateInDataMapper depositCreateInDataMapper;
    private final DepositCreateResultMapper depositCreateResultMapper;
    @Value("${logParams.inout:false}")
    private boolean logRecevied;
    private final ObjectMapper mapper = new ObjectMapper();

    @PostConstruct
    private void init () {
        log.info("Used {} as deposits repository", this.getClass().getCanonicalName());
    }

    @Override
    public FetchedProducts getClientDeposits(String clientId, String channelCode, String languageMnemonic) {
        FetchedProducts fetchedProducts = new FetchedProducts();

        try {
            List<AccountDeposit> clientDeposits = getClientAccountDeposits(clientId, channelCode, languageMnemonic);

            fetchedProducts.setFetchedAll(true);
            fetchedProducts.setFetchedProductList(clientDeposits);
            fetchedProducts.setTimestamp(Date.from(Instant.now()));
        } catch (Exception e) {
            handleException(clientId, e);
        }

        return fetchedProducts;
    }

    @Mapper(componentModel = "spring", uses = DateTimeMapping.class)
    public interface DepositCreateInDataMapper {
        @Mapping(source = "inData.sdt", target = "sdt", qualifiedByName = {"DateTimeMapping", "DateToLocalDate"})
        @Mapping(source = "inData.mdt", target = "mdt", qualifiedByName = {"DateTimeMapping", "DateToLocalDate"})
        WSDepositAddInParms convertToSOAPInput(DepositCreateInData inData);
    }

    @Mapper(componentModel = "spring")
    public interface DepositCreateResultMapper {
        @Mapping(source = "inData.dlr", target = "id")
        DepositCreateOutData build(WSDepositAddOutParms outParms, DepositCreateInData inData);
    }

    @Override
    public DepositCreateOutData createDeposit(DepositCreateInData inData) {
        WsDepositAddCmd depositAddCmd = new WsDepositAddCmd(depositOperatePortType)
                .setInCommonParms(commonParms)
                .setInParms(depositCreateInDataMapper.convertToSOAPInput(inData));

        final DepositCreateOutData out;
        try {
            out = depositCreateResultMapper.build(depositAddCmd.execute(), inData);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        if (isBlank(out.getEand())) {
            throw new RuntimeException("EAND field is missing");
        }
        out.setOperationDateTime(new Date());
        return out;
    }

    private List<AccountDeposit> getClientAccountDeposits(String clientId, String channelCode, String languageMnemonic) {
        WsStatementDepositListGetCmd depositListGetCmd = new WsStatementDepositListGetCmd(depositList13PortType)
                .setInCommonParms(commonParms)
                .setInParms(inParams(clientId, channelCode, languageMnemonic));
        WSStatementDepositListGetResponseType response = depositListGetCmd.execute();
        if(logRecevied) {
            response.getOutParms().getResultSet().getResultSetRow().forEach(e -> {
                try {
                    log.info("Received deposit: {}", mapper.writeValueAsString(e));
                } catch (JsonProcessingException e1) {
                    log.warn("Received deposit could not be parsed into json! ClientId: {}, deposit NEEAN: {}",
                            clientId, e.getNeean());
                }
            });
        }
        return response.getOutParms().getResultSet().getResultSetRow().stream()
                .map(FactoryDeposit::createFromSOAPResultSetRow)
                .collect(Collectors.toList());
    }

    private WSStatementDepositListGetInParms inParams(String clientId, String channelCode, String languageMnemonic) {
        WSStatementDepositListGetInParms params = new WSStatementDepositListGetInParms();

        params.setCus(clientId);

        Optional.ofNullable(channelCode)
                .ifPresent(params::setXm);
        Optional.ofNullable(languageMnemonic)
                .ifPresent(params::setLnm);

        return params;
    }

    private void handleException(String clientId, Exception e) {
        boolean isUserNotFoundException = e.toString().contains(DepositsRemoteRepositoryErrorCode.USER_NOT_FOUND.getCode());

        if (isUserNotFoundException) {
            handleUserNotFoundException(clientId, e);
        } else {
            handleDepositsReceivingException(clientId, e);
        }
    }

    private void handleUserNotFoundException(String clientId, Exception e) {
        log.info("Getting deposits for client {}: service says, client is unknown (error code {})",
                clientId, DepositsRemoteRepositoryErrorCode.USER_NOT_FOUND.getCode());

        throw new UserNotFoundException(clientId, e);
    }

    private void handleDepositsReceivingException(String clientId, Exception e) {
        String logMessageTemplate = e instanceof SOAPFaultException
                ? "Getting deposits for client {}: SOAPFault exception occurs: {}"
                : "Getting deposits for client {}: exception occurs: {}";

        log.error(logMessageTemplate, clientId, e.toString());

        throw new DepositsRecievingException(clientId, e);
    }
}
