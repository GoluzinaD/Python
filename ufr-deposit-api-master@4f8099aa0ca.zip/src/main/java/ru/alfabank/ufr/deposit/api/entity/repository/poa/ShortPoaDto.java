package ru.alfabank.ufr.deposit.api.entity.repository.poa;

import io.swagger.v3.oas.annotations.Parameter;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ShortPoaDto {
    @Parameter(description = "Основная информация о доверенности.")
    private AggregatePoaDto aggregatePoa;

    @Parameter(description = "Информация о доверителе и доверенном лице, зафиксированных в рамках доверенности")
    private TrustedRelationDto trustedRelation;

    @Parameter(description = "Информация о типе и виде доверенности")
    private TypeKindDto typeKind;
}