package ru.alfabank.ufr.deposit.api.utils;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;

@Component
public class UriResolver {
    @Value("${interaction.clientDepositsApi.rest.baseUri}")
    private String baseUri;
    @Value("${interaction.clientDepositsApi.rest.servicePath}")
    private String servicePath;
    public URI uriDepositsRestApi(String clientId) {
        return UriComponentsBuilder.fromUriString(baseUri)
                .pathSegment(servicePath)
                .queryParam("cus", clientId)
                .build()
                .toUri();
    }
}
