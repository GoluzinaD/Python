package ru.alfabank.ufr.deposit.api.controller.deposit;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.alfabank.ufr.deposit.api.entity.rest.AvailableDepositTypes;
import ru.alfabank.ufr.deposit.api.entity.rest.DepositInfo;
import ru.alfabank.ufr.deposit.api.entity.rest.DepositVariantsRequest;
import ru.alfabank.ufr.deposit.api.service.DepositService;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import java.util.List;

@Slf4j
@CrossOrigin
@RestController
@RequestMapping(value = "deposit")
@RequiredArgsConstructor
@RestControllerAdvice
public class AllDepositsController {
    private final DepositService depositService;

    @GetMapping(path = "/available-types", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<AvailableDepositTypes> getAllDepositTypes(
            @Valid @NotBlank @RequestParam(name = "ctp", required = false, defaultValue = "${defaults.ctp}") String clientType,
            @Valid @NotBlank @RequestParam(name = "ccy") String[] depositCurrencies,
            @Valid @NotBlank @RequestParam(name = "pu") String servicePackageCode,
            @Valid @NotBlank @RequestParam(name = "osn") String mainAccountOpened) {
        return ResponseEntity.ok(depositService.getAllAvailableDepositTypes(clientType, depositCurrencies, servicePackageCode,
                mainAccountOpened));
    }

    @GetMapping(path = "/variants", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<DepositInfo>> getDepositVariants(@Valid DepositVariantsRequest request) {
        return ResponseEntity.ok(depositService.getDepositVariants(request));
    }
}