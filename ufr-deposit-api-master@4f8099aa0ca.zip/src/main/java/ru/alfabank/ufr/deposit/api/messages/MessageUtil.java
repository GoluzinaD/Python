package ru.alfabank.ufr.deposit.api.messages;

import lombok.RequiredArgsConstructor;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import ru.alfabank.ufr.deposit.api.configuration.Constants;

@Service
@RequiredArgsConstructor
public class MessageUtil {
    private final MessageSource messageSource;

    public String getMessage(String messages, Object ... objects){
        return  messageSource.getMessage(messages, objects, Constants.LOCALE_RU);
    }
}
