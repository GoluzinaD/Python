package ru.alfabank.ufr.deposit.api.entity.rest.moduleinfo;

import lombok.Data;
import lombok.experimental.Accessors;
import org.springframework.beans.factory.annotation.Value;

import java.util.List;

import static java.util.Collections.emptyList;

@Data
@Accessors(chain = true)
public class ModuleDto {

    @Value("${moduleInfo.module.id}")
    private String id;
    private String name;
    private String path;
    private String description;
    private String icon;
    private Boolean available;
    private List<ModuleOperationsDto> operations;
    private List<String> bans = emptyList();
}
