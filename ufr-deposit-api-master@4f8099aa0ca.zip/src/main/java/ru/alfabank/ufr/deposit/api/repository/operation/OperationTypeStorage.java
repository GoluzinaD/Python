package ru.alfabank.ufr.deposit.api.repository.operation;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Repository;
import ru.alfabank.ufr.deposit.api.entity.repository.operation.OperationType;

import static org.springframework.data.mongodb.core.query.Query.query;

@Slf4j
@Repository
@RequiredArgsConstructor
public class OperationTypeStorage implements OperationTypeGetter {
    private final MongoTemplate mongoTemplate;
    @Value("${operationTypeCollectionName}")
    private String operationTypeCollectionName;

    @Override
    public OperationType getOperationType(String eventType) {
        log.info("Getting OperationType from {} collection with eventType(_id) {}", operationTypeCollectionName, eventType);
        return mongoTemplate.findOne(query(Criteria.where("_id").is(eventType)), OperationType.class, operationTypeCollectionName);
    }
}
