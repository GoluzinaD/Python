package ru.alfabank.ufr.deposit.api.entity.rest;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class DepositCloseInData {
    private String eqId;
    private String operatorLogin;
    private String userBranch;
    private String brnm;
    private String dlp;
    private String dlr;
    private String tax;
    private String eand;
    private String wasSecondDoc;
    private String barcode1;
    private String barcode2;
    private String wasESigning;
    private String eventNumber1;
    private String eventNumber2;
    private String needDULScan;
    private String workflow;
    private Boolean shouldSkipCreateEvent;
}
