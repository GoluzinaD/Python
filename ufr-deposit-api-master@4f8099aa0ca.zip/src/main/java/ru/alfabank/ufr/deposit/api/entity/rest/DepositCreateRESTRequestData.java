package ru.alfabank.ufr.deposit.api.entity.rest;

import io.swagger.v3.oas.annotations.Parameter;
import lombok.Data;
import lombok.EqualsAndHashCode;
import ru.alfabank.ufr.deposit.api.entity.rest.session.SessionAbstractRequest;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Date;

@Data
@EqualsAndHashCode(callSuper = true)
public class DepositCreateRESTRequestData extends SessionAbstractRequest {
    @Parameter(description = "Тип сделки\n" +
            "\n" +
            "Заполняется значением выходного параметра <dlp> функции Получение информации по депозиту.", example = "V06")
    @NotBlank
    private String dlp;

    @Parameter(description = "Мнемоника отделения пользователя.\n" +
            "\n" +
            "Для получения мнемоники используется микросервис ufr-ad-api (метод api/employees/{username}, выходной параметр eqMnemonic).",
            example = "MOPV")
    @NotBlank
    private String brnm;

    @Parameter(description = "Мнемоника валюты сделки\n" +
            "\n" +
            "Заполняется значением поля Валюта формы Оформление депозита.",
            example = "RUR")
    @NotBlank
    private String ccy;

    @Parameter(description = "Сумма сделки\n" +
            "\n" +
            "Заполняется значением поля Сумма формы Оформление депозита.\n" +
            "\n" +
            "Передается значение в минорных единицах (копейках).",
            example = "1111000")
    @NotNull
    private BigDecimal dla;

    @Parameter(description = "Дата старта сделки\n" +
            "\n" +
            "Заполняется значением текущей системной даты.")
    @NotNull
    private Date sdt;

    @Parameter(description = "Срок депозита в днях. \n" +
            "    Если на форме Оформление депозита в поле Срок значение НЕ введено вручную (выбрано из списка) – заполняется значением выходного параметра <cdd> функции Получение информации по депозиту (из выходных параметров функции выбирается запись, соответствующая значениям в полях Сумма и Срок: [<minsum> <= Сумма <= <maxsum>] и [Срок == <prd>]).\n" +
            "    Если на форме Оформление депозита в поле Срок значение введено вручную – заполняется значением поля Срок (в днях).")
    private int cdd;

    @Parameter(description = "Дата завершения сделки\n" +
            "\n" +
            "Заполняется только если на форме Оформление депозита НЕ установлен чекбокс Автоматическое продление. Иначе – поле не заполняется.\n" +
            "\n" +
            "Заполняется значением:\n" +
            "\n" +
            "    Если на форме Оформление депозита в поле Срок значение НЕ введено вручную (выбрано из списка): [Текущая системная дата] + [значение выходного параметра <cdd> функции Получение информации по депозиту (из выходных параметров функции выбирается запись, соответствующая значениям в полях Сумма и Срок: [<minsum> <= Сумма <= <maxsum>] и [Срок == <prd>])].\n" +
            "    Если на форме Оформление депозита в поле Срок значение введено вручную: [Текущая системная дата] + [значение поля Срок (в днях)].")
    private Date mdt;

    @Parameter(description = "Interest days basis\n" +
            "\n" +
            "2\n" +
            "\n" +
            "Значение настраивается в конфигурации.",
            example = "2")
    @NotNull
    private Integer idb;

    @Parameter(description = "Частота выплаты процентов\n" +
            "\n" +
            "Заполняется значением выходного параметра <ifq> функции Получение списка депозитов, доступных для открытия.",
            example = "V31")
    @NotBlank
    private String ifq;

    @Parameter(description = "Код налога 1\n" +
            "\n" +
            "B0\n" +
            "\n" +
            "Значение настраивается в конфигурации.",
            example = "B0")
    @NotBlank
    private String cr1;

    @Parameter(description = "Код налога 2\n" +
            "\n" +
            "B0\n" +
            "\n" +
            "Значение настраивается в конфигурации.",
            example = "B0")
    @NotBlank
    private String cr2;

    @Parameter(description = "Капитализация процентов?\n" +
            "\n" +
            "Y, если в поле Сумма формы Оформление депозита выбрано значение \"На депозит (капитализация)\". Иначе – N.",
            example = "Y")
    @NotBlank
    private String cpi;

    @Parameter(description = "Префикс счета старта\n" +
            "\n" +
            "Заполняется значением выходного параметра branchId функции Получение расширенной информации о счете.",
            example = "0702")
    @NotBlank
    private String abf;

    @Parameter(description = "Номер счета старта\n" +
            "\n" +
            "Заполняется значением выходного параметра accountBaseNumber функции Получение расширенной информации о счете.",
            example = "AAAABA")
    @NotBlank
    private String anf;

    @Parameter(description = "Суффикс счета старта\n" +
            "\n" +
            "Заполняется значением выходного параметра accountSuffix функции Получение расширенной информации о счете.",
            example = "002")
    @NotBlank
    private String asf;

    @Parameter(description = "Префикс счета завершения\n" +
            "\n" +
            "Заполняется значением выходного параметра branchId функции Получение расширенной информации о счете.",
            example = "0702")
    @NotBlank
    private String abm;

    @Parameter(description = "Номер счета завершения\n" +
            "\n" +
            "Заполняется значением выходного параметра accountBaseNumber функции Получение расширенной информации о счете.",
            example = "AAAABA")
    @NotBlank
    private String anm;

    @Parameter(description = "Суффикс счета завершения\n" +
            "\n" +
            "Заполняется значением выходного параметра accountSuffix функции Получение расширенной информации о счете.",
            example = "002")
    @NotBlank
    private String asm;

    @Parameter(description = "Код периода\n" +
            "\n" +
            "Заполняется значением выходного параметра <prc> функции Получение информации по депозиту (из выходных параметров функции выбирается запись, соответствующая значениям в полях Сумма и Срок:\n" +
            " Для депозитов с выбором срока:\n" +
            "\n" +
            "[<minsum> <= Сумма <= <maxsum>] и [Срок == <prd>]\n" +
            " Для депозитов с ручным вводом срока:\n" +
            "\n" +
            "[<minsum> <= Сумма <= <maxsum>]\n" +
            "\n" +
            "и\n" +
            "\n" +
            "[<cdd> текущего интервала <= Срок < <cdd> следующего интервала] – для всех интервалов, кроме последнего\n" +
            "\n" +
            "[<cdd><= Срок <= <maxday>] – для последнего интервала",
            example = "T6")
    @NotBlank
    private String prc;

    @Parameter(description = "Мнемоника валюты завершения\n" +
            "\n" +
            "Заполняется значением поля Валюта формы Оформление депозита.",
            example = "RUR")
    @NotBlank
    private String ccym;

    @Parameter(description = "Мнемоника валюты старта\n" +
            "\n" +
            "Заполняется значением поля Валюта формы Оформление депозита.",
            example = "RUR")
    @NotBlank
    private String ccyf;

    @Parameter(description = "Номер клиента бенефициара\n" +
            "\n" +
            "Заполняется значением CUS Клиента.",
            example = "AAAABA")
    @NotBlank
    private String bcus;

    @Parameter(description = "Местоположения клиента бенефициара\n" +
            "\n" +
            "Не заполняется.")
    @NotNull
    private String bclc;

    @Parameter(description = "Банк или клиент?\n" +
            "\n" +
            "C\n" +
            "\n" +
            "Значение настраивается в конфигурации.",
            example = "C")
    @NotBlank
    private String boc;

    //   fields for ufr-mcrm-ucc-session-api event/add
    private String sessionToken;
    private String depositName;
    private String depositCurrencyName;
    private String depositCurrency;
    private String depositTerm;
    private String depositSum;
    private String capitalization;
    private String prolongation;
    private String wasExpressAccountOpening;
    private String wasRURTransfer;
    private String wasForeignCurrTransfer;
    private String debetAccNum;
    private String creditAccNum;
    private String convertedDebetSum;
    private String debetAccCurrency;
    private String rate;
    private String depositAccNum;
    private String creditExpressAccNum;
    private String depositNumber;
    private String depositOpenDate;
    private String depositEndDate;
    private String totalRate;
    private String baseRate;
    private String additionalRate;
    private String servicePacketName;
    private String servicePacketCode;
    private String totalCapitalizationRate;
    private String minimalBalance;
    private String maximalSum;
    private String allowedReplenishmentDate;
    private String poaFIO;
    private String poaOpnAccStartDate;
    private String poaOpnAccNumber;
    private String poaOpnDepStartDate;
    private String poaOpnDepNumber;
    private String poaTransferStartDate;
    private String poaTransferNumber;
}
