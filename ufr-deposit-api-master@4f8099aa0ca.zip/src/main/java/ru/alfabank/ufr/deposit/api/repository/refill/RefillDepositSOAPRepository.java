package ru.alfabank.ufr.deposit.api.repository.refill;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;
import ru.alfabank.api.deposit.principal.DepositPrincipalAddCommandFactory;
import ru.alfabank.api.deposit.principal.DepositPrincipalAddRequest;
import ru.alfabank.api.deposit.principal.DepositPrincipalAddResponse;
import ru.alfabank.ufr.deposit.api.utils.WS;
import ru.alfabank.ws.cs.eq.wsdepositprincipal10.WSDepositPrincipalPortType;
import ru.alfabank.ws.cs.wscommontypes10.WSCommonParms;

import java.math.BigDecimal;
import java.util.Optional;

@Slf4j
@Repository
public class RefillDepositSOAPRepository implements RefillDepositRepository {
    private final WSCommonParms commonParms;
    private final DepositPrincipalAddCommandFactory principalAddCommandFactory;
    private final int timeout;

    public RefillDepositSOAPRepository(WSCommonParms commonParms, WSDepositPrincipalPortType portType,
                                       @Value("${hystrix.command.default.execution.isolation.thread.timeoutInMilliseconds}") int timeout) {
        this.commonParms = commonParms;
        this.principalAddCommandFactory = new DepositPrincipalAddCommandFactory(commonParms, timeout, portType);
        this.timeout = timeout;
    }

    @Override
    public BigDecimal refill(Input input) {
        DepositPrincipalAddRequest request = getRequest(input);
        return Optional.ofNullable(principalAddCommandFactory.getCommand(
                WS.duplicateAndReplaceWithNotBlank(commonParms, input.getBranchNumber(), input.getUserID()),
                request,
                timeout).execute())
                .map(DepositPrincipalAddResponse::getSequenceNumber)
                .orElse(null);
    }

    private DepositPrincipalAddRequest getRequest(Input input) {
        return DepositPrincipalAddRequest.builder()
                .dealType(input.getDlp())
                .dealReference(input.getDlr())
                .branchMnemonic(input.getBrnm())
                .customerMnemonic(input.getCus())
                .increase(input.getInc())
                .settlementBranch(input.getAbf())
                .settlementAccountBasicNumber(input.getAnf())
                .settlementAccountSuffix(input.getAsf())
                .receiveAmount(input.getNwr())
                .exceedTransactionAmount(input.getAdj())
                .narrativeAccountPosting(input.getNda())
                .build();
    }
}