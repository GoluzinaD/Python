package ru.alfabank.ufr.deposit.api.configuration.moduleinfo;

import lombok.Data;

@Data
public class OperationProperty {

    private String id;
    private String endpoint;
    private String name;

}
