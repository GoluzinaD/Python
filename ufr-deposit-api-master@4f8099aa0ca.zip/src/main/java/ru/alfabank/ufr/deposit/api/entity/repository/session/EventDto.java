package ru.alfabank.ufr.deposit.api.entity.repository.session;

import lombok.Builder;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
@Builder
public class EventDto {
    @NotBlank
    private String token;

    @NotNull
    @Valid
    private AbstractEventDataDto event;
}