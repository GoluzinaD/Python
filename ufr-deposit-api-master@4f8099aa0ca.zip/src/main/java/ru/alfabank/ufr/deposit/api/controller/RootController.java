package ru.alfabank.ufr.deposit.api.controller;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import ru.alfabank.ufr.deposit.api.configuration.moduleinfo.AppDefinedPathProps;
import ru.alfabank.ufr.deposit.api.entity.repository.ad.AuthEncodeRequest;
import ru.alfabank.ufr.deposit.api.entity.rest.moduleinfo.ModuleDto;
import ru.alfabank.ufr.deposit.api.entity.rest.moduleinfo.SessionResponse;
import ru.alfabank.ufr.deposit.api.repository.ad.AdApiRepository;
import ru.alfabank.ufr.deposit.api.service.ModuleInfoService;

import javax.validation.Valid;
import java.util.Optional;

@Slf4j
@RestController
//@CrossOrigin
@RequiredArgsConstructor
public class RootController {
    private final ModuleInfoService moduleInfoService;
    private final AppDefinedPathProps moduleInfoAppDefinedPathProps;
    private final AdApiRepository adApiRepository;

    @PostMapping(
            value = "getInfo",
            produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE)
    public ModuleDto getModuleInfo(
            @RequestParam(value = "ad-token", required = false) String adToken,
            @RequestBody @Valid SessionResponse sessionRequestDto,
            @Value("${interaction.servicePanel.adPassHash}") String adPassHash) {
        String token = Optional.ofNullable(adToken).orElseGet(() -> retrieveToken(sessionRequestDto, adPassHash));
        return moduleInfoService.getModuleDto(token, sessionRequestDto);
    }

    @PostMapping(
            value = "open/getInfo",
            produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE)
    public ModuleDto getModuleInfoOpenDeposit(
            @RequestParam(value = "ad-token", required = false) String adToken,
            @RequestBody @Valid SessionResponse sessionRequestDto,
            @Value("${interaction.servicePanel.adPassHash}") String adPassHash) {
        String token = Optional.ofNullable(adToken).orElseGet(() -> retrieveToken(sessionRequestDto, adPassHash));
        return moduleInfoService.getModuleDtoOpenDeposit(token, sessionRequestDto);
    }

    private String retrieveToken(SessionResponse sessionRequestDto, String adPassHash) {
        return Optional.ofNullable(adApiRepository.encode(AuthEncodeRequest.builder()
                .cus(Optional.ofNullable(sessionRequestDto).map(SessionResponse::getCus).orElse(null))
                .extSysCode(moduleInfoAppDefinedPathProps.getCallerId())
                .passHash(adPassHash)
                .username(sessionRequestDto.getAdLogin())
                .build()
        ).getToken()).orElseThrow(() -> new RuntimeException(
                "No ad token received! Check user login or ad-api url in app props"));
    }
}