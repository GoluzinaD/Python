package ru.alfabank.ufr.deposit.api.configuration;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.servers.Server;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Collections;

/**
 * Конфигурация Swagger UI
 */
@Configuration
public class SwaggerConfig {

    private static final String TITLE = "ufr-deposit-api";

    @Value("${version}")
    private String version;
    @Value("${server.url}")
    private String serverURL;
    @Value("${server.description}")
    private String description;

    @Bean
    public OpenAPI openAPI() {
        return new OpenAPI()
                .info(new Info().title(TITLE)
                        .description("Модуль предназначен для обработки депозитов.")
                        .version(version.isEmpty() ? "no version" : version))
                .servers(Collections.singletonList(new Server().url(serverURL).description(description)));
    }
}
