package ru.alfabank.ufr.deposit.api.repository.counter;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Repository;
import ru.alfabank.ufr.deposit.api.entity.repository.Counter;

import static org.springframework.data.mongodb.core.query.Query.query;

@Repository
@RequiredArgsConstructor
public class MongoDepositCounterStorage implements DepositCounter, DepositCounterModifier {
    private final MongoTemplate mongoTemplate;
    @Value("${depositCreateCounterCollectionName}")
    private String counterCollectionName;

    //todo временное решение для обхода коллизий в генерируемых значениях на тестовых средах
    @Value("${deposit.counter.offset:0}")
    private int offset;

    @Override
    public int getNext(String cus) {
        return offset + mongoTemplate.findAndModify(query(Criteria.where("cus").is(cus)), new Update().inc("value", 1),
                FindAndModifyOptions.options().returnNew(true).upsert(true),
                Counter.class, counterCollectionName).getValue();
    }

    @Override
    @Scheduled(cron = "${counterResetSchedule}")
    public void resetAll() {
        mongoTemplate.dropCollection(counterCollectionName);
    }
}
