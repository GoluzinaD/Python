package ru.alfabank.ufr.deposit.api.entity.repository;

import lombok.Data;

@Data
public class Counter {
    private String cus;
    private int value;
}
