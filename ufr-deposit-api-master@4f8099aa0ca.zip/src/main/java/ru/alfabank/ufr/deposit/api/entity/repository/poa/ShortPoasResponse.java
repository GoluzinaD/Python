package ru.alfabank.ufr.deposit.api.entity.repository.poa;

import lombok.Data;

import java.util.List;

@Data
public class ShortPoasResponse {

    private List<ShortPoaDto> shortPoaList;
}
