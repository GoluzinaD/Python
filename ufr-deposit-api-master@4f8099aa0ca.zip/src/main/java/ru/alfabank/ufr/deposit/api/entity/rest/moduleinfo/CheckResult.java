package ru.alfabank.ufr.deposit.api.entity.rest.moduleinfo;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.util.stream.Stream;

@Getter
@RequiredArgsConstructor
public enum CheckResult {
    YES("OK"),
    NO("BAN"),
    ERROR("ERROR");

    private final String value;

    public static CheckResult getByValue(String value) {
        return Stream.of(values())
                .filter(result -> result.getValue().equals(value))
                .findFirst()
                .orElse(null);
    }
}