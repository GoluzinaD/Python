package ru.alfabank.ufr.deposit.api.entity.rest;

import lombok.Data;
import lombok.experimental.Accessors;

import java.util.Map;
import java.util.Set;

@Data
public class AvailableDepositTypes {
    @Data
    @Accessors(chain = true)
    public static class DlpData {
        private Set<String> ccy;
        private DepositPropsInList depositProps;
    }

    private Map<String,DlpData> dlp;
}
