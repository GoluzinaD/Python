package ru.alfabank.ufr.deposit.api.repository.exceptions;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class DepositMaintainException extends WebServiceException {

    public DepositMaintainException(Throwable cause) {
        super(cause);
    }
}
