package ru.alfabank.ufr.deposit.api.repository.operation;

import ru.alfabank.ufr.deposit.api.entity.repository.operation.OperationType;

public interface OperationTypeGetter {
    OperationType getOperationType(String eventType);
}
