package ru.alfabank.ufr.deposit.api.aspect.validation;

public class CusMatchingValidationException extends IllegalArgumentException {
    CusMatchingValidationException(String msg, Throwable cause) { super(msg, cause); }
    CusMatchingValidationException(String msg) { super(msg); }
}
