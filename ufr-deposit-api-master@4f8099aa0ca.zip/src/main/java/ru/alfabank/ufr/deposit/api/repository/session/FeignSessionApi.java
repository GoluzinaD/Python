package ru.alfabank.ufr.deposit.api.repository.session;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import ru.alfabank.ufr.deposit.api.configuration.FeignClientConfiguration;
import ru.alfabank.ufr.deposit.api.entity.repository.poa.FullPoasResponse;
import ru.alfabank.ufr.deposit.api.entity.repository.session.EventDto;
import ru.alfabank.ufr.deposit.api.entity.repository.session.TokenDto;
import ru.alfabank.ufr.deposit.api.entity.rest.SessionDto;
import ru.alfabank.ufr.deposit.api.entity.rest.SessionStatusDto;

import javax.validation.Valid;
import java.util.List;

@FeignClient(name = "sessionApi", url = "${interaction.sessionApi.endpoint}", configuration = FeignClientConfiguration.class)
public interface FeignSessionApi {
    @PostMapping(value = "/session/check")
    SessionStatusDto checkSession(@RequestBody SessionDto request);

    @PostMapping(value = "/event/add")
    TokenDto addEvent(@RequestBody @Valid EventDto request);

    @GetMapping(value = "/session/data")
    List<FullPoasResponse> getSession(@RequestParam("id") String sessionId, @RequestParam("names") String key);
}