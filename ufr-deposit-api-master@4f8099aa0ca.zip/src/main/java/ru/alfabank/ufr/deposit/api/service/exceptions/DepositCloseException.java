package ru.alfabank.ufr.deposit.api.service.exceptions;

public class DepositCloseException extends RuntimeException {
    public DepositCloseException(Throwable cause) { super(cause); }
}
