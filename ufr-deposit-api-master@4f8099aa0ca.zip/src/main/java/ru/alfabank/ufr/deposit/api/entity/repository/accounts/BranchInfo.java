package ru.alfabank.ufr.deposit.api.entity.repository.accounts;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Accessors(chain = true)
@Data
public class BranchInfo implements Serializable {
    private String branchName;
    private String branchFullName;
    private String bic;
    private String inn;
    private String kpp;
    private String okato;
    private String correspondentAccount;
    private String subsidiaryName;
    private String rkcName;
    private String okpo;
}
