package ru.alfabank.ufr.deposit.api.utils;

import lombok.experimental.UtilityClass;

import java.math.BigDecimal;

@UtilityClass
public class NumberOps {
    private static final BigDecimal HUNDRED = new BigDecimal("100");
    public BigDecimal dividedBy100(BigDecimal dividend) {
        return dividend.divide(HUNDRED);
    }

}
