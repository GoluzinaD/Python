package ru.alfabank.ufr.deposit.api.messages;

public enum MessageCode {
    SESSION_API_REPOSITORY_FULL_POA("message.error.handlerNoSuchObjectResponseApiException.session.api.repository.FullPoa"),
    SESSION_API_REPOSITORY_FULL_POA_DTO("message.error.handlerNoSuchObjectResponseApiException.session.api.repository.FullPoaDto"),
    SESSION_API_REPOSITORY_AGGREGATE_POA_START_DATE("message.error.handlerNoSuchObjectResponseApiException.session.api.repository.aggregate.PoaStartDate"),
    SESSION_API_REPOSITORY_AGGREGATE_POA_EXPIRY_DATE("message.error.handlerNoSuchObjectResponseApiException.session.api.repository.aggregate.PoaExpiryDate"),
    SESSION_API_REPOSITORY_AGGREGATE_IS_GENERAL_FLAG("message.error.handlerNoSuchObjectResponseApiException.session.api.repository.aggregate.IsGeneral"),
    SESSION_API_REPOSITORY_ELEMENTARY_POA_LIST("message.error.handlerNoSuchObjectResponseApiException.session.api.repository.ElementaryPoaList"),
    SESSION_API_REPOSITORY_ELEMENTARY_POA_DTO_OTHER_DETAILS("message.error.handlerNoSuchObjectResponseApiException.session.api.repository.elementaryPoaDto.OtherDetails"),
    POA_CONTROLLER_ACCOUNT_NUMBER("message.error.illegalArgument.accountNumber");

    private String description;

    MessageCode(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }
}
