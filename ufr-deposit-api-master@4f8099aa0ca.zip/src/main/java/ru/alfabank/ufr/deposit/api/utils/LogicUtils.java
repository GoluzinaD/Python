package ru.alfabank.ufr.deposit.api.utils;

import org.apache.commons.lang3.StringUtils;
import ru.alfabank.ufr.deposit.api.configuration.Constants;

public class LogicUtils {
    public static String booleanToString(Boolean value) {
        return Boolean.TRUE.equals(value)
                ? Constants.Y
                : (Boolean.FALSE.equals(value) ? Constants.N : null);
    }

    public static Boolean stringToBoolean(String value) {
        return StringUtils.isBlank(value)
                ? null
                : Constants.Y.equalsIgnoreCase(value);
    }
}