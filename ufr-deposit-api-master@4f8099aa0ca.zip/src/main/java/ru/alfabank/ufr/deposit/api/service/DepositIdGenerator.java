package ru.alfabank.ufr.deposit.api.service;

public interface DepositIdGenerator {
    String getNextId(String cus);
}
