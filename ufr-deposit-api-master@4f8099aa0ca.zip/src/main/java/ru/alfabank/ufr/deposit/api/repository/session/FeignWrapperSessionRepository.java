package ru.alfabank.ufr.deposit.api.repository.session;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;
import ru.alfabank.ufr.deposit.api.entity.repository.session.EventDto;
import ru.alfabank.ufr.deposit.api.entity.repository.session.TokenDto;
import ru.alfabank.ufr.deposit.api.entity.rest.SessionDto;
import ru.alfabank.ufr.deposit.api.entity.rest.SessionStatusDto;

@Repository
@RequiredArgsConstructor
public class FeignWrapperSessionRepository implements SessionRepository {
    private final FeignSessionApi feignSessionApi;
    @Override
    public SessionStatusDto checkSession(SessionDto request) {
        return feignSessionApi.checkSession(request);
    }

    @Override
    public TokenDto addEvent(EventDto request) {
        return feignSessionApi.addEvent(request);
    }
}
