package ru.alfabank.ufr.deposit.api.aspect.exceptionhandling;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

import java.text.MessageFormat;

@Slf4j
@Aspect
@Component
public class HandleRepoLayerExceptions {

    @AfterThrowing(pointcut = "executionRepositoryDialingMethod()", throwing = "ex")
    public void handleSOAPThrowing(JoinPoint jp, Throwable ex) {
        log.error("execution of method {} with arguments {} threw exception: {}", jp.getSignature().getName(), jp.getArgs(), ex);
    }

    @Pointcut("execution(public * ru.alfabank.ufr.deposit.api.repository..*(..))")
    public void executionRepositoryDialingMethod() {}

}
