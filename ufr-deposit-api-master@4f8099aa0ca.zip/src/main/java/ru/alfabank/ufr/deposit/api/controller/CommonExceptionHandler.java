package ru.alfabank.ufr.deposit.api.controller;

import lombok.extern.slf4j.Slf4j;
import net.minidev.json.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import ru.alfabank.ufr.deposit.api.entity.exceptions.NoSuchObjectResponseApiException;
import ru.alfabank.ufr.deposit.api.utils.ExceptionHandling;

@ControllerAdvice
@Slf4j
public class CommonExceptionHandler {
    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseBody
    public ResponseEntity<String> handleConstraintValidationException(MethodArgumentNotValidException ex) {
        JSONObject jsonObject = new JSONObject();
        ExceptionHandling.commonExceptionHandling(ex, jsonObject);
        log.error("{}", ex);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(jsonObject.toString());
    }

    @ExceptionHandler(Exception.class)
    @ResponseBody
    protected ResponseEntity<String> handleAnyException(Exception ex) {
        JSONObject jsonObject = new JSONObject();
        ExceptionHandling.commonExceptionHandling(ex, jsonObject);
        log.error("{}", ex);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(jsonObject.toString());
    }

    @ExceptionHandler(NoSuchObjectResponseApiException.class)
    @ResponseBody
    protected ResponseEntity<String> handleNoSuchObjectResponseApiException(NoSuchObjectResponseApiException ex) {
        JSONObject jsonObject = new JSONObject();
        ExceptionHandling.commonExceptionHandling(ex, jsonObject);
        log.error("{}", ex);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(jsonObject.toString());
    }
}