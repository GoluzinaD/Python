package ru.alfabank.ufr.deposit.api.entity.repository.poa;

import io.swagger.v3.oas.annotations.Parameter;
import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.Size;

@Data
@Builder
public class TypeKindDto {
    @Size(min=3, max=3)
    @Parameter(description = "Код типа доверенности.")
    private String codeType;

    @Parameter(description = "Наименование типа доверенности.")
    private String typeName;

    @Size(min=3, max=3)
    @Parameter(description = "Код вида доверенности.")
    private String codeKind;

    @Parameter(description = "Наименование вида доверенности.")
    private String kindName;
}