package ru.alfabank.ufr.deposit.api.repository.counter;


public interface DepositCounter {
    int getNext(String cus);
}
