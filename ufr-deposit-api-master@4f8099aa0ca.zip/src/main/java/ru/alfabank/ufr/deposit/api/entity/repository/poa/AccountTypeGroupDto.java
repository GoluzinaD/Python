package ru.alfabank.ufr.deposit.api.entity.repository.poa;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.Parameter;
import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.Size;

@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AccountTypeGroupDto {
    @JsonProperty("codeAccountTypeGroup")
    @Size(min=3, max=3)
    @Parameter(description = "Код подкатегории.")
    private String codeAtg;

    @Parameter(description = "Наименование подкатегории.")
    private String atgName;

    @Size(min=3, max=3)
    @Parameter(description = "Группа типов объектов (категория).")
    private String accountGroup;
}