package ru.alfabank.ufr.deposit.api.repository.autoprolangation.wsDeposit;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.springframework.stereotype.Repository;
import ru.alfabank.ufr.deposit.api.entity.repository.autoProlongation.maintain.MaintainDepositRequestDto;
import ru.alfabank.ufr.deposit.api.repository.exceptions.DepositMaintainException;
import ru.alfabank.ufr.deposit.api.utils.DateTimeMapping;
import ru.alfabank.ufr.deposit.api.utils.WS;
import ru.alfabank.ws.cs.eq.wsdeposit11.WSDepositPortType;
import ru.alfabank.ws.cs.eq.wsdeposit11.hystrix.WsDepositMaintainCmd;
import ru.alfabank.ws.cs.eq.wsdepositinoutparms11.WSDepositMaintainInParms;
import ru.alfabank.ws.cs.eq.wsdepositinoutparms11.WSDepositMaintainOutParms;
import ru.alfabank.ws.cs.wscommontypes10.WSCommonParms;

@Slf4j
@Repository
@RequiredArgsConstructor
public class DepositApiRepository implements DepositRepository {
    private final WSCommonParms commonParms;
    private final WSDepositPortType depositPortType;
    private final DepositMaintainInParmsMapper inParmsMapper;

    @Mapper(componentModel = "spring", uses = DateTimeMapping.class)
    interface DepositMaintainInParmsMapper {
        @Mapping(source = "requestDto.mdt",
                target = "mdt",
                qualifiedByName = {"DateTimeMapping", "DateToLocalDate"})
        WSDepositMaintainInParms convertToWSDepositMaintainInParms(MaintainDepositRequestDto requestDto);
    }

    @Override
    public WSDepositMaintainOutParms maintainDeposit(MaintainDepositRequestDto requestDto) {
        WsDepositMaintainCmd maintainCmd = new WsDepositMaintainCmd(depositPortType)
                .setInCommonParms(WS.duplicateAndReplaceWithNotBlank(commonParms, requestDto.getBranchNumber(), requestDto.getUserId()))
                .setInParms(inParmsMapper.convertToWSDepositMaintainInParms(requestDto));

        try {
            return  maintainCmd.execute();
        } catch (Exception e) {
            throw new DepositMaintainException(e);
        }
    }
}