package ru.alfabank.ufr.deposit.api.repository.counter;

public interface DepositCounterModifier {
    void resetAll();
}
