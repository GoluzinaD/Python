package ru.alfabank.ufr.deposit.api.entity.rest.moduleinfo;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

@Data
public class SessionRequestDto implements Serializable {
    String sessionId;
    @NotBlank
    String adLogin;
    SessionResponse sessionInfo;
}