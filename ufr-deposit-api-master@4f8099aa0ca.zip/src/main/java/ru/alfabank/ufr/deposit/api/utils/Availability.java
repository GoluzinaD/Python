package ru.alfabank.ufr.deposit.api.utils;

import lombok.experimental.UtilityClass;
import ru.alfabank.ufr.deposit.api.configuration.moduleinfo.ModuleInfoProps;

@UtilityClass
public class Availability {
    public boolean CheckInclusionException(ModuleInfoProps.NamesIncludeExcept namesIncludeExcept, final String name) {
        return (namesIncludeExcept.getExcept().stream().noneMatch(s -> s.equals(name))
                && namesIncludeExcept.getInclude().stream().anyMatch(s -> s.equals(name)));
    }
}
