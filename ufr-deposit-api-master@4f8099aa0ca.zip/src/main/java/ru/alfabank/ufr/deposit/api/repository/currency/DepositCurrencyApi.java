package ru.alfabank.ufr.deposit.api.repository.currency;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import ru.alfabank.ufr.deposit.api.configuration.FeignClientConfiguration;
import ru.alfabank.ufr.deposit.api.entity.repository.currency.ConversionRatesResponse;

import java.math.BigDecimal;

@FeignClient(name = "depositCurrencyApi", url = "${interaction.depositCurrencyApi.url}", configuration = FeignClientConfiguration.class)
public interface DepositCurrencyApi {
    @GetMapping(path = "${interaction.depositCurrencyApi.conversion}")
    ConversionRatesResponse getLatestConversion(@RequestParam("currencyFrom") String currencyFrom,
                                                @RequestParam("currencyTo") String currencyTo,
                                                @RequestParam("amount") BigDecimal amount);
}