package ru.alfabank.ufr.deposit.api.entity.rest;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Data
public class DepositCreateInData {
    private String dlp;
    private String dlr;
    private String brnm;
    private String ccy;
    private BigDecimal dla;
    private Date sdt;
    private Date mdt;
    private Integer idb;
    private String ifq;
    private String cr1;
    private String cr2;
    private String cpi;
    private String abf;
    private String anf;
    private String asf;
    private String abm;
    private String anm;
    private String asm;
    private String prc;
    private String ccym;
    private String ccyf;
    private String bcus;
    private String bclc;
    private String boc;
}
