package ru.alfabank.ufr.deposit.api.entity.repository.depositPrincipal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DepositPrincipalClaimRequest {
    private String userId;
    private String branchNumber;
    private String cus;
    private String branch; //brnm
    private String depositType; //dlp
    private String depositNumber; // dlr
    private String clc;
    private String inc;
    private BigDecimal sumOfWithdrawal;
    private String nda;
}
