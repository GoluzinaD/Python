package ru.alfabank.ufr.deposit.api.controller.deposit;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import net.minidev.json.JSONObject;
import org.mapstruct.Mapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.alfabank.ufr.deposit.api.entity.rest.*;
import ru.alfabank.ufr.deposit.api.entity.rest.autoProlongation.AutoProlongationRequest;
import ru.alfabank.ufr.deposit.api.entity.rest.depositClaim.DepositClaimRequest;
import ru.alfabank.ufr.deposit.api.entity.rest.depositClaim.DepositClaimResponse;
import ru.alfabank.ufr.deposit.api.repository.exceptions.DepositMaintainException;
import ru.alfabank.ufr.deposit.api.repository.exceptions.DepositsRecievingException;
import ru.alfabank.ufr.deposit.api.repository.exceptions.UserClaimException;
import ru.alfabank.ufr.deposit.api.repository.exceptions.UserNotFoundException;
import ru.alfabank.ufr.deposit.api.service.DepositService;
import ru.alfabank.ufr.deposit.api.service.autoProlangation.AutoProlongationDepositService;
import ru.alfabank.ufr.deposit.api.service.exceptions.CreateDepositException;
import ru.alfabank.ufr.deposit.api.service.exceptions.DepositCloseException;
import ru.alfabank.ufr.deposit.api.service.exceptions.RefillDepositException;
import ru.alfabank.ufr.deposit.api.service.exceptions.SessionAddEventException;
import ru.alfabank.ufr.deposit.api.utils.ExceptionHandling;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Locale;

import static ru.alfabank.ufr.deposit.api.configuration.Constants.MSG_FIELD_RESPONSE;

@Slf4j
@CrossOrigin
@RestController
@RequestMapping(value = "deposit/client")
@RequiredArgsConstructor
@RestControllerAdvice
public class ClientDepositsController {
    private final DepositService depositService;
    private final AutoProlongationDepositService autoProlongationService;
    private final DTOConversion conversion;
    private final MessageSource messageSource;
    private final ObjectMapper mapper;

    @Setter
    @Value("${logParams.inout:false}")
    private boolean logSent;

    @GetMapping(path = "{clientId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<FetchedProducts> getClientDeposits(@PathVariable(name = "clientId") String clientId,
                                                             @RequestParam(name = "channelCode", required = false) String channelCode,
                                                             @RequestParam(name = "languageMnemonic", required = false) String languageMnemonic) {
        log.info("#GET: url is /deposit/client/{clientId}. clientId is {}, channelCode is {}, languageMnemonic is {}",
                clientId, channelCode, languageMnemonic);
        FetchedProducts clientDeposits = depositService.getClientDeposits(clientId, channelCode, languageMnemonic);
        if (logSent) {
            try {
                log.info("Sent deposit products: {}", mapper.writeValueAsString(clientDeposits));
            } catch (JsonProcessingException e1) {
                log.warn("Deposits to be sent could not be parsed into json! ClientId: {}",
                        clientId);
            }
        }
        return ResponseEntity.ok(clientDeposits);
    }


    @PostMapping(path = "create", produces = MediaType.APPLICATION_JSON_VALUE)
    @SneakyThrows(JsonProcessingException.class)
    public DepositCreateOutData createDeposit(@Valid @NotNull @RequestBody DepositCreateRESTRequestData request) {
        log.info("#POST: url is /deposit/client/create. request is {}", mapper.writeValueAsString(request));
        return depositService.createDeposit(request);
    }

    @GetMapping(path = "opened", produces = MediaType.APPLICATION_JSON_VALUE)
    public OpenedDepositDetails getOpenedDepositDetails(
            @Valid @NotBlank @RequestParam(name = "brnm") String brnm,
            @Valid @NotBlank @RequestParam(name = "dlp") String dlp,
            @Valid @NotBlank @RequestParam(name = "dlr") String dlr,
            @Valid @NotBlank @RequestParam(name = "xm", required = false, defaultValue = "${defaults.xm}") String xm,
            @Valid @NotBlank @RequestParam(name = "lnm", required = false, defaultValue = "${defaults.lnm}") String lnm) {
        log.info("#GET: url is /deposit/client/opened. brnm is {}, dlp is {}, dlr is {}, xm is {}, lnm is {}",
                brnm, dlp, dlr, xm, lnm);
        return depositService.getFullOpenedDepositDetails(brnm, dlp, dlr, xm, lnm);
    }

    @PostMapping(path = "refill", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @SneakyThrows(JsonProcessingException.class)
    public BigDecimal refillDeposit(@RequestHeader(value = "${sessionParams.headers.eqId}") String eqId,
                                    @RequestHeader(value = "${sessionParams.headers.operatorLogin}") String opLogin,
                                    @RequestHeader(value = "${sessionParams.headers.sessionToken}") String sessionToken,
                                    @RequestBody @Valid DepositRefillInData inData,
                                    Locale locale) {
        log.info("#POST: url is /deposit/client/refill. request is {}", mapper.writeValueAsString(inData));
        return depositService.refillDeposit(eqId, opLogin, sessionToken, inData, locale);
    }

    @GetMapping(path = "rest/{clientId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<FetchedProducts> getClientDepositsFromRest(@PathVariable(name = "clientId") String clientId,
                                                                     @RequestParam(required = false, defaultValue = "false") boolean isClosed) {
        log.info("#GET: url is /deposit/client/rest/{clientId}. clientId is {}, isClosed is {}", clientId, isClosed);
        FetchedProducts clientDeposits = depositService.getClientRestDeposits(clientId, null, null, isClosed);
        if (logSent) {
            try {
                log.info("Sent deposit products: {}", mapper.writeValueAsString(clientDeposits));
            } catch (JsonProcessingException e1) {
                log.warn("Deposits to be sent could not be parsed into json! ClientId: {}",
                        clientId);
            }
        }
        return ResponseEntity.ok(clientDeposits);
    }


    @PostMapping(path = "close/validation", produces = MediaType.APPLICATION_JSON_VALUE)
    @SneakyThrows(JsonProcessingException.class)
    public DepositCloseValidationParams getCloseValidation(@RequestBody @Valid DepositCloseValidationRequest request) {
        log.info("#POST: url is /deposit/client/close/validation. request is {}", mapper.writeValueAsString(request));
        return depositService.getDepositCloseValidationParams(request);
    }

    @PostMapping(path = "close", produces = MediaType.APPLICATION_JSON_VALUE)
    @SneakyThrows(JsonProcessingException.class)
    public DepositCloseResponse closeDeposit(@RequestBody @Valid DepositCloseRequest request,
                                             @RequestHeader(value = "${sessionParams.headers.eqId}") String eqId,
                                             @RequestHeader(value = "${sessionParams.headers.operatorLogin}") String operatorLogin) {
        log.info("#POST: url is /deposit/client/close. request is {}", mapper.writeValueAsString(request));
        return depositService.closeDeposit(conversion.convert(request).setEqId(eqId).setOperatorLogin(operatorLogin));
    }

    @PostMapping(path = "claim", produces = MediaType.APPLICATION_JSON_VALUE)
    @SneakyThrows(JsonProcessingException.class)
    public ResponseEntity<DepositClaimResponse> claimDeposit(@Valid @NotNull @RequestBody DepositClaimRequest request) {
        log.info("#POST: url is /deposit/client/claim. request is {}", mapper.writeValueAsString(request));
        DepositClaimResponse response = depositService.claim(request);
        return ResponseEntity.ok(response);
    }

    @PostMapping(path = "autoProlongation", produces = MediaType.APPLICATION_JSON_VALUE)
    @SneakyThrows(JsonProcessingException.class)
    public ResponseEntity<Void> autoProlongationDeposit(@Valid @NotNull @RequestBody AutoProlongationRequest request) {
        log.info("#POST: url is /deposit/client/autoProlongation. request is {}", mapper.writeValueAsString(request));
        autoProlongationService.autoProlongDeposit(request);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @ExceptionHandler(UserNotFoundException.class)
    @ResponseBody
    public ResponseEntity<String> userNotFoundExceptionHandler(UserNotFoundException e, Locale locale) {
        JSONObject jsonObject = new JSONObject();
        ExceptionHandling.commonExceptionHandling(e, jsonObject);
        log.error("Exception occurs: {}", jsonObject);
        jsonObject.put(MSG_FIELD_RESPONSE, messageSource.getMessage("respMsg.userNotFound", null, locale));
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(jsonObject.toString());
    }

    @ExceptionHandler(DepositsRecievingException.class)
    @ResponseBody
    public ResponseEntity<String> depositsReceivingExceptionHandler(DepositsRecievingException e, Locale locale) {
        JSONObject jsonObject = new JSONObject();
        ExceptionHandling.commonExceptionHandling(e, jsonObject);
        log.error("Exception occurs: {}", jsonObject);
        jsonObject.put(MSG_FIELD_RESPONSE, messageSource.getMessage("respMsg.depositsReceivingFailed", null, locale));
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(jsonObject.toString());
    }

    @ExceptionHandler(CreateDepositException.class)
    @ResponseBody
    public ResponseEntity<String> depositCreateExceptionHandler(CreateDepositException e, Locale locale) {
        JSONObject jsonObject = new JSONObject();
        ExceptionHandling.commonExceptionHandling(e, jsonObject);
        log.error("Exception occurs: {}", jsonObject);
        jsonObject.put(MSG_FIELD_RESPONSE, messageSource.getMessage("respMsg.createDepositFailed", null, locale));
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(jsonObject.toString());
    }

    @ExceptionHandler(SessionAddEventException.class)
    @ResponseBody
    public ResponseEntity<String> sessionAddEventExceptionHandler(SessionAddEventException e, Locale locale) {
        JSONObject jsonObject = new JSONObject();
        ExceptionHandling.commonExceptionHandling(e, jsonObject);
        log.error("Exception occurs: {}", jsonObject);
        jsonObject.put(MSG_FIELD_RESPONSE, messageSource.getMessage("respMsg.addEventFailed", null, locale));
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(jsonObject.toString());
    }

    @ExceptionHandler(DepositCloseException.class)
    @ResponseBody
    public ResponseEntity<String> depositCloseExceptionHandler(DepositCloseException e, Locale locale) {
        JSONObject jsonObject = new JSONObject();
        ExceptionHandling.commonExceptionHandling(e, jsonObject);
        log.error("Exception occurs: {}", jsonObject);
        jsonObject.put(MSG_FIELD_RESPONSE, messageSource.getMessage("respMsg.depositCloseFailed", null, locale));
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(jsonObject.toString());
    }

    @ExceptionHandler(RefillDepositException.class)
    @ResponseBody
    public ResponseEntity<String> refillDepositExceptionHandler(Exception e, Locale locale) {
        JSONObject jsonObject = new JSONObject();
        ExceptionHandling.commonExceptionHandling(e, jsonObject);
        jsonObject.put(MSG_FIELD_RESPONSE, messageSource.getMessage("respMsg.refillDepositFailed", null, locale));
        log.error("Exception occurs: {}", jsonObject);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(jsonObject.toString());
    }

    @ExceptionHandler(UserClaimException.class)
    @ResponseBody
    public ResponseEntity<DepositClaimResponse> handleUserClaimException(UserClaimException e, Locale locale) {
        DepositClaimResponse response = new DepositClaimResponse();
        response.setErrorCode(e.getErrorCode());
        JSONObject jsonObject = new JSONObject();
        ExceptionHandling.commonExceptionHandling(e, jsonObject);
        jsonObject.put(MSG_FIELD_RESPONSE, messageSource.getMessage("respMsg.userClaimException", null, locale));
        log.error("Exception occurs: {}", jsonObject);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
    }

    @ExceptionHandler(DepositMaintainException.class)
    @ResponseBody
    public ResponseEntity<String> handleDepositMaintainException(DepositMaintainException e, Locale locale) {
        JSONObject jsonObject = new JSONObject();
        ExceptionHandling.commonExceptionHandling(e, jsonObject);
        jsonObject.put(MSG_FIELD_RESPONSE, messageSource.getMessage("respMsg.depositMaintainFailed", null, locale));
        log.error("Exception occurs: {}", jsonObject);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(jsonObject.toString());
    }

    @Mapper(componentModel = "spring")
    interface DTOConversion {
        DepositCloseInData convert(DepositCloseRequest request);
    }
}