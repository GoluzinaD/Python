package ru.alfabank.ufr.deposit.api.service.session;

import ru.alfabank.ufr.deposit.api.entity.rest.DepositCreateRESTRequestData;
import ru.alfabank.ufr.deposit.api.entity.rest.autoProlongation.AutoProlongationRequest;
import ru.alfabank.ufr.deposit.api.entity.rest.session.SessionAbstractRequest;
import ru.alfabank.ufr.deposit.api.entity.rest.session.SessionRequestWrapper;

import java.util.HashMap;
import java.util.Map;

public enum SessionCustomFieldsGenerator {
    CREATE {
        @Override
        public Map<String, String> getCustomFields(SessionRequestWrapper<? extends SessionAbstractRequest> requestWrapper) {
            DepositCreateRESTRequestData request = (DepositCreateRESTRequestData) requestWrapper.getRequest();
            Map<String, String> customFields = new HashMap<>();
            customFields.put("depositName", request.getDepositName());
            customFields.put("depositCurrencyName", request.getDepositCurrencyName());
            customFields.put("depositCurrency", request.getDepositCurrency());
            customFields.put("depositTerm", request.getDepositTerm());
            customFields.put("depositSum", request.getDepositSum());
            customFields.put("capitalization", request.getCapitalization());
            customFields.put("prolongation", request.getProlongation());
            customFields.put("wasExpressAccountOpening", request.getWasExpressAccountOpening());
            customFields.put("wasRURTransfer", request.getWasRURTransfer());
            customFields.put("wasForeignCurrTransfer", request.getWasForeignCurrTransfer());
            customFields.put("debetAccNum", request.getDebetAccNum());
            customFields.put("creditAccNum", request.getCreditAccNum());
            customFields.put("convertedDebetSum", request.getConvertedDebetSum());
            customFields.put("debetAccCurrency", request.getDebetAccCurrency());
            customFields.put("rate", request.getRate());
            customFields.put("depositAccNum", request.getDepositAccNum());
            customFields.put("creditExpressAccNum", request.getCreditExpressAccNum());
            customFields.put("depositNumber", request.getDepositNumber());
            customFields.put("depositOpenDate", request.getDepositOpenDate());
            customFields.put("depositEndDate", request.getDepositEndDate());
            customFields.put("totalRate", request.getTotalRate());
            customFields.put("baseRate", request.getBaseRate());
            customFields.put("additionalRate", request.getAdditionalRate());
            customFields.put("servicePacketName", request.getServicePacketName());
            customFields.put("servicePacketCode", request.getServicePacketCode());
            customFields.put("totalCapitalizationRate", request.getTotalCapitalizationRate());
            customFields.put("minimalBalance", request.getMinimalBalance());
            customFields.put("maximalSum", request.getMaximalSum());
            customFields.put("allowedReplenishmentDate", request.getAllowedReplenishmentDate());
            customFields.put("poaFIO", request.getPoaFIO());
            customFields.put("poaOpnAccStartDate", request.getPoaOpnAccStartDate());
            customFields.put("poaOpnAccNumber", request.getPoaOpnAccNumber());
            customFields.put("poaOpnDepStartDate", request.getPoaOpnDepStartDate());
            customFields.put("poaOpnDepNumber", request.getPoaOpnDepNumber());
            customFields.put("poaTransferStartDate", request.getPoaTransferStartDate());
            customFields.put("poaTransferNumber", request.getPoaTransferNumber());
            return customFields;
        }
    },
    PROLONG {
        @Override
        public Map<String, String> getCustomFields(SessionRequestWrapper<? extends SessionAbstractRequest> requestWrapper) {
            AutoProlongationRequest request = (AutoProlongationRequest) requestWrapper.getRequest();
            Map<String, String> customFields = new HashMap<>();
            customFields.put("autoprolongation_depositName", request.getDepositName());
            customFields.put("autoprolongation_depositCurrency", request.getDepositCurrency());
            customFields.put("autoprolongation_depositTerm", request.getDepositTerm());
            customFields.put("autoprolongation_lastProlDate", request.getLastProlDate());
            customFields.put("autoprolongation_prolDateRefill", request.getProlDateRefill());
            customFields.put("autoprolongation_nextProlDate", request.getNextProlDate());
            customFields.put("autoprolongation_depositOpeningSum", request.getDepositOpeningSum());
            customFields.put("autoprolongation_depositOpeningSum2", request.getDepositOpeningSum2());
            customFields.put("autoprolongation_capitalization", request.getCapitalization());
            customFields.put("autoprolongation_prolongation", request.getProlongation());
            customFields.put("autoprolongation_depositAccNum", request.getDepositAccNum());
            customFields.put("autoprolongation_ExpressAccNum", request.getExpressAccNum());
            customFields.put("autoprolongation_depositNumber", request.getDepositNumber());
            customFields.put("autoprolongation_depositOpenDate", request.getDepositOpenDate());
            customFields.put("autoprolongation_depositOpenDate2", request.getDepositOpenDate2());
            customFields.put("autoprolongation_depositEndDate", request.getDepositEndDate());
            customFields.put("autoprolongation_totalRate", request.getTotalRate());
            customFields.put("autoprolongation_baseRate", request.getBaseRate());
            customFields.put("autoprolongation_additionalRate", request.getAdditionalRate());
            customFields.put("autoprolongation_servicePacketName", request.getServicePacketName());
            customFields.put("autoprolongation_servicePacketCode", request.getServicePacketCode());
            customFields.put("autoprolongation_totalCapitalizationRate", request.getTotalCapitalizationRate());
            customFields.put("autoprolongation_minimalBalance", request.getMinimalBalance());
            customFields.put("autoprolongation_maximalSum", request.getMaximalSum());
            customFields.put("autoprolongation_allowedReplenishmentDate", request.getAllowedReplenishmentDate());
            customFields.put("autoprolongation_setAutoprolongation", request.getSetAutoprolongation());
            customFields.put("autoprolongation_depositSum", request.getDepositSum());
            customFields.put("autoprolongation_poaStartDate", request.getPoaStartDate());
            customFields.put("autoprolongation_poaNumber", request.getPoaNumber());
            customFields.put("poaFIO", request.getPoaFIO());
            return customFields;
        }
    };

    public abstract Map<String, String> getCustomFields(SessionRequestWrapper<? extends SessionAbstractRequest> requestWrapper);
}
