package ru.alfabank.ufr.deposit.api.service.poa;

import org.mapstruct.Mapper;
import org.springframework.stereotype.Service;
import ru.alfabank.ufr.deposit.api.entity.repository.poa.FullPoaDto;
import ru.alfabank.ufr.deposit.api.entity.rest.poa.FullPoasResponseDto;

import java.util.List;

@Service
@Mapper(componentModel = "spring")
public interface PoaMapper {


    default FullPoasResponseDto getFullPoasResponseDto(List<FullPoaDto> fullPoaDtos, String accountNumber) {
        return FullPoasResponseDto.builder()
                .fullPoaList(fullPoaDtos)
                .accountNumber(accountNumber)
                .build();
    }
}
