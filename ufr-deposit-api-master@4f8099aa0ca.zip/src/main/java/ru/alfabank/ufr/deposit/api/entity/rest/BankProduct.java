package ru.alfabank.ufr.deposit.api.entity.rest;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@Data
@Accessors(chain = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BankProduct {
    public BankProduct() {}
    public BankProduct(String name, String currencyCode, ProductClassification classification,
                       FinancialResults financialResult, Date date, BigDecimal balanceInMinorUnits, int minority) {
        this.name = name;
        this.classification = classification;
        this.financialResults = financialResult;
        this.timestamp = date;
        this.uniqId = UUID.randomUUID().toString();
        this.balanceAmount = new Amount(balanceInMinorUnits, minority, currencyCode);
        this.balanceAmountReal = this.balanceAmount.getAmountReal();
        this.balanceAmountInMinorUnits = this.balanceAmount.getAmountInMinorUnits();
        this.balanceCurrencyCode = this.balanceAmount.getCurrencyCode();
        this.balanceMinority = this.balanceAmount.getMinority();
    }
    private String name;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
    private Date timestamp;
    private Amount balanceAmount;

    @Deprecated
    private BigDecimal balanceAmountReal;
    @Deprecated
    private BigDecimal balanceAmountInMinorUnits;
    @Deprecated
    private int balanceMinority;
    @Deprecated
    private String balanceCurrencyCode;


    private ProductClassification classification;
    private FinancialResults financialResults;
    private String uniqId;
}
