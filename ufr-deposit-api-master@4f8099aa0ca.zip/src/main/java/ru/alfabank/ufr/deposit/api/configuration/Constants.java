package ru.alfabank.ufr.deposit.api.configuration;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.util.Locale;

public class Constants {

    public enum ProductCategory {
        BANKACCOUNT,
        BROKERAGE,
        //        DEPOSIT,
        BROKER_ACCOUNT,
        TRUSTED_MANAGEMENT
    }

    public enum ProductSubCategory {
        @JsonProperty("CURRENTACC")
        CURRENTACC("CURRENTACC", ""),
        @JsonProperty("SAVINGACC")
        SAVINGACC("SAVINGACC", ""),
        @JsonProperty("DEPOSIT")
        DEPOSIT("", ""),
        @JsonProperty("BANKACCOUNTOTHER")
        BANKACCOUNTOTHER("", ""), // игнорируется в выдаче

        @JsonProperty("STOCKS")
        STOCKS("stocks", "АКЦИИ"),
        @JsonProperty("BONDS")
        BONDS("bonds", "ОБЛИГАЦИИ"),
        @JsonProperty("BROKERAGEOTHERS")
        BROKERAGEOTHERS("otherAssets", "ИНСТРУМЕНТ"),
        @JsonProperty("BROKERAGEACC")
        BROKERAGEACC("money", "Брокерский счёт");

        @Getter
        private String apiName;
        @Getter
        private String russianName;

        ProductSubCategory(String apiName, String russianName) {
            this.apiName = apiName;
            this.russianName = russianName;
        }

        public static ProductSubCategory getBrokerageSubCategory(String key) {
            switch (key) {
                case "stocks": {
                    return STOCKS;
                }
                case "stock": {
                    return STOCKS;
                }
                case "bonds": {
                    return BONDS;
                }
                case "bond": {
                    return BONDS;
                }
                case "otherAssets": {
                    return BROKERAGEOTHERS;
                }
                case "otherAsset": {
                    return BROKERAGEOTHERS;
                }
                case "otherasset": {
                    return BROKERAGEOTHERS;
                }
                case "money": {
                    return BROKERAGEACC;
                }
                default: {
                    throw new IllegalArgumentException("There is not productSubCategory: " + key);
                }
            }
        }
    }

    public enum FinancialResultType {
        FIN_RESULT_ALL,
        FIN_RESULT_YEARLY,
        FIN_RESULT_CURRENT_YEAR;
    }

    public enum InaccessibilityData {

        BANKACCOUNT("банковским счетам"),
        BROKERAGE("брокерским счетам"),
        TRUST_MANAGEMENT("доверительному управлению"),
        DEPOSIT("депозитам"),
        CURRENTACC("текущим счетам"),
        SAVINGACC("накопительным счетам");

        @Getter
        private String russianName;

        InaccessibilityData(String russianName) {
            this.russianName = russianName;
        }

        public static InaccessibilityData getBankAccountSubCategories(String key) {
            switch (key) {
                case "CURRENTACC": {
                    return CURRENTACC;
                }
                case "SAVINGACC": {
                    return SAVINGACC;
                }
                default: {
                    throw new IllegalArgumentException("There is not BankAccountSubCategory: " + key);
                }
            }
        }


    }

    public static final Locale LOCALE_RU = new Locale("ru");
    public static final String DEPOSIT_SERVICE_USER_NOT_FOUND_ERROR_CODE = "KSM2010";

    public static final String ASYNC_EXECUTOR_DEF_THREAD_NAME_PREFIX = "Async-";
    public static final int ASYNC_EXECUTOR_DEF_CORE_POOL = 70;
    public static final int ASYNC_EXECUTOR_DEF_MAX_POOL = 100;
    public static final int ASYNC_EXECUTOR_DEF_QUEUE_SIZE = 6000;

    public static final String HYSTRIX_EXECUTOR_DEF_CORE_POOL = "70";
    public static final String HYSTRIX_EXECUTOR_DEF_MAX_POOL = "100";
    public static final String HYSTRIX_EXECUTOR_DEF_QUEUE_THRESHOLD = "5000";
    public static final String HYSTRIX_EXECUTOR_DEF_QUEUE_SIZE = "6000";
    public static final String HYSTRIX_COMMAND_TIMEOUT_MS = "5000";


    public static final String ID_HARDCODE_CLIENT = "ALONVP";
    public static final String CACHE_TIME = "cache-time";
    public static final String FORMAT_DATE_TIME_ERROR_MESSAGES = "HH:mm dd.MM";
    public static final String FORMAT_DATE_TIME_CACHE_HEADER = "yyyy-MM-dd'T'HH:mm:ss.SSS";

    //    CONSUMER SERVICE:
    public static final String SUBJECT_TAG_TYPE_RISK_PROFILE = "SubjectTagType_RiskProfile";
    public static final int ROW_PAGE_NUMBER = 1;
    public static final int ROW_PAGE_LENGTH = 50;
    public static final String ABS_CODE = "ABS_EQ";
    public static final String RECORD_SET_ROW_FLAG = "MarkerType_subjectTags";
    public static final String TAG_TYPE_CODE = "SubjectTagType_RiskProfile";
    public static final String CAREFUL_RISK_PROFILE_IN_RUSSIAN = "Осторожный";
    public static final String MODERATELY_CONSERVATIVE_RISK_PROFILE_IN_RUSSIAN = "Умеренно-консервативный";


    // deposit operations:

    public static final String WORKFLOW_DEFAULT = "default";
    public static final String EVENT_TYPE_24 = "24";
    public static final String EVENT_TYPE_100 = "100";
    public static final String EVENT_TYPE_118 = "118";
    public static final String EVENT_TYPE_119 = "119";
    public static final String PARTIAL_DEMAND_DEPOSIT = "partialDemandDeposit";//27
    public static final String PARTIAL_DEPOSIT_CLAIM_WITH_DUL = "partialDepositClaimWithDul";//140
    public static final String PARTIAL_DEPOSIT_CLAIM_WITHOUT_DUL = "partialDepositClaimWithoutDul";//139
    public static final String FIRST_EVENT = "firstEvent";
    public static final String SECOND_EVENT = "secondEvent";
    public static final String EVENT_TYPE_KEY = "eventType";

    public static final String N = "N";
    public static final String Y = "Y";
    public static final String ACC_TYPE = "EL";
    public static final String DOCS_AD014 = "AD014";
    public static final String DOCS_AD001 = "AD001";
    public static final String DOCS_AD020 = "AD020";
    public static final String FREE_FORMAT_SEPARATOR = "|";
    public static final String SEMICOLON_DELIMITER = ";";
    public static final String MARKER_WAS_ESIGNING = "d";
    public static final String MARKER_WAS_NOT_ESIGNING = "m";

    public static final String ERROR_CODE_FIELD_RESPONSE = "errorCode";
    public static final String CLIENT_ID_FIELD_RESPONSE = "eqId";
    public static final String MSG_FIELD_RESPONSE = "msg";
    public static final String FULL_MSG_FIELD_RESPONSE = "fullMsg";
    public static final int MAX_APP_ID_SIZE = 32;

    // POA
    public static final String AVAILABLE_OPEN_DEPOSIT_CODE = "OD";
    public static final String POSSIBLE_DEBIT_ACCOUNT_CODE = "D";
    public static final String DEPOSIT_CODE = "02";
    public static final String POA_KEY_PARAMETER = "POA_LIST";


    @RequiredArgsConstructor
    public enum NumberGroupSeparator {
        SPACE(' '),
        NOSPACE('\0');

        public final char SEPARATOR;
    }

    @RequiredArgsConstructor
    public enum NumberDecimalSeparator {
        DOT('.'),
        COMMA(',');

        public final char SEPARATOR;
    }
}
