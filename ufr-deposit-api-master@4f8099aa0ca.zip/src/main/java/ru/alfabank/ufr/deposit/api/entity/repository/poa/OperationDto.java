package ru.alfabank.ufr.deposit.api.entity.repository.poa;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.Parameter;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class OperationDto {
    @Parameter(description = "Код вида операции.")
    private String codeOperationKind;

    @Parameter(description = "Наименование вида операции.")
    private String operationKindName;

    @Parameter(description = "Код типа операции.")
    private String operationType;

    @Parameter(description = "Наименование типа операции.")
    private String operationTypeName;

    @JsonProperty("bpoa")
    @Parameter(description = "Признак доступности операции для Банковской доверенности.")
    private Integer bPoa;

    @JsonProperty("npoa")
    @Parameter(description = "Признак доступности операции для Нотариальной/Иностранной доверенности.")
    private Integer nPoa;

    @JsonProperty("ibspoa")
    @Parameter(description = "Признак доступности операции для Банковской доверенности для ИБС.")
    private Integer ibsPoa;

    @Parameter(description = "Признак доступности операции для клиентов без ДКБО.")
    private Integer isAllowWithoutDkbo;

    @JsonProperty("apoa")
    @Parameter(description = "Признак доступности операции для Банковской доверенности Альфа Private.")
    private Integer aPoa;

    private String otherOperationTypeGroup;
}