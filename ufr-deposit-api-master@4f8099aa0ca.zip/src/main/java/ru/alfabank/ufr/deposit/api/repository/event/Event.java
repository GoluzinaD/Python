package ru.alfabank.ufr.deposit.api.repository.event;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import ru.alfabank.ufr.deposit.api.utils.Timestamp;

@Builder
@ToString
@Setter
@Getter
public class Event {

    // Тип события в СКД "Регистрация нового клиента"
    public static final String REGISTER_CLIENT_EVENT_TYPE = "19";
    // Тип события для оформления третьему лицу
    public static final String THIRD_PERSON_EVENT_TYPE = "21";

    private String type;

    private String sourceId;

    private String channelId;

    private String customerPinEq;

    private String managerId;

    private String operatorId;

    private String salePointId;

    private String freeFormat;

    private Timestamp time;

    private Timestamp startTime;

    private Timestamp callingTime;

    private String eventNumber;
    
    private String clientType;

    private String customerLocationId;

    private String packageCode;

    private String dealID;

    private String masterSys;

}
