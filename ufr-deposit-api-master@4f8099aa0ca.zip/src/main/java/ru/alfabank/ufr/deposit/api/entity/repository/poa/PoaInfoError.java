package ru.alfabank.ufr.deposit.api.entity.repository.poa;

import io.swagger.v3.oas.annotations.Parameter;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class PoaInfoError {
    @Parameter(description = "Сообщение об ошибке.")
    private String errorMessage;

    @Parameter(description = "EQ id пользователя в БД.")
    private String clientEqId;

    @Parameter(description = "Статус ошибки.")
    private String errorStatus;
}