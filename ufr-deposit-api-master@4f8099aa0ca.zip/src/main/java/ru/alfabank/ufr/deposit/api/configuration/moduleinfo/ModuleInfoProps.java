package ru.alfabank.ufr.deposit.api.configuration.moduleinfo;

import lombok.Data;
import lombok.experimental.Accessors;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.Collections;
import java.util.List;

@Data
@Accessors(chain = true)
public class ModuleInfoProps {

    private ModuleProperty module;
    private AvailableFor availableFor;

    @Data
    @Accessors(chain = true)
    public static class AvailableFor {
        private NamesIncludeExcept cus;
        private NamesIncludeExcept opLogin;
        private NamesIncludeExcept clientType;
    }

    @Data
    public static class NamesIncludeExcept {
        private List<String> include = Collections.emptyList();
        private List<String> except = Collections.emptyList();
    }
}
