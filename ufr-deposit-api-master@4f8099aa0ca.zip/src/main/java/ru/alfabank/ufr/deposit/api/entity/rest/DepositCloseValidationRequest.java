package ru.alfabank.ufr.deposit.api.entity.rest;

import io.swagger.v3.oas.annotations.Parameter;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class DepositCloseValidationRequest {
    @Parameter(description = "Мнемоника отделения пользователя.\n" +
            "\n" +
            "Для получения мнемоники используется микросервис ufr-ad-api (метод api/employees/{username}, выходной параметр eqMnemonic)."
            , example = "MOPV")
    @NotNull
    private String brnm;

    @Parameter(description = "Тип сделки\n" +
            "\n" +
            "Заполняется значением выходного параметра depositType функции Получение списка депозитов клиента."
            , example = "AQ3")
    @NotNull
    private String dlp;

    @Parameter(description = "Номер (шифр) сделки.\n" +
            "\n" +
            "Заполняется значением выходного параметра depositNumber функции Получение списка депозитов клиента."
            , example = "AQVX7Q101090B")
    @NotNull
    private String dlr;

    @Parameter(description = "Признак \"Возвращать налог?\"\n" +
            "\n" +
            "Y\n" +
            "\n" +
            "Значение настраивается в конфигурации."
            , example = "Y")
    @NotNull
    private String tax;
}
