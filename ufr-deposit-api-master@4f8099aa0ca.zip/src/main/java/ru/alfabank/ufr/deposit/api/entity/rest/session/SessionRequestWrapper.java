package ru.alfabank.ufr.deposit.api.entity.rest.session;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@AllArgsConstructor
public class SessionRequestWrapper<T extends SessionAbstractRequest> {

    private T request;
}
