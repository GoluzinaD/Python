package ru.alfabank.ufr.deposit.api.entity.rest.depositClaim;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DepositClaimRequest {
    @NotBlank
    private String userId;
    @NotBlank
    private String branchNumber;
    @NotBlank
    private String eqId;
    @NotBlank
    private String operatorLogin;
    @NotBlank
    private String sessionToken;
    @NotBlank
    private String userBranch;
    @NotBlank
    private String branch; //brnm
    @NotBlank
    private String depositType; //dlp
    @NotBlank
    private String depositNumber; // dlr
    @NotBlank
    private String depositBranch;
    @NotBlank
    private String depositBasicAccountNumber;
    @NotBlank
    private String depositSuffix;
    @NotNull
    private BigDecimal sumOfWithdrawal;
    private String barcode;
    @NotBlank
    private String wasESigning;
    private String eventNumber;
    @NotBlank
    private String needDULScan;
    @NotBlank
    private String workflow;
    @NotBlank
    private String eand;

    private Boolean shouldSkipCreateEvent;
}