package ru.alfabank.ufr.deposit.api.entity.rest;

import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Date;
import java.util.List;

@Component
public class FactoryFetchedProducts {
    public FetchedProducts createFromAccountDepositList(List<AccountDeposit> depositsList) {
        return new FetchedProducts()
                .setFetchedAll(true)
                .setFetchedProductList(depositsList)
                .setTimestamp(Date.from(Instant.now()));
    }
}
