package ru.alfabank.ufr.deposit.api.entity.repository.event;

import lombok.Data;

@Data
public class CloseDeposit {
    private String callingTime;
    private String channelId;
    private String customerLocationId;
    private String customerPinEq;
    private String dealID;
    private String eventNumber;
    private String freeFormat;
    private String managerId;
    private String masterSys;
    private String operatorId;
    private String salePointId;
    private String sourceId;
    private String startTime;
    private String time;
    private String type;
}
