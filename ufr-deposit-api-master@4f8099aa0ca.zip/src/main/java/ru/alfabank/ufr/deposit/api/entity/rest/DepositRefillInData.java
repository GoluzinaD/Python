package ru.alfabank.ufr.deposit.api.entity.rest;

import lombok.Data;
import ru.alfabank.ufr.deposit.api.utils.OneOfNullable;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

@Data
public class DepositRefillInData {
    @NotNull
    private String userBranch;
    @NotNull
    private String brnm;
    @NotNull
    private String dlp;
    @NotNull
    private String dlr;
    @NotNull
    private BigDecimal sum;
    @NotNull
    private String expressAccount;
    @OneOfNullable(allowed = {"Y", "y", "N", "n"})
    private String wasRURTransfer;
    @OneOfNullable(allowed = {"Y", "y", "N", "n"})
    private String wasForeignCurrTransfer;
    private String debetAccNum;
    private String debetAccCurrency;
    private BigDecimal convertedDebetSum;
    private BigDecimal rate;
    private String servicePacketName;
    private String servicePacketCode;
    private String poaPopolTransferStartDate;
    private String poaPopolTransferNumber;
    private String poaPopolStartDate;
    private String poaPopolNumber;
    private String poaFIO;
    private Boolean writeEventToSession;
    private Boolean createBusinessEvent;
}
