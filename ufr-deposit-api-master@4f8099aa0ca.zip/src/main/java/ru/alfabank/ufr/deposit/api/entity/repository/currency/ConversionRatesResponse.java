package ru.alfabank.ufr.deposit.api.entity.repository.currency;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class ConversionRatesResponse {
    // Сумма в валюте конверсии
    private BigDecimal amountOut;
    // Курс конверсии
    private BigDecimal exRateOne;
    // Значение валюты курса конвертации (слабой валюты)
    private String currencyRate;
}