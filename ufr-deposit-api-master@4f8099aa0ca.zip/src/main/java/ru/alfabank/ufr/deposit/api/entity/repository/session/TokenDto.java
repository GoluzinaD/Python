package ru.alfabank.ufr.deposit.api.entity.repository.session;

import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class TokenDto {
    @NotBlank
    private String token;
}