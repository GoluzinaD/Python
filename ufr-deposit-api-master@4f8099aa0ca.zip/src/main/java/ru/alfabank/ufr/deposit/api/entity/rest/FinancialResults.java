package ru.alfabank.ufr.deposit.api.entity.rest;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class FinancialResults {
    private FinancialResult finResultAll;
    private FinancialResult finResultYearly;
    private FinancialResult finResultCurrentYear;
}
