package ru.alfabank.ufr.deposit.api.repository.client;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import ru.alfabank.ufr.deposit.api.entity.rest.*;
import ru.alfabank.ufr.deposit.api.repository.exceptions.DepositsRecievingException;
import ru.alfabank.ufr.deposit.api.repository.exceptions.UserNotFoundException;
import ru.alfabank.ufr.deposit.api.utils.UriResolver;

import javax.annotation.PostConstruct;
import javax.xml.bind.JAXBContext;
import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Slf4j
@Repository
@Primary
@RequiredArgsConstructor
public class ClientDepositsRestRepository implements ClientDepositsRepository {
    private final RestTemplate restTemplate;
    private final UriResolver uriResolver;
    private final FactoryFetchedProducts factoryFetchedProducts;
    @Value("${logParams.inout:false}")
    private boolean logRecevied;
    private static ObjectMapper JACKSON_MAPPER = new ObjectMapper();

    @Value("${interaction.clientDepositsApi.rest.systemCode}")
    private String systemCode;
    @Value("${interaction.clientDepositsApi.rest.userCode}")
    private String userCode;
    @Value("${interaction.clientDepositsApi.rest.userId}")
    private String userId;
    @Value("${interaction.clientDepositsApi.rest.branchNumber}")
    private String branchNumber;

    @PostConstruct
    private void init () {
        log.info("Used {} as deposits repository", this.getClass().getCanonicalName());
    }

    @Override
    public FetchedProducts getClientDeposits(String clientId, String channelCode, String languageMnemonic) {
        return factoryFetchedProducts.createFromAccountDepositList(getClientAccountDeposits(clientId, false));
    }

    public FetchedProducts getClientDeposits(String clientId, String channelCode, String languageMnemonic, Boolean isClosed) {
        return factoryFetchedProducts.createFromAccountDepositList(getClientAccountDeposits(clientId, isClosed));
    }

    @Override
    public DepositCreateOutData createDeposit(DepositCreateInData inData) {
        throw new UnsupportedOperationException("Not implemented for REST repository!");
    }

    private List<AccountDeposit> getClientAccountDeposits(String clientId, Boolean isClosed) {
        AccountDepositRestResponse response = retrieveDepositsForClient(clientId);
        if(logRecevied) {
            response.getResultSetRow().stream().forEach(o -> {
                try {
                    log.info("Received deposit: {}", JACKSON_MAPPER.writeValueAsString(o));
                } catch (JsonProcessingException e1) {
                    log.warn("Received deposit could not be parsed into json! ClientId: {}, deposit NEEAN: {}",
                            clientId, o.getNeeandeposit());
                }
            });
        }
        return response.getResultSetRow().stream()
                .filter(a -> !isClosed || "Y".equals(a.getIsclosed()) || "D".equals(a.getIsclosed()))
                .map(FactoryDeposit::createFromRESTApiResponse)
                .collect(Collectors.toList());
    }

    private AccountDepositRestResponse retrieveDepositsForClient(String clientId) throws UserNotFoundException, DepositsRecievingException {
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.add("X-External-System-Code", systemCode);
        headers.add("X-External-User-Code", userCode);
        headers.add("X-UserID", userId);
        headers.add("X-BranchNumber", branchNumber);
        try {
            ResponseEntity<String> stringResponseEntity = restTemplate.exchange(
                    uriResolver.uriDepositsRestApi(clientId),
                    HttpMethod.GET,
                    new HttpEntity<>(headers),
                    String.class);
            String stringResponseEntityBody = stringResponseEntity.getBody();
            byte[] bytes = Objects.requireNonNull(stringResponseEntityBody)
                    .getBytes(StandardCharsets.ISO_8859_1);
            AccountDepositRestResponse response = (AccountDepositRestResponse) JAXBContext
                    .newInstance(AccountDepositRestResponse.class)
                    .createUnmarshaller()
                    .unmarshal(new ByteArrayInputStream(bytes));
            log.info("rest response {}", response);
            return response;
        } catch (HttpClientErrorException e) {
            if(e.getStatusCode() == HttpStatus.NOT_FOUND) {
                log.warn("Client {} not found with deposits rest api ({})", clientId, uriResolver.uriDepositsRestApi(clientId));
                throw new UserNotFoundException(clientId, e);
            }
            log.error("Retrieving deposits from rest api ({}): exception occurs: {}",
                    uriResolver.uriDepositsRestApi(clientId), e);
            throw new DepositsRecievingException(clientId, e);
        } catch (Exception e) {
            log.error("Retrieving deposits from rest api ({}): exception occurs: {}",
                    uriResolver.uriDepositsRestApi(clientId), e);
            throw new DepositsRecievingException(clientId, e);
        }
    }

}
