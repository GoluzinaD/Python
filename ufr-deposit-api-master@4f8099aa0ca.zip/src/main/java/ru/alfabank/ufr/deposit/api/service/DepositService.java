package ru.alfabank.ufr.deposit.api.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.mapstruct.Mapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import ru.alfabank.api.deposit.principal.DepositPrincipalAddResponse;
import ru.alfabank.ufr.deposit.api.configuration.DepositRefillParams;
import ru.alfabank.ufr.deposit.api.entity.repository.accounts.Account;
import ru.alfabank.ufr.deposit.api.entity.repository.ad.Employee;
import ru.alfabank.ufr.deposit.api.entity.repository.currency.ConversionRatesResponse;
import ru.alfabank.ufr.deposit.api.entity.repository.depositPrincipal.DepositPrincipalClaimRequest;
import ru.alfabank.ufr.deposit.api.entity.repository.operation.OperationType;
import ru.alfabank.ufr.deposit.api.entity.repository.session.CustomEventDataDto;
import ru.alfabank.ufr.deposit.api.entity.repository.session.EventDto;
import ru.alfabank.ufr.deposit.api.entity.rest.AvailableDepositTypes;
import ru.alfabank.ufr.deposit.api.entity.rest.DepositCloseInData;
import ru.alfabank.ufr.deposit.api.entity.rest.DepositCloseResponse;
import ru.alfabank.ufr.deposit.api.entity.rest.DepositCloseValidationParams;
import ru.alfabank.ufr.deposit.api.entity.rest.DepositCloseValidationRequest;
import ru.alfabank.ufr.deposit.api.entity.rest.DepositCreateInData;
import ru.alfabank.ufr.deposit.api.entity.rest.DepositCreateOutData;
import ru.alfabank.ufr.deposit.api.entity.rest.DepositCreateRESTRequestData;
import ru.alfabank.ufr.deposit.api.entity.rest.DepositInfo;
import ru.alfabank.ufr.deposit.api.entity.rest.DepositRefillInData;
import ru.alfabank.ufr.deposit.api.entity.rest.DepositVariantsRequest;
import ru.alfabank.ufr.deposit.api.entity.rest.FetchedProducts;
import ru.alfabank.ufr.deposit.api.entity.rest.OpenedDepositDetails;
import ru.alfabank.ufr.deposit.api.entity.rest.depositClaim.DepositClaimRequest;
import ru.alfabank.ufr.deposit.api.entity.rest.depositClaim.DepositClaimResponse;
import ru.alfabank.ufr.deposit.api.repository.accounts.AccountsApi;
import ru.alfabank.ufr.deposit.api.repository.ad.AdApiRepository;
import ru.alfabank.ufr.deposit.api.repository.client.ClientDepositsRestRepository;
import ru.alfabank.ufr.deposit.api.repository.client.ClientDepositsSOAPRepository;
import ru.alfabank.ufr.deposit.api.repository.close.ClosingDepositRepository;
import ru.alfabank.ufr.deposit.api.repository.currency.DepositCurrencyApi;
import ru.alfabank.ufr.deposit.api.repository.depositPrincipal.DepositPrincipalRepository;
import ru.alfabank.ufr.deposit.api.repository.event.Event;
import ru.alfabank.ufr.deposit.api.repository.event.EventRepository;
import ru.alfabank.ufr.deposit.api.repository.opened.OpenedDepositRepository;
import ru.alfabank.ufr.deposit.api.repository.operation.OperationTypeGetter;
import ru.alfabank.ufr.deposit.api.repository.refill.RefillDepositRepository;
import ru.alfabank.ufr.deposit.api.repository.session.SessionRepository;
import ru.alfabank.ufr.deposit.api.repository.types.DepositTypesRepository;
import ru.alfabank.ufr.deposit.api.repository.variants.DepositVariantsRepository;
import ru.alfabank.ufr.deposit.api.service.exceptions.CreateDepositException;
import ru.alfabank.ufr.deposit.api.service.exceptions.DepositCloseException;
import ru.alfabank.ufr.deposit.api.service.exceptions.RefillDepositException;
import ru.alfabank.ufr.deposit.api.utils.DtoConverter;
import ru.alfabank.ufr.deposit.api.utils.EventFactory;
import ru.alfabank.ufr.deposit.api.utils.NumberOps;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.util.*;

import static java.math.BigDecimal.ZERO;
import static java.math.RoundingMode.HALF_UP;
import static java.util.Optional.ofNullable;
import static org.apache.commons.lang3.StringUtils.EMPTY;
import static ru.alfabank.ufr.deposit.api.configuration.Constants.EVENT_TYPE_100;
import static ru.alfabank.ufr.deposit.api.configuration.Constants.EVENT_TYPE_118;
import static ru.alfabank.ufr.deposit.api.configuration.Constants.EVENT_TYPE_119;
import static ru.alfabank.ufr.deposit.api.configuration.Constants.EVENT_TYPE_24;
import static ru.alfabank.ufr.deposit.api.configuration.Constants.FIRST_EVENT;
import static ru.alfabank.ufr.deposit.api.configuration.Constants.N;
import static ru.alfabank.ufr.deposit.api.configuration.Constants.SECOND_EVENT;
import static ru.alfabank.ufr.deposit.api.configuration.Constants.WORKFLOW_DEFAULT;
import static ru.alfabank.ufr.deposit.api.configuration.Constants.Y;
import static ru.alfabank.ufr.deposit.api.utils.Predicates.isGreaterThan;

@Slf4j
@Component
@RequiredArgsConstructor
public class DepositService {
    private final ClientDepositsRestRepository clientDepositsRestRepository;
    private final ClientDepositsSOAPRepository clientDepositsSOAPRepository;
    private final DepositTypesRepository depositTypesRepository;
    private final DepositVariantsRepository depositVariantsRepository;
    private final OpenedDepositRepository openedDepositRepository;
    private final ClosingDepositRepository closingDepositRepository;
    private final EventRepository eventRepository;
    private final AdApiRepository adApiRepository;
    private final AccountsApi accountsApi;
    private final RefillDepositRepository refillDepositRepository;
    private final MessageSource messageSource;
    private final EventFactory eventFactory;
    private final SessionRepository sessionRepository;
    private final DepositRefillParams depositRefillParams;
    private final DepositPrincipalRepository depositPrincipalRepository;
    private final DtoConverter dtoConverter;
    private final CreateDepositRequestMapper createDepositRequestMapper;
    private final DepositIdGenerator depositIdGenerator;
    private final DepositCurrencyApi depositCurrencyApi;
    private final OperationTypeGetter operationTypeGetter;

    public static final String DEP_FILL_INC = "Y";
    public static final String DEP_FILL_NDA = "Y";

    // 1970.01.01
    private static final Date PROLONG_DATE_INVALID_MIN = Date.from(Instant.EPOCH);


    @Value("${interaction.accountsApi.accountList.params.operationTypes}")
    private String[] operationTypesAccountList;
    @Value("${interaction.accountsApi.accountList.params.act}")
    private String[] actAccountList;


    public AvailableDepositTypes getAllAvailableDepositTypes(String clientType, String[] depositCurrencies, String servicePackageCode,
                                                             String mainAccountOpened) {
        return depositTypesRepository.getAvailableDepositTypes(clientType, depositCurrencies, servicePackageCode, mainAccountOpened);
    }

    public List<DepositInfo> getDepositVariants(DepositVariantsRequest variantsRequest) {
        return depositVariantsRepository.getDepositVariantsOfType(variantsRequest);
    }

    @Mapper(componentModel = "spring")
    public interface CreateDepositRequestMapper {
        DepositCreateInData convert(DepositCreateRESTRequestData request);
    }

    public DepositCreateOutData createDeposit(DepositCreateRESTRequestData request) {
        DepositCreateInData inData = createDepositRequestMapper.convert(request);
        inData.setDlr(depositIdGenerator.getNextId(request.getBcus()));
        DepositCreateOutData outData;
        try {
            outData = clientDepositsSOAPRepository.createDeposit(inData);
        } catch (Exception e) {
            throw new CreateDepositException(e);
        }
        return outData;
    }

    public FetchedProducts getClientDeposits(String clientId, String channelCode, String languageMnemonic) {
        return clientDepositsSOAPRepository.getClientDeposits(clientId, channelCode, languageMnemonic);
    }

    public FetchedProducts getClientRestDeposits(String clientId, String channelCode, String languageMnemonic, Boolean isClosed) {
        return clientDepositsRestRepository.getClientDeposits(clientId, channelCode, languageMnemonic, isClosed);
    }

    public OpenedDepositDetails getOpenedDepositDetails(String brnm, String dlp, String dlr, String xm, String lnm) {
        return openedDepositRepository.getDetails(brnm, dlp, dlr, xm, lnm);
    }

    public OpenedDepositDetails getFullOpenedDepositDetails(String brnm, String dlp, String dlr, String xm, String lnm) {
        OpenedDepositDetails openedDepositDetails = getOpenedDepositDetails(brnm, dlp, dlr, xm, lnm);
        enrichOpenedDepositDetails(openedDepositDetails);
        return openedDepositDetails;
    }

    public DepositCloseValidationParams getDepositCloseValidationParams(DepositCloseValidationRequest request) {
        return closingDepositRepository.getCloseValidationParams(request);
    }

    public DepositCloseResponse closeDeposit(DepositCloseInData request) {
        try {
            DepositCloseResponse depositCloseResponse = new DepositCloseResponse();
            Employee employee = adApiRepository.getEmployee(request.getOperatorLogin());
            closingDepositRepository.closeDeposit(request, employee.getEqProfile(), employee.getEqNumber());
            eventRepository.createEvent(eventFactory.getDepositCloseEvent(request, EVENT_TYPE_24));
            if (WORKFLOW_DEFAULT.equals(request.getWorkflow())) {
                depositCloseResponse.setNeedDULScan(N);
                return depositCloseResponse;
            }

            String type;
            if (N.equals(request.getNeedDULScan())) {
                type = EVENT_TYPE_118;
            } else {
                type = EVENT_TYPE_119;
            }

            if (!Boolean.TRUE.equals(request.getShouldSkipCreateEvent())) {
                try {
                    eventRepository.createEvent(eventFactory.getDepositCloseEvent(request, type));
                } catch (Exception e) {
                    log.error("", e);
                }
            }
            depositCloseResponse.setNeedDULScan(request.getNeedDULScan());

            if (!Boolean.TRUE.equals(request.getShouldSkipCreateEvent())) {
                if (Y.equals(request.getWasSecondDoc())) {
                    eventRepository.createEvent(eventFactory.getDepositCloseEvent(request, EVENT_TYPE_100));
                }
            }

            return depositCloseResponse;
        } catch (Exception e) {
            throw new DepositCloseException(e);
        }
    }

    public BigDecimal refillDeposit(String cus, String opLogin, String sessionToken, DepositRefillInData inData, Locale locale) {
        try {
            Employee employee = adApiRepository.getEmployee(opLogin);
            final String expressAccountNumber = new String(Base64.getDecoder().decode(inData.getExpressAccount()));
            Set<Account> userAccounts = accountsApi.getAccountListByPinEq(cus, operationTypesAccountList, actAccountList);
            Account expressAccount = userAccounts.stream()
                    .filter(a -> a.getAccountNumber().equals(expressAccountNumber))
                    .reduce((a, b) -> {
                        throw new IllegalStateException(messageSource.getMessage(
                                "depositService.multipleExpressAccountsFound", new String[]{expressAccountNumber},
                                locale));
                    })
                    .orElseThrow(() -> new RuntimeException(messageSource.getMessage(
                            "depositService.refillDepositExpressAccountNotFound", new String[]{expressAccountNumber},
                            locale)));
            final String branchId = expressAccount.getBranchId();
            final String accountOwner = expressAccount.getAccountOwner();
            final String accountSuffix = expressAccount.getAccountSuffix();

            var depositInfo = this.getOpenedDepositDetails(inData.getBrnm(), inData.getDlp(), inData.getDlr(),
                    depositRefillParams.getXm(), depositRefillParams.getLnm());

            final BigDecimal operationNumber = refillDepositRepository.refill(new RefillDepositRepository.Input()
                    .setDlp(inData.getDlp())
                    .setDlr(inData.getDlr())
                    .setBrnm(inData.getBrnm())
                    .setCus(cus)
                    .setInc(DEP_FILL_INC)
                    .setAbf(branchId)
                    .setAnf(accountOwner)
                    .setAsf(accountSuffix)
                    .setNwr(inData.getSum())
                    .setAdj(inData.getSum())
                    .setNda(DEP_FILL_NDA)
                    .setBranchNumber(employee.getEqNumber())
                    .setUserID(employee.getEqProfile())
            );

            final ConversionRatesResponse conversion = StringUtils.equals(depositInfo.getScccy(), inData.getDebetAccCurrency())
                    ? null
                    : depositCurrencyApi.getLatestConversion(depositInfo.getScccy(), inData.getDebetAccCurrency(), new BigDecimal(1000));

            if (BooleanUtils.isNotFalse(inData.getWriteEventToSession())) {
                sessionRepository.addEvent(EventDto.builder().token(sessionToken).event(
                        new CustomEventDataDto()
                                .setCustomFields(generateCustomFields(depositInfo, inData, conversion))
                                .setCustomType(depositRefillParams.getSessionEvent().getCustomType())
                                .setDateTime(ZonedDateTime.now())
                                .setEventType(depositRefillParams.getSessionEvent().getEventType())
                ).build());
            }

            if (BooleanUtils.isNotFalse(inData.getCreateBusinessEvent())) {
                eventRepository.createEvent(eventFactory.getEventRefillDeposit(cus, opLogin, inData));
            }

            return operationNumber;
        } catch (Exception e) {
            throw new RefillDepositException(e);
        }
    }

    Map<String, String> generateCustomFields(OpenedDepositDetails depositDetails, DepositRefillInData inData, ConversionRatesResponse conversion) {
        final SimpleDateFormat commonDateFormat = new SimpleDateFormat(depositRefillParams.getSessionEvent().getCommonDateFormat());
        final DecimalFormatSymbols formatSymbols = new DecimalFormatSymbols();
        formatSymbols.setDecimalSeparator(depositRefillParams.getSessionEvent().getNumberDecimalSeparator().SEPARATOR);
        formatSymbols.setGroupingSeparator(depositRefillParams.getSessionEvent().getNumberGroupSeparator().SEPARATOR);
        final DecimalFormat decimalFormat = new DecimalFormat("###,##0.00", formatSymbols);
        var depositRefillSum = NumberOps.dividedBy100(inData.getSum());
        var depositSum = NumberOps.dividedBy100(depositDetails.getV5Bal());
        Map<String, String> f = new HashMap<>();

        f.put("refill_depositName", depositDetails.getNm1());
        f.put("refill_depositCurrency", depositDetails.getScccy());
        f.put("refill_depositTerm", depositDetails.getTermdescr());
        f.put("refill_lastProlDate", ofNullable(depositDetails.getV5Lre()).filter(this::prolongationDateIsValid).map(commonDateFormat::format).orElse(EMPTY));
        final boolean isSameDay = ofNullable(depositDetails.getV5Lre()).map(d -> DateUtils.isSameDay(new Date(), d)).orElse(false);
        f.put("refill_prolDateRefill", isSameDay ? Y : N);
        f.put("refill_nextProlDate", commonDateFormat.format(depositDetails.getV5Nrd()));
        f.put("refill_depositRefillSum", decimalFormat.format(depositRefillSum));
        f.put("refill_depositSum", decimalFormat.format(depositSum));
        f.put("refill_depositSumAfterRefill", decimalFormat.format(depositSum.add(depositRefillSum)));
        f.put("refill_depositOpeningSum", decimalFormat.format(NumberOps.dividedBy100(depositDetails.getOtdla2())));
        f.put("refill_depositOpeningSum2", decimalFormat.format(NumberOps.dividedBy100(depositDetails.getStsum())));

        f.put("refill_capitalization", depositDetails.getCpi());
        f.put("refill_prolongation", depositDetails.getProl());
        f.put("refill_wasRURTransfer", ofNullable(inData.getWasRURTransfer()).orElse(EMPTY));
        f.put("refill_wasForeignCurrTransfer", ofNullable(inData.getWasForeignCurrTransfer()).orElse(EMPTY));
        f.put("refill_debetAccNum", ofNullable(inData.getDebetAccNum()).orElse(EMPTY));
        f.put("refill_convertedDebetSum", ofNullable(inData.getConvertedDebetSum()).map(decimalFormat::format).orElse(EMPTY));
        f.put("refill_debetAccCurrency", ofNullable(inData.getDebetAccCurrency()).orElse(EMPTY));
        f.put("refill_rate", ofNullable(inData.getRate()).map(BigDecimal::toPlainString).orElse(EMPTY));
        f.put("refill_depositAccNum", depositDetails.getNeean());
        f.put("refill_ExpressAccNum", new String(Base64.getDecoder().decode(inData.getExpressAccount())));
        f.put("refill_depositNumber", inData.getDlr());
        f.put("refill_depositOpenDate", depositDetails.getAccrual().getGraphic().stream().findFirst().map(OpenedDepositDetails.Accrual.Entry::getOmdte)
                .map(commonDateFormat::format).orElseGet(() -> {
                    log.error("Empty accrual graphic got!");
                    return "";
                }));
        f.put("refill_depositOpenDate2", commonDateFormat.format(depositDetails.getDdst()));
        f.put("refill_depositEndDate", commonDateFormat.format(depositDetails.getDdend()));
        f.put("refill_totalRate", getRateSafe(depositDetails.getV5Rat()));
        f.put("refill_baseRate", getRateSafe(depositDetails.getBrat()));
        f.put("refill_additionalRate", getRateSafe(depositDetails.getDrat()));
        f.put("refill_servicePacketName", ofNullable(inData.getServicePacketName()).orElse(EMPTY));
        f.put("refill_servicePacketCode", ofNullable(inData.getServicePacketCode()).orElse(EMPTY));
        f.put("refill_totalCapitalizationRate", getRateSafe(depositDetails.getTotalint().setScale(2, HALF_UP)));
        f.put("refill_minimalBalance", Y.equalsIgnoreCase(depositDetails.getSnt())
                ? decimalFormat.format(NumberOps.dividedBy100(depositDetails.getMinbal()))
                : EMPTY);
        f.put("refill_maximalSum",
                Optional.of(depositDetails.getMaxsum())
                        .filter(isGreaterThan(ZERO))
                        .map(NumberOps::dividedBy100)
                        .map(decimalFormat::format)
                        .orElse(EMPTY)
        );
        f.put("refill_allowedReplenishmentDate", shouldAllowedReplenishmentDateBeFilled(depositDetails)
                ? commonDateFormat.format(DateUtils.addDays(new Date(), depositDetails.getDinclast().toBigInteger().intValue()))
                : EMPTY
        );
        f.put("refill_poaPopolTransferStartDate", ofNullable(inData.getPoaPopolTransferStartDate()).orElse(EMPTY));
        f.put("refill_poaPopolTransferNumber", ofNullable(inData.getPoaPopolTransferNumber()).orElse(EMPTY));
        f.put("refill_poaPopolStartDate", ofNullable(inData.getPoaPopolStartDate()).orElse(EMPTY));
        f.put("refill_poaPopolNumber", ofNullable(inData.getPoaPopolNumber()).orElse(EMPTY));
        f.put("poaFIO", ofNullable(inData.getPoaFIO()).orElse(EMPTY));
        f.put("refill_currencyRate", ofNullable(conversion).map(ConversionRatesResponse::getCurrencyRate).orElse(depositDetails.getScccy()));
        return f;
    }

    private String getRateSafe(BigDecimal rate) {
        return ofNullable(rate).filter(isGreaterThan(ZERO))
                .map(BigDecimal::stripTrailingZeros)
                .map(BigDecimal::toPlainString)
                .orElse(EMPTY);
    }

    private boolean shouldAllowedReplenishmentDateBeFilled(OpenedDepositDetails depositDetails) {
        return depositDetails.getPopol().equalsIgnoreCase("Y")
                && depositDetails.getDinclast().compareTo(ZERO) >= 0;
    }

    private boolean prolongationDateIsValid(Date d) {
        return PROLONG_DATE_INVALID_MIN.before(d);
    }

    public DepositClaimResponse claim(DepositClaimRequest request) {

        DepositPrincipalClaimRequest depositPrincipalClaimRequest = dtoConverter.createDepositPrincipalApiClaimRequest(request);

        DepositClaimResponse response = new DepositClaimResponse();
        log.info("request is {}, depositPrincipalApi call", request);
        DepositPrincipalAddResponse principalAddResponse = depositPrincipalRepository.claim(depositPrincipalClaimRequest);
        response.setSequenceNumber(principalAddResponse.getSequenceNumber());
        try {
            log.info("request is {}, first eventApi call", request);
            Event firstEvent = eventRepository.createEvent(eventFactory.getEventDepositClaim(request, FIRST_EVENT));
            log.info("firstEvent is {}, request is {}", firstEvent, request);
        } catch (Exception e) {
            log.warn("request is {}, eventApi call error", request);
            if (WORKFLOW_DEFAULT.equals(request.getWorkflow())) {
                response.setNeedDULScan(N);
                return response;
            }
        }

        if (!Boolean.TRUE.equals(request.getShouldSkipCreateEvent())) {
            try {
                log.info("request is {}, second eventApi call", request);
                eventRepository.createEvent(eventFactory.getEventDepositClaim(request, SECOND_EVENT));
            } catch (Exception e) {
                log.warn("request is {}, eventApi call error", request);
                log.error("", e);
            }
            response.setNeedDULScan(request.getNeedDULScan());
        }
        return response;
    }

    public void enrichOpenedDepositDetails(OpenedDepositDetails openedDepositDetails) {
        log.info("enriching opened deposit details for {}", openedDepositDetails);
        openedDepositDetails.getAccrual()
                .getGraphic()
                .forEach(grafics -> grafics.setOperationName(getOperationName(grafics.getEvent().toString())));
    }

    private String getOperationName(String event) {
        OperationType operationType = operationTypeGetter.getOperationType(event);
        log.info("operationType for {} is {}", event, operationType);
        return operationType == null ? EMPTY : operationType.getOperationName();
    }
}

