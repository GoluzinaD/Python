package ru.alfabank.ufr.deposit.api.entity.rest;

import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.math.BigDecimal;

@Data
@Accessors(chain = true)
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class Amount {
    @Deprecated
    private BigDecimal amountReal;
    private BigDecimal amountInMinorUnits;
    private int minority;
    private String currencyCode;

    public Amount(BigDecimal amountInMinorUnits, int minority, String currencyCode) {
        this.amountInMinorUnits = amountInMinorUnits;
        this.minority = minority;
        this.currencyCode = currencyCode;
        this.amountReal = amountInMinorUnits.divide(new BigDecimal(Integer.toString(minority)));
    }
}
