package ru.alfabank.ufr.deposit.api.repository.depositPrincipal;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;
import ru.alfabank.api.deposit.principal.DepositPrincipalAddCommandFactory;
import ru.alfabank.api.deposit.principal.DepositPrincipalAddRequest;
import ru.alfabank.api.deposit.principal.DepositPrincipalAddResponse;
import ru.alfabank.ufr.deposit.api.entity.repository.depositPrincipal.DepositPrincipalClaimRequest;
import ru.alfabank.ufr.deposit.api.utils.WS;
import ru.alfabank.ws.cs.eq.wsdepositprincipal10.WSDepositPrincipalPortType;
import ru.alfabank.ws.cs.wscommontypes10.WSCommonParms;

@Slf4j
@Repository
public class DepositPrincipalApiRepository implements DepositPrincipalRepository {
    private final WSCommonParms commonParms;
    private final DepositPrincipalAddCommandFactory principalAddCommandFactory;
    private final int timeout;

    @Autowired
    public DepositPrincipalApiRepository(WSCommonParms commonParms, WSDepositPrincipalPortType portType,
                                         @Value("${hystrix.command.default.execution.isolation.thread.timeoutInMilliseconds}") int timeout) {
        this.commonParms = commonParms;
        this.principalAddCommandFactory = new DepositPrincipalAddCommandFactory(commonParms, timeout, portType);
        this.timeout = timeout;
    }

    @Override
    public DepositPrincipalAddResponse claim(DepositPrincipalClaimRequest request) {
        DepositPrincipalAddRequest req = getRequest(request);
        log.info("DepositPrincipalAddRequest - {}", req);
        return principalAddCommandFactory.getCommand(
                WS.duplicateAndReplaceWithNotBlank(commonParms, request.getBranchNumber(), request.getUserId()),
                req,
                timeout).execute();
    }

    private DepositPrincipalAddRequest getRequest(DepositPrincipalClaimRequest request) {
        return DepositPrincipalAddRequest.builder()
                .branchMnemonic(request.getBranch())
                .dealType(request.getDepositType())
                .dealReference(request.getDepositNumber())
                .customerMnemonic(request.getCus())
                .customerLocation(request.getClc())
                .increase(request.getInc())
                .payAmount(request.getSumOfWithdrawal())
                .exceedTransactionAmount(request.getSumOfWithdrawal())
                .narrativeAccountPosting(request.getNda())
                .build();
    }
}