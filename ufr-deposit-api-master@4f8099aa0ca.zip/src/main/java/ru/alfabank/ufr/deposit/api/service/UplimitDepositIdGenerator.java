package ru.alfabank.ufr.deposit.api.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import ru.alfabank.ufr.deposit.api.repository.counter.DepositCounter;

import java.util.Date;

@Service
@RequiredArgsConstructor
public class UplimitDepositIdGenerator implements DepositIdGenerator {
    private static final String DEPOSIT_ID_DATE_STRING_FORMAT = "%1$td%1$tm%2$d";
    private static final int DEPOSIT_ID_SERIAL_NUMBER_MAX_VALUE = 0xFF;

    private final DepositCounter counter;

    @Override
    public String getNextId(String cus) {
        return String.format("%1$S%2$S%3$S", formattedCUS(cus), formattedDate(new Date()), formattedSerialNumber(counter, cus));
    }

    private String formattedSerialNumber(DepositCounter counter, String cus) {
        final int serialNumber = counter.getNext(cus);
        validateSerialNumber(serialNumber);
        return String.format("%02X",serialNumber);
    }

    private void validateSerialNumber(final int serialNumber) {
        if(serialNumber > DEPOSIT_ID_SERIAL_NUMBER_MAX_VALUE) {
            throw new RuntimeException(String.format("Serial number of deposit (%s) exceeds maximal allowed value of %s!",
                    serialNumber, DEPOSIT_ID_SERIAL_NUMBER_MAX_VALUE));
        }
    }

    private String formattedDate(Date date) {
        return String.format(DEPOSIT_ID_DATE_STRING_FORMAT, date, date.getYear() % 10);
    }

    private String formattedCUS(final String cus) {
        return cus;
    }
}
