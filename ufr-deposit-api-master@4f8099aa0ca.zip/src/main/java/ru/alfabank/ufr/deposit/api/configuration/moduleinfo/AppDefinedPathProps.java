package ru.alfabank.ufr.deposit.api.configuration.moduleinfo;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "interaction.servicepanel.depositsuipath")
@Data
public class AppDefinedPathProps {
    private String callerId;
    private String callerEntityId;
    private String workflow;
}
