package ru.alfabank.ufr.deposit.api.entity.repository.poa;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.Parameter;
import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.Size;
import java.util.List;

@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OtherDetailsDto {
    @Size(min=3, max=3)
    @Parameter(description = "Код типа категории.")
    private String codeObjectType;

    @Parameter(description = "Наименование типа категории.")
    private String objectTypeName;

    @Size(min=2, max=2)
    @Parameter(description = "Код типа счета в EQ.")
    private String codeAccountType;

    @Parameter(description = "Наименование типа счета в EQ.")
    private String accountTypeName;

    private List<OperationDto> operationList;
    private List<AccountTypeGroupDto> accountTypeGroupList;
}