package ru.alfabank.ufr.deposit.api.entity.rest;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SessionStatusDto {

    public enum Status {
        SESSION_EXISTS,
        SESSION_NOT_EXISTS,
        ANOTHER_SESSION_EXISTS,
        SESSION_EXPIRED,
        SESSION_CLOSED
    }

    public SessionStatusDto(Status status) {
        this.status = status;
    }

    private String id;
    private String eqId;
    private String operatorLogin;
    private Status status;
    private String mobilePhone;
    private String workflow;
    private String viewtype;
    private String callerId;
    private String callerEntityId;
}
