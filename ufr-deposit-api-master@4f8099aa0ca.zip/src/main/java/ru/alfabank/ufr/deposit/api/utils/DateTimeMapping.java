package ru.alfabank.ufr.deposit.api.utils;

import org.mapstruct.Named;
import org.springframework.stereotype.Component;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.GregorianCalendar;

@Component
@Named("DateTimeMapping")
public class DateTimeMapping {
    @Named("DateToXmlGregorianCalendarNoTimeZone")
    public XMLGregorianCalendar dateToXMLGregorianCalendarNoTimeZone(Date date) {
        if (null == date) return null;

        GregorianCalendar gcal = new GregorianCalendar();
        gcal.setTime(date);
        try {
            XMLGregorianCalendar xmlDate = DatatypeFactory.newInstance()
                    .newXMLGregorianCalendar(gcal);
            xmlDate.setTimezone(DatatypeConstants.FIELD_UNDEFINED);
            return xmlDate;
        } catch (DatatypeConfigurationException e) {
            throw new RuntimeException(e);
        }
    }

    @Named("DateToLocalDate")
    public LocalDate dateToLocalDate(Date date) {
        if (null == date) return null;

        GregorianCalendar gcal = new GregorianCalendar();
        gcal.setTime(date);
        XMLGregorianCalendar xmlDate = null;
        try {
            xmlDate = DatatypeFactory.newInstance()
                    .newXMLGregorianCalendar(gcal);
            xmlDate.setTimezone(DatatypeConstants.FIELD_UNDEFINED);
            return xmlDate.toGregorianCalendar().toZonedDateTime().toLocalDate();
        } catch (DatatypeConfigurationException e) {
            throw new RuntimeException(e);
        }
    }

    public LocalDate convertStringToLocalDate(String datePattern) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(datePattern);
        return LocalDate.parse(datePattern, formatter);
    }
}
