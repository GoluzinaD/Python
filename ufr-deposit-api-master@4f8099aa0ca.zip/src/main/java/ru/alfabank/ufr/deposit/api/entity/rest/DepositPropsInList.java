package ru.alfabank.ufr.deposit.api.entity.rest;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DepositPropsInList {
    private String dlp;
    private String nm1;
    private String nm2;
    private String cpi;
    private String rol;
    private String chm;
    private String chs;
    private String crl;
    private String crt;
    private String ifq;
    private String bi;
}