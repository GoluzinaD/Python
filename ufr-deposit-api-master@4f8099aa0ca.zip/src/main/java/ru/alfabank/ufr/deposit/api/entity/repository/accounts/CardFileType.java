package ru.alfabank.ufr.deposit.api.entity.repository.accounts;

/**
 * Виды картотек
 */
public enum CardFileType {
    K01, K02, K11
}