package ru.alfabank.ufr.deposit.api.repository.accounts;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import ru.alfabank.ufr.deposit.api.configuration.FeignClientConfiguration;
import ru.alfabank.ufr.deposit.api.entity.repository.accounts.Account;

import java.util.Set;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@FeignClient(name = "accountsApi", url = "${interaction.accountsApi.base}", configuration = FeignClientConfiguration.class)
public interface AccountsApi {
    @GetMapping(produces = APPLICATION_JSON_VALUE, value = "/accounts/{pinEq}")
    Set<Account> getAccountListByPinEq(@PathVariable("pinEq") String pinEq,
                                       @RequestParam(value = "operationTypes", required = false) String[] operationTypes,
                                       @RequestParam(value = "act", required = false) String[] act);
}