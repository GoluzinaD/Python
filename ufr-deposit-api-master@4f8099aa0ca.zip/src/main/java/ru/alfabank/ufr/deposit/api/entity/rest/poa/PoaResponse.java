package ru.alfabank.ufr.deposit.api.entity.rest.poa;

import lombok.Builder;
import lombok.Data;
import ru.alfabank.ufr.deposit.api.entity.repository.poa.FullPoasResponse;

@Data
@Builder
public class PoaResponse {
    private boolean isAvailable;
    private FullPoasResponseDto poaResponse;
}
