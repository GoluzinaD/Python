package ru.alfabank.ufr.deposit.api.entity.repository.poa;

import io.swagger.v3.oas.annotations.Parameter;
import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.Size;

@Data
@Builder
public class TrustedRelationDto {
    @Size(max=6)
    @Parameter(description = "Pin EQ доверителя.")
    private String clientEqId;

    @Size(max=6)
    @Parameter(description = "Pin EQ доверенного лица.")
    private String trustedClientEqId;
}
