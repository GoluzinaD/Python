package ru.alfabank.ufr.deposit.api.repository.refill;

import lombok.Data;
import lombok.experimental.Accessors;

import java.math.BigDecimal;

public interface RefillDepositRepository {
    BigDecimal refill(final Input input);

    @Accessors(chain = true)
    @Data
    class Input {
        private String dlp;
        private String dlr;
        private String brnm;
        private String cus;
        private String inc;
        private String abf;
        private String anf;
        private String asf;
        private BigDecimal nwr;
        private BigDecimal adj;
        private String nda;
        private String branchNumber;
        private String userID;
    }
}
