package ru.alfabank.ufr.deposit.api.entity.repository.poa;

import lombok.Data;

@Data
public class FullPoaResponse {

    private FullPoaDto fullPoa;
}
