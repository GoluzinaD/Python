package ru.alfabank.ufr.deposit.api.repository.close;

import ru.alfabank.ufr.deposit.api.entity.rest.DepositCloseInData;
import ru.alfabank.ufr.deposit.api.entity.rest.DepositCloseValidationParams;
import ru.alfabank.ufr.deposit.api.entity.rest.DepositCloseValidationRequest;

public interface ClosingDepositRepository {
    DepositCloseValidationParams getCloseValidationParams(final DepositCloseValidationRequest request);

    void closeDeposit(final DepositCloseInData request, String userId, String branchNumber);
}
