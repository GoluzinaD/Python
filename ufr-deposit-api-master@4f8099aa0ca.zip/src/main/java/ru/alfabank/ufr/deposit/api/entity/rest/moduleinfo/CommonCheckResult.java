package ru.alfabank.ufr.deposit.api.entity.rest.moduleinfo;
import lombok.Data;

import java.util.Collections;
import java.util.List;

@Data
public class CommonCheckResult {
    private String checkCode;
    private CheckResult pass;
    private String resultCode;
    private String description;
    private List<BanCode> banCodes = Collections.emptyList();

    @Data
    public static class BanCode {
        private String code;
        private String description;
        private String condition;
    }

}
