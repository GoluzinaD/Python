package ru.alfabank.ufr.deposit.api.repository.exceptions;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
@EqualsAndHashCode(callSuper = true)
public class WebServiceException extends RuntimeException {
    private String errorCode;
    public WebServiceException(Throwable cause) {
        super(cause);
    }
}
