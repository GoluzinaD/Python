package ru.alfabank.ufr.deposit.api.utils;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.EqualsAndHashCode;

import java.io.IOException;
import java.time.Instant;
import java.time.format.DateTimeFormatter;

/**
 * Класс представляющий временную отметку
 */
@JsonSerialize(using = Timestamp.TimestampSerializer.class)
@JsonDeserialize(using = Timestamp.TimestampDeserializer.class)
@EqualsAndHashCode
public class Timestamp {

    private final Instant instant;

    public Timestamp(Instant instant) {
        this.instant = instant;
    }

    public Instant toInstant() {
        return instant;
    }

    public static Timestamp now() {
        return new Timestamp(Instant.now());
    }

    @Override
    public String toString() {
        return instant.toString();
    }

    static class TimestampDeserializer extends JsonDeserializer<Timestamp> {
        @Override
        public Timestamp deserialize(JsonParser p, DeserializationContext ctxt) throws IOException, JsonProcessingException {
            return new Timestamp(Instant.parse(p.getValueAsString()));
        }
    }

    static class TimestampSerializer extends JsonSerializer<Timestamp> {
        @Override
        public void serialize(Timestamp value, JsonGenerator gen, SerializerProvider serializers) throws IOException, JsonProcessingException {
            gen.writeString(DateTimeFormatter.ISO_INSTANT.format(value.toInstant()));
        }
    }
}
