package ru.alfabank.ufr.deposit.api.repository.exceptions;

import lombok.Getter;

public class UserRelatedException extends WebServiceException {
    @Getter
    private final String clientId;

    public UserRelatedException(String clientId, Throwable cause) {
        super(cause);
        this.clientId = clientId;
    }
}