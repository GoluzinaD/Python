package ru.alfabank.ufr.deposit.api.entity.repository.session;

import lombok.Data;
import lombok.experimental.Accessors;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Past;
import java.time.ZonedDateTime;

@Data
@Accessors(chain = true)
public abstract class AbstractEventDataDto {
    @Past
    private ZonedDateTime dateTime;

    @NotBlank
    private String eventType;
}