package ru.alfabank.ufr.deposit.api.entity.repository.poa;

import io.swagger.v3.oas.annotations.Parameter;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class FullPoaDto {
    @Parameter(description = "Основная информация о доверенности.")
    private AggregatePoaDto aggregatePoa;

    @Parameter(description = "Дополнительная информация о элементарной доверенности.")
    private List<ElementaryPoaDto> elementaryPoaList;

    @Parameter(description = "Информация о доверителе и доверенном лице, зафиксированных в рамках доверенности")
    private TrustedRelationDto trustedRelation;

    @Parameter(description = "Информация о типе и виде доверенности")
    private TypeKindDto typeKind;
}