package ru.alfabank.ufr.deposit.api.entity.rest;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Data
@Accessors(chain = true)
public class OpenedDepositDetails {
    private String neean;
    private String v5Abd;
    private String v5And;
    private String v5Asd;
    private String scccy;
    private BigDecimal c8Pwd;
    private String neeanintr;
    private String v5Abi;
    private String v5Ani;
    private String v5Asi;
    @JsonFormat(shape = JsonFormat.Shape.NUMBER)
    private Date osctrd;
    private String obdpd;
    private String cpi;
    private BigDecimal v5Bal;
    private BigDecimal stsum;
    @JsonFormat(shape = JsonFormat.Shape.NUMBER)
    private Date otsdte;
    private String termdescr;
    private BigDecimal v5Rat;
    private String prol;
    private String v5Arc;
    private BigDecimal minbal;
    private BigDecimal mininc;
    private BigDecimal dinclast;
    private BigDecimal totalint;
    private String omabfout;
    private String omanfout;
    private String omasfout;
    private String neeanout;
    private String omabfin;
    private String omanfin;
    private String omasfin;
    private String neeanin;
    private String v5Act;
    @JsonFormat(shape = JsonFormat.Shape.NUMBER)
    private Date v5Dtef;
    @JsonFormat(shape = JsonFormat.Shape.NUMBER)
    private Date v5Dteh;
    @JsonFormat(shape = JsonFormat.Shape.NUMBER)
    private Date v5Mdt;
    @JsonFormat(shape = JsonFormat.Shape.NUMBER)
    private Date v5Lcd;
    @JsonFormat(shape = JsonFormat.Shape.NUMBER)
    private Date v5Lre;
    @JsonFormat(shape = JsonFormat.Shape.NUMBER)
    private Date v5Nrd;
    @JsonFormat(shape = JsonFormat.Shape.NUMBER)
    private Date v5Ncd;
    @JsonFormat(shape = JsonFormat.Shape.NUMBER)
    private Date v5Dlm;
    private String v5Ifq;
    private String v5Prc;
    private String v5Rddy;
    private BigDecimal v5Rnum;
    private BigDecimal v5Am1;
    private BigDecimal v5Am2;
    private BigDecimal v5Am4;
    private String v5Pl1;
    private String v5Pl2;
    private String v5Brr;
    private String v5Drr;
    private BigDecimal v5Rtm;
    private BigDecimal v5Spr;
    private String v5Peg;
    private String popol;
    private String snt;
    private String v5Hsw;
    private String onprl;
    private String cnlprl;
    private BigDecimal otdla2;
    @JsonFormat(shape = JsonFormat.Shape.NUMBER)
    private Date ddend;
    @JsonFormat(shape = JsonFormat.Shape.NUMBER)
    private Date ddst;
    private String yoaifq;
    private String hbrnm;
    private String dname;
    private BigDecimal cdd;
    private BigDecimal wrat;
    private String nm1;
    private String nm2;
    private String depname;
    private String dll;
    private String xmpopol;
    private BigDecimal tsum;
    private BigDecimal maxsum;
    private BigDecimal maxrep;
    private BigDecimal brat;
    private BigDecimal drat;
    private Accrual accrual;

    @Data
    public static class Accrual {

        private List<Entry> graphic;

        @Data
        public static class Entry {
            private String ombrnm;
            private String omdlp;
            private String omdlr;
            @JsonFormat(shape = JsonFormat.Shape.NUMBER)
            private Date omdte;
            private String ommvt;
            private String ommvts;
            private BigDecimal omns3;
            private String omapp;
            private String ombdt;
            private String omprf;
            private String omccy;
            private String omnst;
            private BigDecimal omnwp;
            private BigDecimal omnwr;
            private String omcus;
            private String omclc;
            private String omdrf;
            private String omabf;
            private String omanf;
            private String omasf;
            private String omabd;
            private String omand;
            private String omasd;
            private String omreqf;
            private String omprvf;
            private String omxm;
            private String omxms;
            private String omarc;
            private String omynpg;
            private String omynar;
            private String ombmp;
            private String omocs;
            private String omprnr;
            private String omnet;
            private String omrqsf;
            private String omprsf;
            private String v2Brnm;
            private String v2Dlp;
            private String v2Dlr;
            @JsonFormat(shape = JsonFormat.Shape.NUMBER)
            private Date v2Dte;
            private String v2Brr;
            private String v2Drr;
            private BigDecimal v2Rat;
            private BigDecimal v2Rtm;
            private BigDecimal v2Spr;
            private String v2Peg;
            private String v2Reqf;
            @JsonFormat(shape = JsonFormat.Shape.NUMBER)
            private Date v2Dlm;
            private BigDecimal v2Minr;
            private BigDecimal v2Maxr;
            private String v3Brnm;
            private String v3Dlp;
            private String v3Dlr;
            @JsonFormat(shape = JsonFormat.Shape.NUMBER)
            private Date v3Dte;
            private BigDecimal v3Bal;
            private BigDecimal v3Amtp;
            private String v4Brnm;
            private String v4Dlp;
            private String v4Dlr;
            @JsonFormat(shape = JsonFormat.Shape.NUMBER)
            private Date v4Dte;
            private String v4Tdt;
            private BigDecimal v4Aim1;
            private BigDecimal v4Aim2;
            private BigDecimal v4Aim3;
            private BigDecimal v4Aim4;
            private BigDecimal v4Iam1;
            @JsonFormat(shape = JsonFormat.Shape.NUMBER)
            private Date v4Dte2;
            private String v4Ynmi;
            private String v4Ynma;
            private BigDecimal v4Pen;
            private String v4Fci;
            @JsonFormat(shape = JsonFormat.Shape.NUMBER)
            private Date rdepod;
            private String rdebrnm;
            private String rdedlp;
            private String rdedlr;
            private String rdepu;
            private String rdeosn;
            private BigDecimal rdebaz;
            private BigDecimal rdenad;
            @JsonFormat(shape = JsonFormat.Shape.NUMBER)
            private Date rdesdte;
            private String rdesopr;
            private String slbrnm;
            private String sldlp;
            private String sldlr;
            @JsonFormat(shape = JsonFormat.Shape.NUMBER)
            private Date sldte;
            private String sltyp;
            private BigDecimal slseq;
            @JsonFormat(shape = JsonFormat.Shape.NUMBER)
            private Date slpdte;
            @JsonFormat(shape = JsonFormat.Shape.NUMBER)
            private Date slndte;
            private String slrdm;
            @JsonFormat(shape = JsonFormat.Shape.NUMBER)
            private Date rdcpod;
            private String rdccus;
            private String rdcclc;
            private String rdcbrnm;
            private String rdcdlp;
            private String rdcdlr;
            private BigDecimal rdcsqn;
            private BigDecimal rdcama;
            private String rdcean1;
            private String rdcean2;
            private String rdcsd1;
            private String rdcsd2;
            private String rdcsd3;
            private String rdcsd4;
            private String rdccod;
            private String rdcusr;
            @JsonFormat(shape = JsonFormat.Shape.NUMBER)
            private Date rdcdlm;
            private String grp3D;
            private BigDecimal event;
            private String operationName;
        }
    }


}
