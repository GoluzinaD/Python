package ru.alfabank.ufr.deposit.api.service.exceptions;

public class SessionAddEventException extends RuntimeException {
    public SessionAddEventException(Throwable e) {
        super(e);
    }
}
