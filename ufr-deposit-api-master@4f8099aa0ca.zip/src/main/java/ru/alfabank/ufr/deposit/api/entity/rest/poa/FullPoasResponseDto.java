package ru.alfabank.ufr.deposit.api.entity.rest.poa;

import lombok.Builder;
import lombok.Data;
import ru.alfabank.ufr.deposit.api.entity.repository.poa.FullPoaDto;

import java.util.List;

@Data
@Builder
public class FullPoasResponseDto {
    private List<FullPoaDto> fullPoaList;
    private String accountNumber;
}
