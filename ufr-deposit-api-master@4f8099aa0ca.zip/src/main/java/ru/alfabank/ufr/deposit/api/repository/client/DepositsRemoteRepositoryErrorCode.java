package ru.alfabank.ufr.deposit.api.repository.client;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
enum DepositsRemoteRepositoryErrorCode {
    USER_NOT_FOUND("KSM2010");

    private final String code;
}
