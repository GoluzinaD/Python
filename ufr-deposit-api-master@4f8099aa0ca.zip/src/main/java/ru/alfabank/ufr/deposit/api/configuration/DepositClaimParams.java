package ru.alfabank.ufr.deposit.api.configuration;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.LinkedHashMap;
import java.util.Map;


@Data
@Configuration
@ConfigurationProperties(prefix = "deposit.claim")
public class DepositClaimParams {
    private String channelId;
    private String freeFormatAccType;
    private Map<String, Integer> eventTypes;
    private Map<String, String> freeFormatDocs = new LinkedHashMap<>();
    private String masterSys;
    private String sourceId;
    private String freeFormatExtSysCode;
}
