package ru.alfabank.ufr.deposit.api.entity.rest;

import lombok.Data;

@Data
public class DepositCloseResponse {
    private String needDULScan;
}
