package ru.alfabank.ufr.deposit.api.entity.rest.session;

public abstract class SessionAbstractRequest {
}