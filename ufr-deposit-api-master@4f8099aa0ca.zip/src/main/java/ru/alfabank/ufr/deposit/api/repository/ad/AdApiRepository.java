package ru.alfabank.ufr.deposit.api.repository.ad;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import ru.alfabank.ufr.deposit.api.configuration.FeignClientConfiguration;
import ru.alfabank.ufr.deposit.api.entity.repository.ad.AuthEncodeRequest;
import ru.alfabank.ufr.deposit.api.entity.repository.ad.AuthEncodeResponse;
import ru.alfabank.ufr.deposit.api.entity.repository.ad.Employee;

@FeignClient(name = "ad", url = "${interaction.ad.url}", configuration = FeignClientConfiguration.class)
public interface AdApiRepository {
    @GetMapping(path = "${interaction.ad.employee}")
    Employee getEmployee(@PathVariable(name = "login") String login);

    @PostMapping(path = "${interaction.ad.encode}")
    AuthEncodeResponse encode(@RequestBody AuthEncodeRequest request);
}