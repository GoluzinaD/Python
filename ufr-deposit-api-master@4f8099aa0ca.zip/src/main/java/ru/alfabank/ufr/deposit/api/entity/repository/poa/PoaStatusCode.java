package ru.alfabank.ufr.deposit.api.entity.repository.poa;

public enum PoaStatusCode {

    CURRENT, AUTHORIZED, ANNULED, EXPIRED, WITHDRAWN, NOTAUTH, DELNOTAUTH
}
