package ru.alfabank.ufr.deposit.api.service.session;

import ru.alfabank.ufr.deposit.api.entity.repository.session.TokenDto;
import ru.alfabank.ufr.deposit.api.entity.rest.DepositCreateRESTRequestData;
import ru.alfabank.ufr.deposit.api.entity.rest.autoProlongation.AutoProlongationRequest;

import java.util.Date;

public interface SessionService {
    TokenDto addCreateDepositEvent(DepositCreateRESTRequestData request, Date operationDateTime);

    TokenDto addProlongDepositEvent(AutoProlongationRequest request);
}
