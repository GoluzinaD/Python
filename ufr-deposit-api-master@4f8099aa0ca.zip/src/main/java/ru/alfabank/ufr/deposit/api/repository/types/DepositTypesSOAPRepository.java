package ru.alfabank.ufr.deposit.api.repository.types;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;
import ru.alfabank.api.deposit.type.list.DepositTypeInfo;
import ru.alfabank.api.deposit.type.list.DepositTypeListGetCommandFactory;
import ru.alfabank.api.deposit.type.list.DepositTypeListGetRequest;
import ru.alfabank.api.deposit.type.list.DepositTypeListGetResponse;
import ru.alfabank.ufr.deposit.api.entity.rest.AvailableDepositTypes;
import ru.alfabank.ufr.deposit.api.entity.rest.DepositPropsInList;
import ru.alfabank.ufr.deposit.api.repository.exceptions.WebServiceException;
import ru.alfabank.ufr.deposit.api.service.AsyncExecution;
import ru.alfabank.ufr.deposit.api.utils.LogicUtils;
import ru.alfabank.ws.cs.eq.wsdeposittypelist11.WSDepositTypeList11PortType;
import ru.alfabank.ws.cs.wscommontypes10.WSCommonParms;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Slf4j
@Repository
public class DepositTypesSOAPRepository implements DepositTypesRepository {
    private final AsyncExecution asyncExecution;
    private final DepositTypeListGetCommandFactory typeListGetCommandFactory;

    @Autowired
    public DepositTypesSOAPRepository(WSCommonParms commonParms, AsyncExecution asyncExecution, WSDepositTypeList11PortType portType,
                                      @Value("${hystrix.command.default.execution.isolation.thread.timeoutInMilliseconds}") int timeout) {
        this.asyncExecution = asyncExecution;
        this.typeListGetCommandFactory = new DepositTypeListGetCommandFactory(commonParms, timeout, portType);
    }

    private DepositTypeListGetRequest getRequest(String depositCurrency, String clientType, String mainAccountOpened,
                                                 String servicePackageCode) {
        return DepositTypeListGetRequest.builder()
                .clientType(clientType)
                .depositCurrency(depositCurrency)
                .servicePackageCode(servicePackageCode)
                .hasOpenedMainAccount(LogicUtils.stringToBoolean(mainAccountOpened))
                .build();
    }

    private Map<String, Set<DepositPropsInList>> perDlpDepositProps(String depositCurrency, String clientType, String mainAccountOpened,
                                                                    String servicePackageCode) throws Exception {
        DepositTypeListGetRequest request = getRequest(depositCurrency, clientType, mainAccountOpened, servicePackageCode);
        List<DepositTypeInfo> depositTypes = Optional.ofNullable(typeListGetCommandFactory.getCommand(request).execute())
                .map(DepositTypeListGetResponse::getDepositTypes)
                .orElse(Collections.emptyList());

        return depositTypes.stream()
                .map(depositType -> DepositPropsInList.builder()
                        .dlp(depositType.getDealType())
                        .nm1(depositType.getMainName())
                        .nm2(depositType.getAdditionalName())
                        .cpi(LogicUtils.booleanToString(depositType.getHasCapitalization()))
                        .rol(LogicUtils.booleanToString(depositType.getHasProlongation()))
                        .chm(LogicUtils.booleanToString(depositType.getHasEndDateChange()))
                        .chs(LogicUtils.booleanToString(depositType.getHasStartDateChange()))
                        .crl(LogicUtils.booleanToString(depositType.getHasProlongationChange()))
                        .crt(LogicUtils.booleanToString(depositType.getHasRateChange()))
                        .ifq(depositType.getPercentFrequencyPayment())
                        .bi(depositType.getInterestAccrualAccount())
                        .build())
                .collect(Collectors.groupingBy(DepositPropsInList::getDlp, Collectors.toSet()));
    }

    private void regroupWithCcy(String ccy, AvailableDepositTypes accum, DepositPropsInList depositProps) {
        accum.getDlp().computeIfPresent(depositProps.getDlp(), (dlp, data) -> {
            data.getCcy().add(ccy);
            return data;
        });
    }

    @Override
    public AvailableDepositTypes getAvailableDepositTypes(String clientType, String[] depositCurrencies, String servicePackageCode,
                                                          String mainAccountOpened) {
        AvailableDepositTypes a = new AvailableDepositTypes();
        a.setDlp(new ConcurrentHashMap<>());
        Runnable task = () ->
                Stream.of(depositCurrencies).parallel().forEach(currencyCode -> {
                    try {
                        perDlpDepositProps(currencyCode, clientType, mainAccountOpened, servicePackageCode)
                                .forEach((key, value) -> a.getDlp().compute(key, (k, v) -> {
                                    if (v == null)
                                        return new AvailableDepositTypes.DlpData()
                                                .setDepositProps(value.stream()
                                                        .findAny()
                                                        .orElseThrow(() -> new RuntimeException("Unexpected empty set of DepositProps!")))
                                                .setCcy(Stream.of(currencyCode).collect(Collectors.toSet()));
                                    else {
                                        v.getCcy().add(currencyCode);
                                        return v;
                                    }
                                }));
                    } catch (Exception e) {
                       throw new WebServiceException(e);
                    }
                });

        asyncExecution.getForkJoinPool().submit(task).join();
        return a;
    }
}