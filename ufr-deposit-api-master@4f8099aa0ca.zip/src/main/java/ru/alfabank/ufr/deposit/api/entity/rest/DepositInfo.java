package ru.alfabank.ufr.deposit.api.entity.rest;

import lombok.Data;
import lombok.experimental.Accessors;

import java.math.BigDecimal;

@Data
@Accessors(chain = true)
public class DepositInfo {
    // ccy Валюта депозита (мнемоника)
    private String ccy;

    // ccyn Валюта депозита (номер)
    private String ccyn;

    // rnm Наименование валюты
    private String rnm;

    // dll Краткий тип сделки
    private String dll;

    // dlp Тип сделки
    private String dlp;

    // nm1 Наименование депозита
    private String nm1;

    // nm2 Дополнительное наименование депозита
    private String nm2;

    // dname Краткое наименование депозита
    private String dname;

    // prc Код периода сделки
    private String prc;

    // prd Наименование периода сделки
    private String prd;

    // cpi Признак "Капитализация?" (Y/N)
    private String cpi;

    // rol Признак "Пролонгация?" (Y/N)
    private String rol;

    // chm Признак "Изменяемый срок окончания?" (Y/N)
    private String chm;

    // chs Признак "Изменение даты старта?" (Y/N)
    private String chs;

    // crl Признак "Изменение возможности пролонгации?" (Y/N)
    private String crl;

    // crt Признак "Изменение % ставки?" (Y/N)
    private String crt;

    // ifq Частота выплаты %
    private String ifq;

    // bi Счет начисления %
    private String bi;

    // cdd Минимальное количество дней диапазона для открытия депозита
    private BigDecimal cdd;

    // minama Минимальная сумма для открытия депозита
    private BigDecimal minama;

    // minsum Минимальная сумма диапазона
    private BigDecimal minsum;

    // maxsum Максимальная сумма диапазона
    private BigDecimal maxsum;

    // brat Базовая Процентная ставка
    private BigDecimal brat;

    // act Счет учета процентов
    private String act;

    // tax Признак "Возможность удержания НДФЛ" (Y/N)
    private String tax;

    // pdp Признак "Возможность пополнения депозита в дату пролонгации" (Y/N)
    private String pdp;

    // vdp Признак "Возможность частичного востребования депозита в дату пролонгации" (Y/N)
    private String vdp;

    // vnp Признак "Возможность пополнения депозита" (Y/N)
    private String vnp;

    // pnp Признак "Возможность частичного востребования депозита" (Y/N)
    private String pnp;

    // maxday Максимальное количество дней диапазона для открытия депозита
    private BigDecimal maxday;

    // drat Надбавка к Базовой процентной ставке
    private BigDecimal drat;

    // rat Итоговая процентная ставка
    private BigDecimal rat;

}
