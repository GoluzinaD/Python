package ru.alfabank.ufr.deposit.api.entity.rest;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import ru.alfabank.ufr.deposit.api.configuration.Constants;

import java.math.BigDecimal;
import java.util.Date;

@Data
@Accessors(chain = true)
@JsonInclude(JsonInclude.Include.ALWAYS)
@EqualsAndHashCode(callSuper = true)
public class Account extends BankProduct {
    public Account() {}
    public Account(Constants.ProductSubCategory categoryGroup,
                   String name,
                   String accountType,
                   Date openDate,
                   Date closeDate,
                   String accountNumber,
                   String currencyCode,
                   BigDecimal balanceInMinorUnits,
                   int minorUnits,
                   FinancialResults financialResults) {
        super(name, currencyCode,
                new ProductClassification().setCategory(Constants.ProductCategory.BANKACCOUNT.toString())
                        .setGroupWithinCategory(categoryGroup.toString()),
                financialResults, new Date(), balanceInMinorUnits, minorUnits);
        this.setAccountTypeCode(accountType);
        this.setAccountNumber(accountNumber);
        this.setOpenDate(openDate);
        this.setCloseDate(closeDate);
    }
    private String accountNumber;
    private String accountTypeCode;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "Europe/Moscow")
    private Date openDate;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "Europe/Moscow")
    private Date closeDate;
}
