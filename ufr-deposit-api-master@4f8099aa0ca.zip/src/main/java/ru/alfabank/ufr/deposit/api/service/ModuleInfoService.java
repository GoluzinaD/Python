package ru.alfabank.ufr.deposit.api.service;

import lombok.RequiredArgsConstructor;
import org.mapstruct.Mapper;
import org.springframework.stereotype.Service;
import ru.alfabank.ufr.deposit.api.configuration.moduleinfo.AppDefinedPathProps;
import ru.alfabank.ufr.deposit.api.configuration.moduleinfo.ModuleInfoProps;
import ru.alfabank.ufr.deposit.api.configuration.moduleinfo.ModuleProperty;
import ru.alfabank.ufr.deposit.api.entity.rest.moduleinfo.ModuleDto;
import ru.alfabank.ufr.deposit.api.entity.rest.moduleinfo.SessionResponse;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class ModuleInfoService {
    private final ModuleInfoProps moduleInfoProps;
    private final ModuleInfoProps moduleInfoPropsOpenDeposit;
    private final AppDefinedPathProps appDefinedPathProps;
    private final PropsToDTO mapper;

    public ModuleDto getModuleDto(String adToken, SessionResponse sessionInfo) {
        return propsRelatedModuleDTO(adToken, sessionInfo, moduleInfoProps);
    }

    public ModuleDto getModuleDtoOpenDeposit(String adToken, SessionResponse sessionInfo) {
        return propsRelatedModuleDTO(adToken, sessionInfo, moduleInfoPropsOpenDeposit);
    }

    private ModuleDto propsRelatedModuleDTO(String adToken, SessionResponse sessionInfo, ModuleInfoProps moduleInfoProps) {
        return mapper.convert(moduleInfoProps.getModule())
                .setAvailable(true)
                .setPath(
                        String.format(moduleInfoProps.getModule().getPath(),
                                Optional.ofNullable(sessionInfo).map(SessionResponse::getCus).orElse(""),
                                appDefinedPathProps.getCallerId(),
                                appDefinedPathProps.getCallerEntityId(),
                                appDefinedPathProps.getWorkflow(),
                                URLEncoder.encode(adToken, StandardCharsets.UTF_8))
                );
    }


    @Mapper(componentModel = "spring")
    public interface PropsToDTO {
        ModuleDto convert(ModuleProperty from);
    }
}
