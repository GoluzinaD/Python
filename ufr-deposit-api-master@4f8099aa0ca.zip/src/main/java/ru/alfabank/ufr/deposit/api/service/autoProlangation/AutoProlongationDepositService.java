package ru.alfabank.ufr.deposit.api.service.autoProlangation;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.alfabank.ufr.deposit.api.entity.repository.autoProlongation.maintain.MaintainDepositRequestDto;
import ru.alfabank.ufr.deposit.api.entity.rest.autoProlongation.AutoProlongationRequest;
import ru.alfabank.ufr.deposit.api.repository.autoprolangation.wsDeposit.DepositRepository;
import ru.alfabank.ufr.deposit.api.repository.event.EventRepository;
import ru.alfabank.ufr.deposit.api.service.session.SessionService;
import ru.alfabank.ufr.deposit.api.utils.DtoConverter;
import ru.alfabank.ufr.deposit.api.utils.EventFactory;

@Slf4j
@Component
@RequiredArgsConstructor
public class AutoProlongationDepositService {
    private final DepositRepository depositRepository;
    private final DtoConverter dtoConverter;
    private final SessionService sessionService;
    private final EventRepository eventRepository;
    private final EventFactory eventFactory;

    public void autoProlongDeposit(AutoProlongationRequest request) {
        MaintainDepositRequestDto maintainDepositRequestDto = dtoConverter.createMaintainDepositRequestDto(request);
        depositRepository.maintainDeposit(maintainDepositRequestDto);

        sendBusinessEvent(request);
    }

    private void sendBusinessEvent(AutoProlongationRequest request) {
        sessionService.addProlongDepositEvent(request);
        try {
            eventRepository.createEvent(
                    eventFactory.getAutoProlongationDepositEvent(request));
        } catch (Exception e) {
            log.info("Error calling the WSCodeBusinessEvent10#Add service, message is- {}", e.getMessage());
        }
    }
}
