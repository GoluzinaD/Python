package ru.alfabank.ufr.deposit.api.entity.repository.ad;

import lombok.Data;

@Data
public class AuthEncodeResponse {
    private String token;
}
