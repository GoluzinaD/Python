package ru.alfabank.ufr.deposit.api.entity.repository.poa;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.Parameter;
import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.math.BigDecimal;

@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AggregatePoaDto {
    @NotNull
    @Parameter(description = "ID доверенности.")
    private BigDecimal aggregatePoaId;

    @NotNull
    @Min(0) @Max(1)
    @Parameter(description = "Свойство генеральной доверенности.")
    private Integer isGeneral;

    @Size(max=15)
    @Parameter(description = "Номер доверенности.")
    private String poaNumber;

    @Size(max=35)
    @Parameter(description = "Номер в реестре.")
    private String poaNumberRegister;

    @Size(max=35)
    @Parameter(description = "Номер бланка.")
    private String poaNumberBlank;

    @Parameter(description = "Дата выдачи доверенности.")
    private String poaIssueDate;

    @Size(max=35)
    @Parameter(description = "Место выдачи.")
    private String poaCity;

    @Parameter(description = "Дата начала действия доверенности.")
    private String poaStartDate;

    @NotNull
    @Parameter(description = "Дата окончания действия.")
    private String poaExpiryDate;

    @Size(max=19)
    @Parameter(description = "ID отделения ввода (цифровой номер отделения).")
    private String branchNumber;

    @Size(max=500)
    @Parameter(description = "Комментарий.")
    private String poaComments;

    @Size(max=10)
    @Parameter(description = "Номер доп. соглашения ИБС.")
    private String ibsAgreeNumber;

    @Parameter(description = "Дата доп. соглашения ИБС.")
    private String ibsAgreeDate;

    @Size(max=7)
    @Parameter(description = "Номер ИБС.")
    private String ibsNumber;

    @Parameter(description = "Дата заведения доверенности в системе.")
    private String poaCreateDate;

    @Parameter(description = "Дата аннулирования доверенности.")
    private String poaAnnulmentDate;

    @Parameter(description = "Дата отмены доверенности.")
    private String poaWithdrawalDate;

    @Parameter(description = "Дата удаления.")
    private String poaDeleteDate;

    @Size(max=255)
    @Parameter(description = "Система источник создания доверенности.")
    private String poaSource;

    @Size(max=9)
    @Parameter(description = "Заполняется при добавлении новой доверенности.")
    private String userEqId;

    @Parameter(description = "Опциональный номер отделения, в котором может быть авторизовано доверенное лицо.")
    private String branchXNumber;

    @Size(max=8)
    @Parameter(description = "Баркод.")
    private String barcode;

    @Parameter(description = "Код статуса доверенности.")
    private PoaStatusCode poaStatusCode;

    @Parameter(description = "Описание статуса доверенности.")
    private String statusName;
}