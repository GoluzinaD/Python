package ru.alfabank.ufr.deposit.api.service.exceptions;

public class RefillDepositException extends RuntimeException {
    public RefillDepositException(String msg, Throwable e) { super(msg, e); }
    public RefillDepositException(Throwable e) { super(e); }
}
