package ru.alfabank.ufr.deposit.api.configuration;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.Map;

@Data
@Configuration
@ConfigurationProperties(prefix = "deposit.autoprolongation", ignoreUnknownFields = false)
public class DepositAutoProlongationParams {
    private String customType;
    private String eventType;
    private String channelId;
    private String masterSys;
    private String sourceId;
    private Map<String, String> freeFormatMap;

}
