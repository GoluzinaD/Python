package ru.alfabank.ufr.deposit.api.repository.close;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.mapstruct.Mapper;
import org.springframework.stereotype.Repository;
import ru.alfabank.ufr.deposit.api.entity.rest.DepositCloseInData;
import ru.alfabank.ufr.deposit.api.entity.rest.DepositCloseValidationParams;
import ru.alfabank.ufr.deposit.api.entity.rest.DepositCloseValidationRequest;
import ru.alfabank.ufr.deposit.api.repository.exceptions.UserRelatedException;
import ru.alfabank.ufr.deposit.api.utils.WS;
import ru.alfabank.ws.cs.eq.wsdepositwithdraw11.WSDepositWithdraw11PortType;
import ru.alfabank.ws.cs.eq.wsdepositwithdraw11.hystrix.WsDepositWithdrawAddCmd;
import ru.alfabank.ws.cs.eq.wsdepositwithdraw11.hystrix.WsDepositWithdrawValidateCmd;
import ru.alfabank.ws.cs.eq.wsdepositwithdrawinoutparms11.WSDepositWithdrawAddInParms;
import ru.alfabank.ws.cs.eq.wsdepositwithdrawinoutparms11.WSDepositWithdrawValidateInParms;
import ru.alfabank.ws.cs.eq.wsdepositwithdrawinoutparms11.WSDepositWithdrawValidateOutParms;
import ru.alfabank.ws.cs.wscommontypes10.WSCommonParms;

@Slf4j
@Repository
@RequiredArgsConstructor
public class ClosingDepositRepositorySOAPRepository implements ClosingDepositRepository {
    private final WSDepositWithdraw11PortType portType;
    private final WSCommonParms commonParms;
    private final DTOConversion mapper;

    @Override
    public DepositCloseValidationParams getCloseValidationParams(DepositCloseValidationRequest request) {
        WsDepositWithdrawValidateCmd validateCmd = new WsDepositWithdrawValidateCmd(portType)
                .setInCommonParms(commonParms)
                .setInParms(mapper.validateOpConvertRequest(request));
        try {
            return mapper.validateOpConvertResponse(validateCmd.execute().getOutParms());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void closeDeposit(DepositCloseInData request, String userId, String branchNumber) {
        WsDepositWithdrawAddCmd withdrawAddCmd = new WsDepositWithdrawAddCmd(portType)
                .setInCommonParms(WS.duplicateAndReplaceWithNotBlank(commonParms, branchNumber, userId))
                .setInParms(mapper.closeRequestConvert(request));
            WSCommonParms c = WS.duplicateAndReplaceWithNotBlank(commonParms, branchNumber, userId);
        try {
            withdrawAddCmd.execute();
        } catch (Exception e) {
            throw new UserRelatedException(request.getEqId(), e);
        }
    }

    @Mapper(componentModel = "spring")
    interface DTOConversion {
        WSDepositWithdrawValidateInParms validateOpConvertRequest(DepositCloseValidationRequest request);
        DepositCloseValidationParams validateOpConvertResponse(WSDepositWithdrawValidateOutParms response);
        WSDepositWithdrawAddInParms closeRequestConvert(DepositCloseInData request);
    }
}