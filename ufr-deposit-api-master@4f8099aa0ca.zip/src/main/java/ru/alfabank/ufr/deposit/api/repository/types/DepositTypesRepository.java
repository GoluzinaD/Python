package ru.alfabank.ufr.deposit.api.repository.types;

import ru.alfabank.ufr.deposit.api.entity.rest.AvailableDepositTypes;

public interface DepositTypesRepository {
    AvailableDepositTypes getAvailableDepositTypes(String clientType, String[] depositCurrencies, String servicePackageCode,
                                                   String mainAccountOpened);
}