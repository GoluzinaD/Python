package ru.alfabank.ufr.deposit.api.utils;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.springframework.stereotype.Component;
import ru.alfabank.ufr.deposit.api.configuration.Constants;
import ru.alfabank.ufr.deposit.api.configuration.DepositClaimParams;
import ru.alfabank.ufr.deposit.api.entity.repository.autoProlongation.maintain.MaintainDepositRequestDto;
import ru.alfabank.ufr.deposit.api.entity.repository.depositPrincipal.DepositPrincipalClaimRequest;
import ru.alfabank.ufr.deposit.api.entity.rest.autoProlongation.AutoProlongationRequest;
import ru.alfabank.ufr.deposit.api.entity.rest.depositClaim.DepositClaimRequest;

import java.util.Date;

@Slf4j
@Component
@RequiredArgsConstructor
public class DtoConverter {
    private final DTOConversion dtoConversion;
    private final DepositClaimParams depositClaimParams;

    public DepositPrincipalClaimRequest createDepositPrincipalApiClaimRequest(DepositClaimRequest request) {
        return dtoConversion.convertToDepositPrincipalClaimRequest(request);
    }

    public MaintainDepositRequestDto createMaintainDepositRequestDto(AutoProlongationRequest request) {
        MaintainDepositRequestDto maintainDepositRequestDto = MaintainDepositRequestDto
                .builder()
                .userId(request.getUserId())
                .branchNumber(request.getBranchNumber())
                .brnm(request.getBranch())
                .dlr(request.getDepositNumber())
                .dlp(request.getDepositType())
//                .mdt(request.getDdend())
                .build();
        if (Constants.N.equals(request.getSetAutoprolongation())) {
            maintainDepositRequestDto.setMdt(new Date(Long.parseLong(request.getDdend())));
        }
        return maintainDepositRequestDto;
    }

    @Mapper(componentModel = "spring")
    interface DTOConversion {
        @Mappings({
                @Mapping(target = "cus", source = "request.eqId"),
                @Mapping(target = "clc", constant = StringUtils.EMPTY),
                @Mapping(target = "inc", constant = Constants.N),
                @Mapping(target = "nda", constant = Constants.Y)
        })
        DepositPrincipalClaimRequest convertToDepositPrincipalClaimRequest(DepositClaimRequest request);
    }
}