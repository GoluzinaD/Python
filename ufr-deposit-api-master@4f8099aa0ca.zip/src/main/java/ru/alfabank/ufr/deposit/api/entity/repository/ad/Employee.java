package ru.alfabank.ufr.deposit.api.entity.repository.ad;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.List;

@Data
@Accessors(chain = true)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Employee {
    @JsonProperty("sAMAccountName")
    private String login;
    private String displayName;
    private String sn;
    private String givenName;
    private String middleName;
    private String title;
    private String mail;
    private String eqMnemonic;
    private String eqNumber;
    private String eqProfile;
    private List<String> groups;
    private List<String> permissions;
    private String error;
}
