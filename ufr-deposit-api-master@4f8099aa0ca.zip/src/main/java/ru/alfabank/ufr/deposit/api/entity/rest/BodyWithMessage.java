package ru.alfabank.ufr.deposit.api.entity.rest;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class BodyWithMessage {
    private String msg;
}
