package ru.alfabank.ufr.deposit.api.entity.rest.autoProlongation;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import ru.alfabank.ufr.deposit.api.entity.rest.session.SessionAbstractRequest;

import javax.validation.constraints.NotBlank;

@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
public class AutoProlongationRequest extends SessionAbstractRequest {
    @NotBlank
    private String userId;
    @NotBlank
    private String branchNumber;
    @NotBlank
    private String eqId;
    @NotBlank
    private String operatorLogin;
    @NotBlank
    private String sessionToken;
    @NotBlank
    private String userBranch;
    @NotBlank
    private String branch;
    @NotBlank
    private String depositType;//dlp
    @NotBlank
    private String depositNumber;//dlr
    @NotBlank
    private String ddend;
    @NotBlank
    private String setAutoprolongation;
    @NotBlank
    private String depositName;
    @NotBlank
    private String depositTerm;//extendedDeposit
    @NotBlank
    private String depositCurrency; //extendedDeposit.scccy,
    @NotBlank
    private String lastProlDate; //momentDateShortFormat(currentDeposit.openDate),
    @NotBlank
    private String prolDateRefill; //isSameCurrentDate(currentDeposit.openDate) ? BooleanFlag.Y : BooleanFlag.N,
    @NotBlank
    private String nextProlDate; //extendedDeposit.v5nrd,
    @NotBlank
    private String depositOpeningSum; //formatCorporateAmountWithoutCurrency(extendedDeposit.otdla2, extendedDeposit.scccy),
    @NotBlank
    private String depositOpeningSum2; //formatAmount(extendedDeposit.stsum / 100),
    @NotBlank
    private String capitalization; //extendedDeposit.cpi,
    @NotBlank
    private String prolongation; //currentDeposit.prolongation,
    @NotBlank
    private String depositAccNum; //extendedDeposit.neean,
    @NotBlank
    private String expressAccNum; //btoa(currentDeposit.expressAccount),
    @NotBlank
    private String depositOpenDate; //extendedDeposit.graphic[FIRST_ELEMENT].omdte,
    @NotBlank
    private String depositOpenDate2; //extendedDeposit.ddst,
    @NotBlank
    private String depositEndDate; //momentDateShortFormat(currentDeposit.closeDate),
    @NotBlank
    private String totalRate; //currentDeposit.interestRate,
    @NotBlank
    private String baseRate; //extendedDeposit.brat,
    @NotBlank
    private String additionalRate; //currentDeposit.premiumRate,
    @NotBlank
    private String servicePacketName; //client.data.baseInfo.servicePackageName,
    @NotBlank
    private String servicePacketCode; //client.data.baseInfo.servicePackage,
    @NotBlank
    private String depositSum; //client.data.baseInfo.servicePackage,
    @NotBlank
    private String totalCapitalizationRate; //currentDeposit.totalRate.toFixed(2),
    private String minimalBalance; //extendedDeposit.snt === BooleanFlag.Y ? formatAmount(extendedDeposit.minbal / 100) : '',
    private String maximalSum; //extendedDeposit.maxsum <= 0 ? '' : formatAmount(extendedDeposit.maxsum / 100),
    private String allowedReplenishmentDate; //(extendedDeposit.popol === BooleanFlag.Y && extendedDeposit.dinclast >= 0)? getAllowedReplenishmentDate(extendedDeposit.sdt, extendedDeposit.dinclast)
    private String poaStartDate;
    private String poaNumber;
    private String poaFIO;
}
