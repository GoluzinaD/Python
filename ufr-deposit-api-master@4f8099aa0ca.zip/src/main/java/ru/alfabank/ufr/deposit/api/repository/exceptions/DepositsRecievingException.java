package ru.alfabank.ufr.deposit.api.repository.exceptions;

public class DepositsRecievingException extends UserRelatedException {
    public DepositsRecievingException(String clientId, Throwable cause) {
        super(clientId, cause);
    }
}
