package ru.alfabank.ufr.deposit.api.repository.variants;

import ru.alfabank.ufr.deposit.api.entity.rest.DepositInfo;
import ru.alfabank.ufr.deposit.api.entity.rest.DepositVariantsRequest;

import java.util.List;

public interface DepositVariantsRepository {
    List<DepositInfo> getDepositVariantsOfType(DepositVariantsRequest variantsRequest);
}
