package ru.alfabank.ufr.deposit.api.entity.rest.moduleinfo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Data;

import java.util.List;
import java.util.Map;

import static java.util.Collections.emptyList;

@Data
public class SessionResponse {

    private String sessionId;
    private String clientType;
    private String cus;
    private String adLogin;
    private String crmbmbCus;
    private Long creationTimestamp;
    private Long refreshTimestamp;
    private Map<String, Object> params;

    @JsonIgnore
    public List<CommonCheckResult> getComplianceResults() {
        List<CommonCheckResult> complianceResults = new ObjectMapper().convertValue(params.get("complianceResults"),
                new TypeReference<List<CommonCheckResult>>() {
                });
        return complianceResults != null ? complianceResults : emptyList();
    }

}