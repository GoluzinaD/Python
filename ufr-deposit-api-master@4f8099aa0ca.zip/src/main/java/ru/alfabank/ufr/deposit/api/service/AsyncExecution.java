package ru.alfabank.ufr.deposit.api.service;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.concurrent.ForkJoinPool;

@Component
public class AsyncExecution {
    @Getter
    private ForkJoinPool forkJoinPool;
    // one can specify desired number of parallelism of the pool in execution.async.workersCount application property
    @Value("${execution.async.workersCount:#{T(Runtime).getRuntime().availableProcessors() > 2 ? T(Runtime).getRuntime().availableProcessors()-1 : 1}}")
    private int workersCount;

    @PostConstruct
    private void init() {
        forkJoinPool = new ForkJoinPool(workersCount);
    }
}
