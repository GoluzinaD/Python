package ru.alfabank.ufr.deposit.api.entity.rest.moduleinfo;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import static com.fasterxml.jackson.annotation.JsonInclude.Include;

@Data
@JsonInclude(Include.NON_NULL)
public class ModuleOperationsDto {
    private String id;
    private String endpoint;
    private String name;
}
