package ru.alfabank.ufr.deposit.api.utils;

import lombok.SneakyThrows;
import lombok.experimental.UtilityClass;
import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import ru.alfabank.ufr.deposit.api.repository.exceptions.WebServiceException;

import static ru.alfabank.ufr.deposit.api.configuration.Constants.ERROR_CODE_FIELD_RESPONSE;
import static ru.alfabank.ufr.deposit.api.configuration.Constants.FULL_MSG_FIELD_RESPONSE;

@UtilityClass
public class ExceptionHandling {
    // ! потенциально stack overflow при намеренном зацикливании причин
    public void bootstrapCauses(Throwable ex, StringBuilder sb, JSONObject jsonObject) {
        if (ex instanceof WebServiceException) {
            addErrorCodeInfo(jsonObject, (WebServiceException) ex);
        }
        if (null != ex.getCause() && !ex.equals(ex.getCause())) {
            bootstrapCauses(ex.getCause(), sb, jsonObject);
            sb.append("\nis the cause of\n");
        }
        sb.append(ex);
    }

    @SneakyThrows
    public void commonExceptionHandling(Throwable e, JSONObject jsonObject) {
        StringBuilder sb = new StringBuilder();
        ExceptionHandling.bootstrapCauses(e, sb, jsonObject);
        jsonObject.put(FULL_MSG_FIELD_RESPONSE, sb.toString());
    }

    private void addErrorCodeInfo(JSONObject jsonObject, WebServiceException e) {
        JSONArray errorCode;
        Object o = jsonObject.get(ERROR_CODE_FIELD_RESPONSE);
        if (o != null) {
            if (!(o instanceof JSONArray)) {
                errorCode = new JSONArray();
                jsonObject.put(ERROR_CODE_FIELD_RESPONSE, errorCode);
            } else {
                errorCode = (JSONArray) o;
            }
        } else {
            errorCode = new JSONArray();
            jsonObject.put(ERROR_CODE_FIELD_RESPONSE, errorCode);
        }
        errorCode.add(e.getErrorCode());
    }
}