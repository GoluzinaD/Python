package ru.alfabank.ufr.deposit.api.configuration;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import javax.validation.constraints.Pattern;

@Data
@Configuration
@ConfigurationProperties(prefix = "sessionparams.headers")
public class SessionHeadersNames {
    @Pattern(regexp = "[a-zA-Z\\-0-9]+")
    private String sessionToken;
    @Pattern(regexp = "[a-zA-Z\\-0-9]+")
    private String eqId;
    @Pattern(regexp = "[a-zA-Z\\-0-9]+")
    private String operatorLogin;
    private String callerId;
}
