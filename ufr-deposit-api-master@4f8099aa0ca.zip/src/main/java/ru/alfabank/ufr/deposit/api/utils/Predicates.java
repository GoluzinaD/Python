package ru.alfabank.ufr.deposit.api.utils;

import java.util.function.Predicate;

public class Predicates {

    public static <T> Predicate<Comparable<T>> isGreaterThan(T other) {
        return item -> item.compareTo(other) > 0;
    }

    public static <T> Predicate<Comparable<T>> isLessThan(T other) {
        return item -> item.compareTo(other) < 0;
    }

    public static <T> Predicate<T> not(Predicate<T> predicate) {
        return predicate.negate();
    }
}
