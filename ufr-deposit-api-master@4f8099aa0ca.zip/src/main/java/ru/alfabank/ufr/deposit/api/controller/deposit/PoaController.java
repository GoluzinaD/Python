package ru.alfabank.ufr.deposit.api.controller.deposit;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import ru.alfabank.ufr.deposit.api.entity.rest.poa.AccessType;
import ru.alfabank.ufr.deposit.api.entity.rest.poa.PoaResponse;
import ru.alfabank.ufr.deposit.api.service.poa.PoaService;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Slf4j
@Validated
@RestController
@RequestMapping(value = "poa")
@RequiredArgsConstructor
public class PoaController {
    private final PoaService poaService;

    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public PoaResponse getPoa(@NotBlank @RequestParam String sessionId,
                              @NotNull @RequestParam AccessType accessType,
                              @RequestParam(required = false) String accountNumber) {
        return poaService.getFullPoaResponse(sessionId, accessType, accountNumber);
    }
}