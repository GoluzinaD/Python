package ru.alfabank.ufr.deposit.api.aspect;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.stereotype.Component;
import ru.alfabank.ufr.deposit.api.entity.rest.DepositCreateRESTRequestData;

import java.util.Calendar;
import java.util.Date;

@Aspect
@Component
@Slf4j
@ConditionalOnExpression("${useServerDateTime}")
public class DatesReplacingRequest {

    @Around("createDepositExecution() && args(@RequestBody body, ..)")
    public Object patchRequestCreateDeposit(ProceedingJoinPoint pjp, DepositCreateRESTRequestData body) throws Throwable {
        Object[] methodArgs = pjp.getArgs();

        log.info("Modifying dates in request. Args was: {}", methodArgs);
        body.setSdt(new Date());
        if(null != body.getMdt()) {
            Calendar mdt = Calendar.getInstance();
            mdt.add(Calendar.DATE, body.getCdd());
            body.setMdt(mdt.getTime());
        }
        log.info("Modifying dates in request. Args now: {}", methodArgs);
        Object result = pjp.proceed();

        return result;
    }


    @Pointcut("execution(public * ru.alfabank.ufr.deposit.api.controller.deposit.ClientDepositsController.createDeposit(..))")
    public void createDepositExecution(){}

}

