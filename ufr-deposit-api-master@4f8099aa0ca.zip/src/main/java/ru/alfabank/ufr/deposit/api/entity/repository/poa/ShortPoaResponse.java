package ru.alfabank.ufr.deposit.api.entity.repository.poa;

import lombok.Data;

@Data
public class ShortPoaResponse {

    private ShortPoaDto shortPoa;
}
