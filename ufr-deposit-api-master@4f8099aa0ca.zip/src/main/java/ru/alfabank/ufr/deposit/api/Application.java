package ru.alfabank.ufr.deposit.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import ru.alfabank.ws.cs.wscommontypes10.WSCommonParms;
import ru.alfalab.cxf.starter.annotation.EnableCxfClient;
import ru.alfalab.cxf.starter.configuration.WSConfiguration;

@SpringBootApplication
@EnableHystrix
@EnableFeignClients
@EnableCxfClient
@ComponentScan({
        "ru.alfabank.ufr.deposit.api"
})
public class Application {
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

    @Bean
    public WSCommonParms wsCommonParms(WSConfiguration wsConfiguration) {
        return wsConfiguration.getParams("common");
    }
}