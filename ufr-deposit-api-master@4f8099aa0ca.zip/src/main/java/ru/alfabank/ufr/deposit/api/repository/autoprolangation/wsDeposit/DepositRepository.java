package ru.alfabank.ufr.deposit.api.repository.autoprolangation.wsDeposit;

import ru.alfabank.ufr.deposit.api.entity.repository.autoProlongation.maintain.MaintainDepositRequestDto;
import ru.alfabank.ws.cs.eq.wsdepositinoutparms11.WSDepositMaintainOutParms;

public interface DepositRepository {
     WSDepositMaintainOutParms maintainDeposit(MaintainDepositRequestDto requestDto);
}