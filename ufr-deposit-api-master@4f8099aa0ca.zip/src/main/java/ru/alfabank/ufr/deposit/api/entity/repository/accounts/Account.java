package ru.alfabank.ufr.deposit.api.entity.repository.accounts;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.experimental.Accessors;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;

/**
 * Created by aashatunov on 25.05.2016.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@Accessors(chain = true)
@Data
public class Account {

    private Date openDate;
    private Date closeDate;
    private String act;
    private String branchId;
    private BranchInfo branchInfo;
    private String accountNumber;
    private String accountSuffix;
    private String accountingMode;
    private String baseCurrencyCode;
    private String baseCurrencyName;
    @Deprecated // use balance instead
    private BigDecimal total;
    private BigDecimal balance;
    private BigDecimal hold;
    private BigDecimal amountOwnFunds;
    private BigDecimal amountOverdraft;
    private String tariff;
    private String tariffName;
    private String clientName;
    private String accountOwner;
    private String name;
    private boolean baseAccount;
    private boolean alwaysPositive;
    private String migrationBankCode;
    private String migrationBankName;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private LocalDate migrationDate;
    private String minorUnitsAmount;
    private List<CardFileType> availableCardFiles;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private LocalDate lastTransactionDate;
    private String creditType;
    private String loanAgreementStatus;

    /**
     * Пакет услуг клиента - ЮЛ
     */
    private String servicePackageCode;

    /**
     * Наименование пакета услуг клиента - ЮЛ
     */
    private String servicePackageName;

    /**
     * Спецусловие "клиент закрыт?"
     */
    private boolean clientClosedC14;

    /**
     * Спецусловие "счёт заблокирован?"
     */
    private boolean accountBlockedC17;

    /**
     * Спецусловие "счёт закрыт?"
     */
    private boolean accountClosedC30;

    /**
     * Спецусловие "дебетование ограничено?"
     */
    private boolean limitedDebitC82;

    /**
     * Спецусловие "электронная картотека?"
     */
    private boolean digitalCatalogC83;

    /**
     * Спецусловие "бумажная разновалютная картотека?"
     */
    private boolean paperCatalogC87;

    /**
     * Спецусловие "неактивный счёт?"
     */
    private boolean inActiveAccountC20;

    /**
     * Спецусловие "нельзя дебетовать?"
     */
    private boolean canNotDebitedC12;

    /**
     * Спецусловие "нельзя кредитовать?"
     */
    private boolean canNotCreditC11;

    /**
     * Группа счета"
     */
    private String accountGroup;
}
