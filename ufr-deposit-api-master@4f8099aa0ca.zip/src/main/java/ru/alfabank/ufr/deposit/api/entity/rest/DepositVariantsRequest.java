package ru.alfabank.ufr.deposit.api.entity.rest;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotBlank;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DepositVariantsRequest {
    @NotBlank
    private String ctp;
    @NotBlank
    private String ccy;
    private String dll;
    @NotBlank
    private String xm;
    @NotBlank
    private String lnm;
    @NotBlank
    private String pu;
    @NotBlank
    private String osn;
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    private Date std;
    private String dlp;
}