package ru.alfabank.ufr.deposit.api.entity.repository.ad;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AuthEncodeRequest {
    private String username;
    private String extSysCode;
    private String passHash;
    private String cus;
}
