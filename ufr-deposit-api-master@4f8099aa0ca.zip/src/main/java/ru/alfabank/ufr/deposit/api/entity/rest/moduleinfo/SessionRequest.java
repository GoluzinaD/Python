package ru.alfabank.ufr.deposit.api.entity.rest.moduleinfo;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class SessionRequest {
    String sessionId;
}
