package ru.alfabank.ufr.deposit.api.entity.repository.poa;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FullPoasResponse {
    private String name;
    private List<FullPoaDto> value;
}
