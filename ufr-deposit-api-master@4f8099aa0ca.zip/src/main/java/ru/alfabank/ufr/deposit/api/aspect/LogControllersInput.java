package ru.alfabank.ufr.deposit.api.aspect;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Aspect
@Component
@Slf4j
public class LogControllersInput {
    @Around("controllerORInterceptorMethodExecution()")
    public Object profile(ProceedingJoinPoint pjp) throws Throwable {
        Object[] methodArgs = pjp.getArgs();

        log.info("Call method {}.{} with args {}", pjp.getSignature().getDeclaringTypeName(), pjp.getSignature().getName(), methodArgs);

        Object result = pjp.proceed();

        log.info("Method {}.{} returns {}", pjp.getSignature().getDeclaringTypeName(), pjp.getSignature().getName(), result);

        return result;
    }

    @Pointcut("execution(public * ru.alfabank.ufr.deposit.api.controller..*.*(..)) || execution(* ru.alfabank.ufr.deposit.api.controller.interceptor.*.*(..))")
    public void controllerORInterceptorMethodExecution(){}

}

