package ru.alfabank.ufr.deposit.api.configuration.moduleinfo;

import lombok.Data;
import lombok.experimental.Accessors;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Data
@Accessors(chain = true)
public class ModuleProperty {

    private String id;
    private String name;
    private String path;
    private String description;
    private String icon;
    private List<OperationProperty> operations = new ArrayList<>();

}
