package ru.alfabank.ufr.deposit.api.entity.rest;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import ru.alfabank.ufr.deposit.api.configuration.Constants;
import ru.alfabank.ws.cs.eq.wsstatementdepositlistinoutparms13.WSStatementDepositListGetOutResultSetRow;

import javax.annotation.PostConstruct;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.Date;

import static java.util.Optional.ofNullable;

@Component
public class FactoryDeposit {
    private static final String DEFAULT_DEPOSIT_NAME = "Депозит";

    private static String DEPOSIT_STATUS_ACTUAL = "";
    private static String DEPOSIT_STATUS_CLOSED = "";
    private static String DEPOSIT_STATUS_DISSOLVED = "";
    private static String DEPOSIT_STATUS_PROLONGED = "";

    @Value("${message.deposit.status.actual}")
    private String depositStatusActual;
    @Value("${message.deposit.status.closed}")
    private String depositStatusClosed;
    @Value("${message.deposit.status.dissolved}")
    private String depositStatusDissolved;
    @Value("${message.deposit.status.prolonged}")
    private String getDepositStatusProlonged;

    @PostConstruct
    private void init() {
        DEPOSIT_STATUS_ACTUAL = depositStatusActual;
        DEPOSIT_STATUS_CLOSED = depositStatusClosed;
        DEPOSIT_STATUS_DISSOLVED = depositStatusDissolved;
        DEPOSIT_STATUS_PROLONGED = getDepositStatusProlonged;
    }

    public static AccountDeposit createFromRESTApiResponse(AccountDepositRestResponse.AccountDepositFromRestApi src) {
        FinancialResults finResultns = new FinancialResults();
        FinancialResult result = new FinancialResult();
        finResultns.setFinResultAll(result);
        result.setAmount(src.getFinres().divide(src.getC8pwd()));
        result.setAmountInMinorUnits(src.getFinres());
        result.setMinority(src.getC8pwd().toBigInteger().intValue());
        result.setCurrencyCode(src.getV5ccy());
        AccountDeposit deposit = new AccountDeposit();
        Amount balanceAmount = new Amount(src.getV5bal(), src.getC8pwd().toBigInteger().intValue(), src.getV5ccy());
        deposit
                .setStatus(depositStatus(src))
                .setTermDeposit(new BigDecimal(src.getFactday()))
                .setFullName(getFullName(src))
                .setStartBalance(new Amount(src.getDla2(), src.getC8pwd().toBigInteger().intValue(), src.getV5ccy()))
                .setTotalRate(src.getTotalint())
                .setInterestPaid(src.getFinres().divide(src.getC8pwd()))
                .setInterestRate(src.getV5rat())
                .setBaseRate(src.getBrat())
                .setBranch(src.getOsbrnm())
                .setDepositType(src.getOsdlp())
                .setDepositNumber(src.getOsdlr())
                .setPremiumRate(src.getDrat())
                .setAccountNumber(src.getNeeandeposit())
                .setOpenDate(src.getDataopennext())// Date.from(src.getOtsdte().toGregorianCalendar().toZonedDateTime().toInstant()))
                .setCloseDate(src.getDend())// Date.from(src.getDdend().toGregorianCalendar().toZonedDateTime().toInstant()))
                .setClassification(new ProductClassification().setCategory(Constants.ProductCategory.BANKACCOUNT.toString())
                        .setGroupWithinCategory(Constants.ProductSubCategory.DEPOSIT.toString()))
                .setFinancialResults(finResultns)
                .setBalanceAmount(balanceAmount)
                .setBalanceAmountInMinorUnits(balanceAmount.getAmountInMinorUnits())
                .setBalanceAmountReal(balanceAmount.getAmountReal())
                .setBalanceCurrencyCode(balanceAmount.getCurrencyCode())
                .setBalanceMinority(balanceAmount.getMinority())
                .setTimestamp(Date.from(Instant.now()))
                .setName(getDepositName(src))
        ;
        return deposit;
    }

    public static AccountDeposit createFromSOAPResultSetRow(WSStatementDepositListGetOutResultSetRow row) {
        FinancialResults finResultns = new FinancialResults();
        FinancialResult result = new FinancialResult();
        finResultns.setFinResultAll(result);
        result.setAmount(row.getV5Am4().divide(row.getC8Pwd()));
        result.setAmountInMinorUnits(row.getV5Am4());
        result.setMinority(row.getC8Pwd().toBigInteger().intValue());
        result.setCurrencyCode(row.getV5Ccy());
        AccountDeposit deposit = new AccountDeposit();
        Amount balanceAmount = new Amount(row.getV5Bal(), row.getC8Pwd().toBigInteger().intValue(), row.getV5Ccy());
        deposit
                .setBranch(row.getOsbrnm())
                .setDepositType(row.getOsdlp())
                .setDepositName(row.getNm1())
                .setDepositNumber(row.getOsdlr())
                .setExpressAccount(row.getNeeanintr())
                .setDepositTerm(row.getTermdescr())
                .setProlongation(row.getProl())
                .setCapitalization(row.getCpi())
                .setTermDeposit(row.getCdd())
                .setRefillTerm(row.getDinclast())
                .setRefillable(row.getPopol())
                .setFullName(String.format("%s %s", row.getNm1(), row.getNm2()))
                .setStartBalance(new Amount(row.getDla2(), row.getC8Pwd().toBigInteger().intValue(), row.getV5Ccy()))
                .setTotalRate(row.getTotalint())
                .setInterestRate(row.getV5Rat())
                .setBaseRate(row.getBrat())
                .setPremiumRate(row.getDrat())
                .setDepositKind(row.getDll())
                .setEarlyWithdrawalAttr(row.getSnt())
                .setMinBalance(row.getMinbal())
                .setDepositBalance(row.getV5Bal())
                .setDepositBranch(row.getV5Abd())
                .setDepositBasicAccountNumber(row.getV5And())
                .setDepositSuffix(row.getV5Asd())
                .setSwitchOnProlongation(row.getOnprl())
                .setSwitchOffProlongation(row.getCnlprl())
                .setAccountNumber(row.getNeean())
                .setOpenDate(Date.from(row.getOtsdte().toGregorianCalendar().toZonedDateTime().toInstant()))
                .setCloseDate(Date.from(row.getDdend().toGregorianCalendar().toZonedDateTime().toInstant()))
                .setClassification(new ProductClassification().setCategory(Constants.ProductCategory.BANKACCOUNT.toString())
                        .setGroupWithinCategory(Constants.ProductSubCategory.DEPOSIT.toString()))
                .setFinancialResults(finResultns)
                .setBalanceAmount(balanceAmount)
                .setBalanceAmountInMinorUnits(balanceAmount.getAmountInMinorUnits())
                .setBalanceAmountReal(balanceAmount.getAmountReal())
                .setBalanceCurrencyCode(balanceAmount.getCurrencyCode())
                .setBalanceMinority(balanceAmount.getMinority())
                .setTimestamp(Date.from(Instant.now()))
                .setName(getDepositName(row))
        ;
        return deposit;
    }

    private static String getDepositName(AccountDepositRestResponse.AccountDepositFromRestApi src) {
        return ofNullable(src.getProductname()).orElse(DEFAULT_DEPOSIT_NAME);
    }

    private static String getDepositName(WSStatementDepositListGetOutResultSetRow row) {
        return ofNullable(row.getDname()).orElse(DEFAULT_DEPOSIT_NAME);
    }

    private static String getFullName(AccountDepositRestResponse.AccountDepositFromRestApi src) {
        if (null == src.getNm1full() || src.getNm1full().isEmpty()) {
            return "";
        } else if (null == src.getNm2add() || src.getNm2add().isEmpty()) {
            return src.getNm1full();
        } else {
            return String.format("%s %s", src.getNm1full(), src.getNm2add());
        }
    }

    private static String depositStatus(AccountDepositRestResponse.AccountDepositFromRestApi src) {
        switch (src.getIsclosed()) {
            case "N":
                return DEPOSIT_STATUS_ACTUAL;
            case "Y":
                return DEPOSIT_STATUS_CLOSED;
            case "D":
                return DEPOSIT_STATUS_DISSOLVED;
            case "R":
                return DEPOSIT_STATUS_PROLONGED;
            default:
                return "";
        }
    }
}