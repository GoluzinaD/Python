package ru.alfabank.ufr.deposit.api.aspect.validation;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;
import ru.alfabank.ufr.deposit.api.entity.rest.DepositCreateRESTRequestData;

@Aspect
@Component
@Slf4j
public class CusMatching {
    @Around("createDepositExecution() && args(.., @RequestBody body)")
    public Object validate(ProceedingJoinPoint pjp, DepositCreateRESTRequestData body) throws Throwable {

        validateBody(body);

        Object result = pjp.proceed();

        return result;
    }

    private void validateBody(DepositCreateRESTRequestData body) {
        if(!(body.getBcus().equals(body.getAnf()) && body.getBcus().equals(body.getAnm()))) {
            throw new CusMatchingValidationException(String.format("bcus, anf, anm params must be an user id and should be equals. Got: bcus=%s anf=%s anm=%s",
                    body.getBcus(), body.getAnf(), body.getAnm()));
        }
    }

    @Pointcut("execution(public * ru.alfabank.ufr.deposit.api.controller.deposit.ClientDepositsController.createDeposit(..))")
    public void createDepositExecution(){}


}

