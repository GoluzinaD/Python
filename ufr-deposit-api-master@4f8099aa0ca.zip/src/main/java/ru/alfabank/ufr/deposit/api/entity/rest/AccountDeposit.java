package ru.alfabank.ufr.deposit.api.entity.rest;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.util.UUID;

@Data
@Accessors(chain = true)
@JsonInclude(JsonInclude.Include.ALWAYS)
@EqualsAndHashCode(callSuper = false)
public class AccountDeposit extends Account {
    private String branch;
    private String depositType;
    private String depositNumber;
    private String depositName;
    private String expressAccount;
    private String depositTerm;
    private String prolongation;
    private String capitalization;
    private BigDecimal termDeposit;
    private BigDecimal refillTerm;
    private String fullName;
    private Amount startBalance;
    private BigDecimal interestPaid;
    private BigDecimal totalRate;
    private BigDecimal interestRate;
    private BigDecimal baseRate;
    private BigDecimal premiumRate;
    private String status;
    private String uniqId = UUID.randomUUID().toString();
    private String refillable;
    private String depositKind;
    private String earlyWithdrawalAttr;
    private BigDecimal minBalance;
    private BigDecimal depositBalance;
    private String depositBranch;
    private String depositBasicAccountNumber;
    private String depositSuffix;
    private String switchOnProlongation;
    private String switchOffProlongation;
    private String operationName;
}
