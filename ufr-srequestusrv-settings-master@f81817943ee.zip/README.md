# Описание

Модуль сервера конфигурации [Spring Cloud Config](https://cloud.spring.io/spring-cloud-config/spring-cloud-config.html)
Использует статичное файловое хранилище (зашитое в JAR'нике) для хранения конфигов (вместо использования репозитория GIT)


# Выставленные REST-сервисы:

#### Получение файла настроек для: приложения/окружения/версии
```
GET http://localhost:8888/{application}/{profile}
```
где:
* **{application}** - имя приложения
* **{profile}** - название профиля (development / integration / loading / prelive / production )

        
# Структура описания конфигурации:

Файлы конфигурации хранятся в **src/main/resources/configs/**{application}/{application}-{profile}.(properties|yml)

#### Пример расположения файлов конфигураций:
```
src/main/resources/configs/client-app-name/client-app-name-development.yml
src/main/resources/configs/client-app-name/client-app-name-integration.yml
src/main/resources/configs/client-app-name/client-app-name-prelive.yml
src/main/resources/configs/client-app-name/client-app-name-production.yml
```
где:
* **client-app-name** - название приложения, которое запрашивает конфиги (spring.application.name)
* **development | integration | loading | prelive | production** - активный профиль приложения, которе запрашивает конфиги

# Как подключить spring cloud config к своему проекту

1. Склонировать пример ufr-example-settings (новая версия spring cloud config с локальными конфигами(без git`а))
2. Добавить в свой проект с именем ufr-<*код вашего проекта*>-settings
3. Изменить название проекта в settings.gradle на свой
4. Изменить в файле build.gradle group с ru.alfabank.ufr.sandbox.configserver на ru.alfabank.ufr.<*код вашего проекта*>.configserver
5. Изменить название package с ru.alfabank.ufr.sandbox.configserver на ru.alfabank.ufr.<*код вашего проекта*>.configserver (лучше сделать с помощью рефакторинга в idea)
6. Изменить в src/main/resources/application.yml: 
	application.name с ufr-sandbox-settings на ufr-<*код вашего проекта*>-settings	
7. Добвить конфиги своих сервисов в src/main/resources/configs/ в строгом соотвествии с правилами: **Структура описания конфигурации**
8. Удалить директорию src/main/resources/configs/ufr-example-srv
9. Далее данный сервис проходит аналогичный любому микросервису pipeline 
